package com.diotek.hangul;

public class DioHangulCoreMethodService{

	private int mHangulHandle;
	
	public void DioHangulCreate(long type) {
		mHangulHandle = HangulCore.Hangul_Create(type);
	}
	
	public void DioHangulDestroy() {
		HangulCore.Hangul_Destroy(mHangulHandle);
	}
	
	public void DioHangulClearState() {
		HangulCore.Hangul_ClearState(mHangulHandle);
	}
	
	public void DioHangulResetMultiTap() {
		HangulCore.Hangul_RestMultiTap(mHangulHandle);
	}
	
	public int DioHangulProcQwerty(char inputChar, char[] strResult, int nResultLen, byte[] delLen, int nkeyType) {
		return HangulCore.Hangul_ProcHangulQwerty(mHangulHandle, inputChar, strResult, nResultLen, delLen, nkeyType);
	}
	
	public boolean DioHangulSetMultitapKeymap(char[]keyMapData, int nKeyMapsizeNum) {
		return HangulCore.Hangul_SetMultitapKeyMap(mHangulHandle, keyMapData, nKeyMapsizeNum);
	}
	
	public int DioHangulProcMultitap(int nKeyIndex, char[] strResult, int nResultLen, byte[] delLen) {
		return HangulCore.Hangul_ProcHangulMultitap(mHangulHandle, nKeyIndex, strResult, nResultLen, delLen);
	}
}
