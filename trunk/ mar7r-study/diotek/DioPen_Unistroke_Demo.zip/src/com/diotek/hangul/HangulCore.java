package com.diotek.hangul;

import android.util.Log;

import com.diotek.ime.unistroke.CommonData;

public class HangulCore{
    static {
        try {
            Log.i("JNI", "Trying to load libHangulCore.so");
            if(CommonData.TARGET == true) {
                System.load("/system/lib/libHangulCore.so");
            } else {
                System.load("/data/data/com.diotek.ime.unistroke/lib/libHangulCore.so");
            }
        } catch (UnsatisfiedLinkError ule) {
            Log.e("JNI", "WARNING: Could not load libHangulCore.so");
        }
    }

    //FLAG FOR AVAILABLE MODULE
    public final static int USE_LAN_KOR_QWERTY_DUBUL    = 0x02;
    public final static int USE_LAN_KOR_CHYNJYIN_HANGUL = 0x04;
    public final static int USE_LAN_KOR_SASANG_HANGUL   = 0x08;
    public final static int USE_LAN_KOR_MOTOROLA_HANGUL = 0x10;
    public final static int USE_LAN_KOR_NARAGUL_HANGUL  = 0x20;
    public final static int USE_LAN_KOR_SKY2_HANGUL     = 0x40;
    
    //for strInput array
    public final static int MULTITAP_KEY_MAP_SIZE = 36;
    public final static int MAX_STRING_INPUT_NUM  = 3;    
    
    // CJI only
    public final static int CHUNJYIN_CHUN    = 0x00B7;    // .
    public final static int CHUNJYIN_DCHUN   = 0x2025;    // ..
    public final static int CHUNJYIN_JY      = 0x3161;    // ��
    public final static int CHUNJYIN_IN      = 0x3163;    // ��
    
    // Sasang only
    public final static int SASANG_VOWL_LARGE_V = 0x3163;  // �� ��
    public final static int SASANG_VOWL_LARGE_H = 0X3161;  // �� ��
    public final static int SASANG_VOWL_SMALL_V = 0x0131;  // ª�� ��
    public final static int SASANG_VOWL_SMALL_H = 0x00AD;  // ª�� ��
    
    // MultiTab || Half-Qwerty add-stroke
    public final static int NARAGUL_STROKE_ADD_QWERTY = 0xD68D;    // NARAGUL Qwerty ȹ �߰�       ('ȹ')
    public final static int NARAGUL_STROKE_ADD_ITUT   = 0xFF0A;    // NARAGUL multitab ȹ �߰�     ('*')
    public final static int NARAGUL_DSTROKE_ADD_ITUT  = 0x0023;    // NARAGUL multitab �� ���� �߰�('#')
    
    public final static int MOTO_STROKE_ADD_QWERTY  = 0xD68D;    // Moto Qwerty ȹ �߰�        ('ȹ')
    public final static int MOTO_STROKE_ADD_ITUT    = 0x0023;    // Moto multitab ȹ �߰�        ('#') 

    public final static int SASANG_DSTROKE_ADD_ITUT  = 0x0023;    // Sasang multitab �� ���� �߰� ('#')

    public final static int ECompositionResult_None  = 0;    //���� ����� ���� ��.
    public final static int ECompositionResult_Exist = 1;    //���� ����� ���� ��.

    public final static int ECompositionError_MemoryIsTooSmall = -1;        //pszResult�� size�� ���� ��.
    public final static int ECompositionError_InvalidMultiTapState = -2;    //MultiTapState�� �ùٸ� ���� �ƴ� ��.
    public final static int ECompositionError_InvalidKeyType = -3;            //KeyType�� �ùٸ� ���� �ƴ� ��.
    
    public final static int EHangulKeyType_None = 0;
    public final static int EHangulKeyType_Cho  = 1;
    public final static int EHangulKeyType_Jung = 2;
    public final static int EHangulKeyType_Jong = 3;
    
    public final static int ITUT_KEY_IDX_0 = 0;
    public final static int ITUT_KEY_IDX_1 = 1;
    public final static int ITUT_KEY_IDX_2 = 2;
    public final static int ITUT_KEY_IDX_3 = 3;
    public final static int ITUT_KEY_IDX_4 = 4;
    public final static int ITUT_KEY_IDX_5 = 5;
    public final static int ITUT_KEY_IDX_6 = 6;
    public final static int ITUT_KEY_IDX_7 = 7;
    public final static int ITUT_KEY_IDX_8 = 8;
    public final static int ITUT_KEY_IDX_9 = 9;
    public final static int ITUT_KEY_IDX_STAR = 10;
    public final static int ITUT_KEY_IDX_POUND = 11;
    public final static int ITUT_KEY_IDX_BSPACE = 12;
    public final static int ITUT_KEY_IDX_MAX = 13;
    
    // callback_implementation [[
    // General api
     public static native int      Hangul_Create(long type);      // ��ü ������ �ּ� ����
     public static native boolean  Hangul_Destroy(int ptr);      // Destroy ���� ����

    //Hangul_Ime
     public static native void     Hangul_ClearState(int ptr);
     public static native void     Hangul_RestMultiTap(int ptr);
     public static native boolean  Hangul_SetMultitapKeyMap(int ptr, char[] keyMapData , int nKeyMapsizeNum);

     public static native int       Hangul_ProcHangulMultitap(int ptr, int nKeyIndex, char[] strResult, int nResultLen, byte[] delLen);
     public static native int       Hangul_ProcHangulQwerty(int ptr, char inputChar, char[] strResult, int nResultLen, byte[] delLen, int nkeyType);
    // callback_implementation ]]
}