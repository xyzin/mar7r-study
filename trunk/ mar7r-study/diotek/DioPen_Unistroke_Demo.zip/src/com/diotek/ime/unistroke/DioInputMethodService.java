﻿package com.diotek.ime.unistroke;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.DialogInterface.OnClickListener;
import android.content.res.Configuration;
import android.inputmethodservice.InputMethodService;
import android.inputmethodservice.Keyboard;
import android.inputmethodservice.KeyboardView;
import android.inputmethodservice.KeyboardView.OnKeyboardActionListener;
import android.media.AudioManager;
import android.os.SystemClock;
import android.os.Vibrator;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.CompletionInfo;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;

import com.diotek.dhwr.unistroke.DHWR;
import com.diotek.dhwr.unistroke.DioHwrMethodService;
import com.diotek.hangul.DioHangulCoreMethodService;
import com.diotek.hangul.HangulCore;
import com.diotek.ime.unistroke.R;
import com.diotek.ime.unistroke.DioCandidateMgr;
import com.diotek.ime.unistroke.CommonData.InputRangeMode;
import com.diotek.recomword.RecomWord;

public class DioInputMethodService extends InputMethodService implements
        OnKeyboardActionListener {

    private static String TAG = "DioInputMethodService";
    private static boolean DEBUG = CommonData.IME_DEBUG;
    
    private int mInputMethodIndex = CommonData.MODES[0];
//    private int mOldInputMethodIndex = CommonData.MODES[0];
//    private boolean mSettings = false;;
    private static int mInputRangeIndex = InputRangeMode.KOR.ordinal(); // 처음 띄우는 언어
    private static int mOldInputRangeIndex = InputRangeMode.KOR.ordinal();
    private static int mInputRangePrevIndex = InputRangeMode.KOR.ordinal();
    private static int mInputRangePrevSymIndex = InputRangeMode.NUM.ordinal();
    private static boolean mTypeClassDateTime = false;
    private static final int HANGUL_RESULT_SIZE = 3;

    private boolean mPredicting;
    private boolean mPredictionOn;  // editor type에 따른 prediction on/off
    private boolean mCompletionOn;  // editor type에 따른 completion on/off
    private boolean mAutoCorrectOn;  // editor type에 따른 correction on/off

    private boolean mAutoSpace;
    private boolean mCapsLock;
    private boolean mAutoCap = true;
    private boolean mCandidateShown = false;
    private boolean mHardKeyboradshown = false;
    private boolean mAltState = false;
    private boolean mAltLockState = false;
    
    private boolean mUnistroke = false;
    private boolean mCands = false;
    
    private boolean mPasswordMode;

    private boolean mVibrateOn;
    private boolean mSoundOn;
    private AudioManager mAudioManager;
    private final float FX_VOLUME = -1.0f; // 1.0f

    private Vibrator mVibrator;
    private long mVibrateDuration;
    private static final String PREF_VIBRATE_ON = "vibrate_on";
    private static final String PREF_SOUND_ON = "sound_on";

    public static final String PREF_RESTORE_INPUTMETHOD = "mySharedPref_InputMethodIndex"; // ejjeon 2010/08/17 united unistroke test 다른 클래스에서도 쓰기위해 public 으로 변경
    private static final String PREF_RESTORE_INPUTEMTHOD_KEY = "com.diotek.ime.unistroke.InputMethodIndex";
	// ejjeon 2010/08/17 united unistroke test { shift info, num shift info 저장을 위해
    public static final String PREF_RESTORE_SHIFT_RANGE = "com.diotek.ime.unistroke.ShiftRange";
    public static final String PREF_RESTORE_SHIFT_DIRECTION = "com.diotek.ime.unistroke.ShiftDirection";
    public static final String PREF_RESTORE_SHIFT_NUM0 = "com.diotek.ime.unistroke.ShiftNum0";
    public static final String PREF_RESTORE_SHIFT_NUM1 = "com.diotek.ime.unistroke.ShiftNum1";
    public static final String PREF_RESTORE_SHIFT_NUM2 = "com.diotek.ime.unistroke.ShiftNum2";
    public static final String PREF_RESTORE_SHIFT_NUM3 = "com.diotek.ime.unistroke.ShiftNum3";
    public static final String PREF_RESTORE_SHIFT_NUM4 = "com.diotek.ime.unistroke.ShiftNum4";
    public static final String PREF_RESTORE_SHIFT_NUM5 = "com.diotek.ime.unistroke.ShiftNum5";
    public static final String PREF_RESTORE_SHIFT_NUM6 = "com.diotek.ime.unistroke.ShiftNum6";
    public static final String PREF_RESTORE_SHIFT_NUM7 = "com.diotek.ime.unistroke.ShiftNum7";
    public static final String PREF_RESTORE_SHIFT_NUM8 = "com.diotek.ime.unistroke.ShiftNum8";
    public static final String PREF_RESTORE_SHIFT_NUM9 = "com.diotek.ime.unistroke.ShiftNum9";
	// ejjeon 2010/08/17 united unistroke test }

    private boolean mSilentMode;
    private boolean mProximityCorrection;

    private CompletionInfo[] mCompletions;
    private int mDeleteCount;
    private static final int DELETE_ACCELERATE_AT = 20;
    private static final int QUICK_PRESS = 200;
    private long mLastKeyTime;

    private AlertDialog mOptionDlg;

    private DioKeyboardSwitcher mIMESwitcher;
    private static DioComKeyboardView mInputView;
    private DioCandidateMgr mCandidateMgr;
    private DioCandidateView mCandidateView;
    
    // Hwr engine
    private DioHwrMethodService mHwrService;
    
    // Hangul engine
    private DioHangulCoreMethodService mHangulKeypad;
    private DioHangulCoreMethodService mHangulQwerty;
    private DioHangulCoreMethodService mHangulHalfQwerty;
    
    private int mHangulCore;

    private StringBuilder mComposing = new StringBuilder();
    private StringBuilder mComposingRecomm = new StringBuilder();
    private String mWordSeparators;
    private String mSentenceSeparators;

    private Suggest mSuggest;
    private UserDictionary mUserDictionary;
    private List<CharSequence> mUDBList = new ArrayList<CharSequence>();
    private WordComposer mWord = new WordComposer();
    private List<CharSequence> mSuggestions =  new ArrayList<CharSequence>();

    private int mSymPage=0;
    private static String mLocale;
    private boolean mRestarting = false;
    
    private boolean mIsLandscape = false;
    
    private int mBestWordIdx = 0;

    public CharSequence[] mKeyboaerList;
    // Rwd porting
    private char[] pathRwdBuf = new char[RecomWord.MAX_LEN_FILE_PATH];
    //private boolean rwdEnableMode = false;

    @Override
    public void onPress(int primaryCode) {
        if(primaryCode != CommonData.KEYCODE_HWR_PANEL) {
            vibrate();
            playKeyClick(primaryCode);
        }
        // TODO Auto-generated method stub
    }

    @Override
    public void onRelease(int arg0) {
        // TODO Auto-generated method stub
    }

    @Override
    public void swipeDown() {
        // TODO Auto-generated method stub
    	mInputView.dismissPreview();
    	hideWindow();
    	onWindowHidden();
    }

    @Override
    public void swipeLeft() {
        // TODO Auto-generated method stub
    	mInputView.dismissPreview();
    	LeftShiftInputRange();
    }

    @Override
    public void swipeRight() {
        // TODO Auto-generated method stub
    	mInputView.dismissPreview();
    	RightShiftInputRange();
    }

    @Override
    public void swipeUp() {
        // TODO Auto-generated method stub

    }
    @Override
    public void onCreate() {
        super.onCreate();
        if (DEBUG) Log.d(TAG,"onCreate");

        // RESTORE_INPUT_METHOD
        SharedPreferences mySharedPref = this.getSharedPreferences(PREF_RESTORE_INPUTMETHOD, Activity.MODE_PRIVATE);
        mInputMethodIndex = mySharedPref.getInt(PREF_RESTORE_INPUTEMTHOD_KEY, CommonData.MODES[0]);

        loadSettings();

        mIMESwitcher = new DioKeyboardSwitcher(this);

        mLocale = getResources().getConfiguration().locale.toString();
        mWordSeparators = getResources().getString(R.string.word_separators);
        mSentenceSeparators = getResources().getString(R.string.sentence_separators);
        mVibrateDuration = getResources().getInteger(R.integer.vibrate_duration_ms);
        initSuggest();

        if( CommonData.USE_RWD ) {
            String path = "/data/data/com.diotek.ime.unistroke/";

            path.getChars(0, path.length(), pathRwdBuf, 0);
            int ret = RecomWord.RW_Create();
            if (DEBUG) Log.i(TAG,"[RWD] RW_Create : " + ret);

            if( mLocale.regionMatches(true, 0, "ko", 0, 2) ) {
                ret = RecomWord.RW_InitLangDB(RecomWord.RWD_LANG_KOR, (short)12);
            }else {
                ret = RecomWord.RW_InitLangDB(RecomWord.RWD_LANG_ENG_US, (short)12);
            }

            if (DEBUG) Log.i(TAG,"[RWD] RW_InitLangDB : " + ret);

            ret = RecomWord.RW_InitUserDB(pathRwdBuf);
            if (DEBUG) Log.i(TAG,"[RWD] RW_InitUserDB : " + ret);

            ret = RecomWord.RW_InitUserHistoryDB(pathRwdBuf);
            if (DEBUG) Log.i(TAG,"[RWD] RW_InitUserHistoryDB : " + ret);

            ret = RecomWord.RW_SetSpellChkDB(pathRwdBuf);
            if (DEBUG) Log.i(TAG,"[RWD] RW_SetSpellChkDB : " + ret);
        }

        // HWR service create
        if(isModes(CommonData.MODE_HANDWRITING) || isModes(CommonData.MODE_FULL_HANDWRITING)) { 
            mHwrService = new DioHwrMethodService();
            if( mHwrService != null ) {
                mHwrService.setContext(this);
                mHwrService.Create();
                mHwrService.initMethod();
            }
            hwrUnistrokeUpdateSettings();
        }

        // Hangul core create
        if((isModes(CommonData.MODE_KEYPAD_SKY2) || isModes(CommonData.MODE_KEYPAD_CJI) 
        		|| isModes(CommonData.MODE_KEYPAD_NARA) || isModes(CommonData.MODE_KEYPAD_MOTO) )
        		&& !CommonData.ONLY_ENGLISH) { 
            mHangulKeypad = new DioHangulCoreMethodService();
            if( mHangulKeypad != null ) {
                mHangulKeypad.DioHangulCreate(HangulCore.USE_LAN_KOR_SKY2_HANGUL);
                mHangulKeypad.DioHangulSetMultitapKeymap(CommonData.KeyData_Sky2, CommonData.KeyData_Sky2.length);
                mHangulKeypad.DioHangulClearState();
            }
        }

        if(isModes(CommonData.MODE_QWERTY) && !CommonData.ONLY_ENGLISH) { 
            mHangulQwerty = new DioHangulCoreMethodService();
            if( mHangulQwerty != null ) {
                mHangulQwerty.DioHangulCreate(HangulCore.USE_LAN_KOR_QWERTY_DUBUL);
                mHangulQwerty.DioHangulClearState();
            }
        }
        if(isModes(CommonData.MODE_HALF_QWERTY) && !CommonData.ONLY_ENGLISH) { 
            mHangulHalfQwerty = new DioHangulCoreMethodService();
            if( mHangulHalfQwerty != null ) {
                mHangulHalfQwerty.DioHangulCreate(HangulCore.USE_LAN_KOR_SASANG_HANGUL);
                mHangulHalfQwerty.DioHangulClearState();
            }
        }
    }

    public boolean isModes(int nMode) {
        for(int i=0; i<CommonData.MODES.length; i++) {
            if(CommonData.MODES[i] == nMode)
               return true;
        }
        return false;
    }
    
    private void initSuggest() {
        mSuggest = new Suggest(this);
        mUserDictionary = new UserDictionary(this);
        mSuggest.setUserDictionary(mUserDictionary);
    }

    @Override
     public void onConfigurationChanged(Configuration conf) {
        if(DEBUG) Log.i(TAG,"onConfigurationChanged");

        mLocale = getResources().getConfiguration().locale.toString();
  
        if(conf.orientation == Configuration.ORIENTATION_LANDSCAPE){
			mIsLandscape = true;
		} else if(conf.orientation == Configuration.ORIENTATION_PORTRAIT){
			mIsLandscape = false;
		}
		
        super.onConfigurationChanged(conf);     
     }

    @Override public void onDestroy() {
        if (DEBUG) Log.i(TAG,"onDestroy");

        if( mUserDictionary != null ) {
            mUserDictionary.close();
            mUserDictionary = null;
        }

        if( mSuggest != null ) {
            mSuggest = null;
        }

        if( mWord != null ) {
            mWord.reset();
            mWord = null;
        }

        if( mUDBList != null ) {
            mUDBList.clear();
            mUDBList = null;
        }

        if( CommonData.USE_RWD )
        {
            RecomWord.RW_Destroy();
            if (DEBUG) Log.i(TAG,"[RWD] RW_Destroy : ");
        }

        if(isModes(CommonData.MODE_HANDWRITING)) { 
            if( mHwrService != null ) {
                mHwrService.destroy();
                mHwrService = null;
            }
        }

        // Hangul core create
        if(isModes(CommonData.MODE_KEYPAD_SKY2) || isModes(CommonData.MODE_KEYPAD_CJI) 
        		|| isModes(CommonData.MODE_KEYPAD_NARA) || isModes(CommonData.MODE_KEYPAD_MOTO)) {
            if( mHangulKeypad != null ) {
                mHangulKeypad.DioHangulDestroy();
                mHangulKeypad = null;
            }
        }

        if(isModes(CommonData.MODE_QWERTY)) { 
            if( mHangulQwerty != null ) {
                mHangulQwerty.DioHangulDestroy();
                mHangulQwerty = null;
            }
        }

        if(isModes(CommonData.MODE_HALF_QWERTY)) { 
            if( mHangulHalfQwerty != null ) {
                mHangulHalfQwerty.DioHangulDestroy();
                mHangulHalfQwerty = null;
            }
        }

        super.onDestroy();
    }

    @Override
    public View onCreateInputView() {
        if (DEBUG) Log.d(TAG,"onCreateInputView");

        mInputView = (DioComKeyboardView) getLayoutInflater().inflate(R.layout.input, null);

        mIMESwitcher.setInputView(mInputView);
        mInputView.setOnKeyboardActionListener(this);
        mIMESwitcher.setKeyboardMode(DioKeyboardSwitcher.MODE_TEXT, 0, mHwrService.bUnistroke); // ejjeon 2010/08/27 united unistroke test
        return mInputView;
    }

    @Override
    public View onCreateCandidatesView() {
        mCandidateMgr = (DioCandidateMgr) getLayoutInflater().inflate(R.layout.candidates, null);
        mCandidateMgr.initViews();
        mCandidateView = (DioCandidateView) mCandidateMgr.findViewById(R.id.candidates);
        mCandidateView.setService(this);
        setCandidatesViewShown(true);
        return mCandidateMgr;
    }
    public DioCandidateMgr getCandidateViewMgr() {
    	return mCandidateMgr;
    }
    @Override
    public void onStartInput(EditorInfo attribute, boolean restarting) {
        if (DEBUG) Log.i(TAG,"onStartInput restarting: " + restarting);
        super.onStartInput(attribute, restarting);
 
        mOldInputRangeIndex = mInputRangeIndex;
        mRestarting = restarting;
    }
    
    public boolean isCandidateShown() {
    	return mCandidateShown;
    }

    @Override
    public void onStartInputView(EditorInfo attribute, boolean restarting) {
        if (DEBUG) Log.i(TAG,"onStartInputView restarting: " + restarting);
        // In landscape mode, this method gets called without the input view being created.
        if (mInputView == null) {
            return;
        }

        mIMESwitcher.makeKeyboards();
        mInputView.closing();
        mPredicting = false;

        setCandidatesViewShown(false);
        if (mCandidateView != null) {
            mCandidateView.setSuggestions(null, false, false, (byte)0);
        }

        loadSettings();

        mCompletions = null;
        mSymPage = 0;

        boolean bIsLandscape = isLandscape();

        mPredictionOn = false;
        mCompletionOn = false;
        mAutoCorrectOn = false;
        
        mCapsLock = false;
        mPasswordMode = false;
        mAutoSpace = true;

        if(mRestarting) {
            mInputRangeIndex = mOldInputRangeIndex;
        } else {
            if( mLocale.regionMatches(true, 0, "ko", 0, 2) ) {
                mInputRangeIndex = InputRangeMode.KOR.ordinal();
            }else {
                mInputRangeIndex = InputRangeMode.ENG.ordinal();
            }
        }

        if(CommonData.ONLY_ENGLISH) {
            if(mInputRangeIndex == InputRangeMode.KOR.ordinal()) {
                mInputRangeIndex = InputRangeMode.ENG.ordinal();
            }
        }
        if(bIsLandscape && isModes(CommonData.MODE_QWERTY)) {
            mInputMethodIndex = CommonData.MODE_QWERTY;
        } else {
            SharedPreferences mySharedPref = this.getSharedPreferences(PREF_RESTORE_INPUTMETHOD, Activity.MODE_PRIVATE);
            mInputMethodIndex = mySharedPref.getInt(PREF_RESTORE_INPUTEMTHOD_KEY, CommonData.MODES[0]);
        }
        
//        if(mSettings) {
//            mInputMethodIndex = mOldInputMethodIndex;
//            mSettings = false;
//        }

        mTypeClassDateTime = false;

        if(DEBUG) Log.i(TAG, "attribute.inputType: " + attribute.inputType);
        switch (attribute.inputType&EditorInfo.TYPE_MASK_CLASS) {
        case EditorInfo.TYPE_CLASS_DATETIME:
            mTypeClassDateTime = true;
        case EditorInfo.TYPE_CLASS_NUMBER:
            if( mInputMethodIndex == CommonData.MODE_HANDWRITING || 
                    mInputMethodIndex == CommonData.MODE_FULL_HANDWRITING) {
                mInputRangeIndex = InputRangeMode.NUM.ordinal();
            } else {
                mInputRangeIndex = InputRangeMode.SYM.ordinal();
            }
            mIMESwitcher.setKeyboardMode(DioKeyboardSwitcher.MODE_TEXT, attribute.imeOptions, mHwrService.bUnistroke); // ejjeon 2010/08/27 united unistroke test
            break;

        case EditorInfo.TYPE_CLASS_PHONE:
            mInputMethodIndex = CommonData.MODE_PHONE_NUMBER;
            mInputRangeIndex = InputRangeMode.NUM.ordinal();
            mIMESwitcher.setKeyboardMode(DioKeyboardSwitcher.MODE_PHONE, attribute.imeOptions, mHwrService.bUnistroke); // ejjeon 2010/08/27 united unistroke test
            break;

        case EditorInfo.TYPE_CLASS_TEXT:
            // ejjeon 2010/08/04 united unistroke test { unistroke state init 입력창 새로 띄울 때
            if (mHwrService != null)
                mHwrService.setUnistrokeContextState();
            // ejjeon 2010/08/04 united unistroke test } unistroke state init
            mPredictionOn = true;
            mAutoCorrectOn = true;
            //                if(mInputMethodIndex == CommonData.MODE_FULL_HANDWRITING) {
            //                    mPredictionOn = false;
            //                }

            // Make sure that passwords are not displayed in candidate view
            int variation = attribute.inputType &  EditorInfo.TYPE_MASK_VARIATION;
            if(DEBUG) Log.i(TAG, "variation: " + variation);

            if (variation == EditorInfo.TYPE_TEXT_VARIATION_EMAIL_ADDRESS) {
                mPredictionOn = false;
                mInputRangeIndex = InputRangeMode.ENG.ordinal();
                mIMESwitcher.setKeyboardMode(DioKeyboardSwitcher.MODE_EMAIL, attribute.imeOptions, mHwrService.bUnistroke); // ejjeon 2010/08/27 united unistroke test
            } else if (variation == EditorInfo.TYPE_TEXT_VARIATION_URI) {
                mPredictionOn = false;
                mInputRangeIndex = InputRangeMode.ENG.ordinal();
                mIMESwitcher.setKeyboardMode(DioKeyboardSwitcher.MODE_URL, attribute.imeOptions, mHwrService.bUnistroke); // ejjeon 2010/08/27 united unistroke test
            } else if (variation == EditorInfo.TYPE_TEXT_VARIATION_PASSWORD ||
                    variation == EditorInfo.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD) {
                mInputRangeIndex = InputRangeMode.ENG.ordinal();
                mIMESwitcher.setKeyboardMode(DioKeyboardSwitcher.MODE_TEXT, attribute.imeOptions, mHwrService.bUnistroke); // ejjeon 2010/08/27 united unistroke test
            } else {
                mIMESwitcher.setKeyboardMode(DioKeyboardSwitcher.MODE_TEXT, attribute.imeOptions, mHwrService.bUnistroke); // ejjeon 2010/08/27 united unistroke test
            }

            if (variation == EditorInfo.TYPE_TEXT_VARIATION_FILTER) {
                mPredictionOn = false;
            }

            if (variation == EditorInfo.TYPE_TEXT_VARIATION_WEB_EDIT_TEXT) {
                // If it's a browser edit field and auto correct is not ON explicitly, then
                // disable auto correction, but keep suggestions on.
                if ((attribute.inputType & EditorInfo.TYPE_TEXT_FLAG_AUTO_CORRECT) == 0) {
                    mAutoCorrectOn = false;
                }
            }

            if (variation == EditorInfo.TYPE_TEXT_VARIATION_PASSWORD ||
                    variation == EditorInfo.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ) {
                mPasswordMode = true;
                mPredictionOn = false;
            }

            if (variation == EditorInfo.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
                    || variation == EditorInfo.TYPE_TEXT_VARIATION_PERSON_NAME) {
                mAutoSpace = false;
            }

            //                // If NO_SUGGESTIONS is set, don't do prediction.
            //                if ((attribute.inputType & EditorInfo.TYPE_TEXT_FLAG_NO_SUGGESTIONS) != 0) {
            //                    mPredictionOn = false;
            //                    mAutoCorrectOn = false;
            //                }

            if ((attribute.inputType & EditorInfo.TYPE_TEXT_FLAG_AUTO_CORRECT) == 0) {
                mAutoCorrectOn = false;
            }
            if ((attribute.inputType&EditorInfo.TYPE_TEXT_FLAG_AUTO_COMPLETE) != 0) {
                mPredictionOn = false;
                mCompletionOn = true && bIsLandscape;
            }
            updateShiftKeyState(attribute);
            break;

        default:
            mIMESwitcher.setKeyboardMode(DioKeyboardSwitcher.MODE_TEXT, attribute.imeOptions, mHwrService.bUnistroke); // ejjeon 2010/08/27 united unistroke test
            updateShiftKeyState(attribute);
            break;
        }

        if(DEBUG) Log.d( TAG, "mPredictionOn=" + mPredictionOn + ",mCompletionOn=" + mCompletionOn +
                ", mAutoCorrectOn=" + mAutoCorrectOn + ",mCapsLock=" + mCapsLock +
                ", mPasswordMode=" + mPasswordMode + ",mAutoSpace=" + mAutoSpace );

        mInputView.setProximityCorrectionEnabled(mProximityCorrection);
        initHangulComposingState();

        if( isPredictionOn() ) {
            clearRecomWordInput(true);
            setRecomWordLanguage( mInputRangeIndex );
        }
    }

    @Override
    public void sendKeyChar(char charCode) {
        InputConnection ic = getCurrentInputConnection();
        if(ic == null)
            return;
        
        switch (charCode) {
            case '\n':
                if (!sendDefaultEditorAction(true)) {
                    long eventTime = SystemClock.uptimeMillis();
                    ic.sendKeyEvent(new KeyEvent(eventTime, eventTime,
                            KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER, 0, 0, 0, 0,
                            KeyEvent.FLAG_SOFT_KEYBOARD|KeyEvent.FLAG_KEEP_TOUCH_MODE));
                }
                break;
            default:
                // Make sure that digits go through any text watcher on the client side.
                if (charCode >= '0' && charCode <= '9') {
                    sendDownUpKeyEvents(charCode - '0' + KeyEvent.KEYCODE_0);
                } else {
                    ic.commitText(String.valueOf((char) charCode), 1);
                }
                break;
        }
    }

    private void loadSettings() {
        // Get the settings preferences
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this);
        mVibrateOn = sp.getBoolean(PREF_VIBRATE_ON, true);
        mSoundOn = sp.getBoolean(PREF_SOUND_ON, true);

        setKeyboardList(); // dhlee 2010/02/17 [키보드 리스트 추가]
        hwrUpdateSettings();
        hwrUnistrokeUpdateSettings();

        if( CommonData.USE_RWD ) {
            rwdUpdateSettings();
        }
    }

    @Override
    public void onFinishInput() {
        if (DEBUG) Log.i(TAG,"onFinishInput");

        super.onFinishInput();
        
        if(mOptionDlg != null && mOptionDlg.isShowing()) {
             mOptionDlg.dismiss();
             mOptionDlg = null;
        }

        InputConnection ic = getCurrentInputConnection();
        if(ic != null) {
            ic.finishComposingText();
            mComposing.setLength(0);
            ic.commitText(mComposing, 1);
            
            mComposingRecomm.setLength(0);
            ic.commitText(mComposingRecomm, 1);
            
        }

        updateCandidates();
        //setCandidatesViewShown(false);

        if (mInputView != null) {
            mInputView.closing();
        }
    }

    @Override
    public void onUpdateSelection(int oldSelStart, int oldSelEnd,
            int newSelStart, int newSelEnd,
            int candidatesStart, int candidatesEnd) {

        if(DEBUG) Log.d(TAG,"onUpdateSelection: oldSelStart=" + oldSelStart + ",oldSelEnd=" + oldSelEnd
                + ",newSelStart=" + newSelStart + ",newSelEnd=" + newSelEnd +
                ",candidatesStart=" + candidatesStart + ",candidatesEnd=" + candidatesEnd );

        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd,
                candidatesStart, candidatesEnd);

        if( (newSelStart == 0 && newSelEnd == 0 && 
                candidatesStart == -1 && candidatesEnd == -1) ||
                (candidatesStart != -1 && candidatesEnd != -1 &&
                (newSelStart != candidatesEnd || newSelEnd != candidatesEnd)) ) {
            initHangulComposingState();

            if(mComposing.length() > 0){
                mComposing.setLength(0);
                InputConnection ic = getCurrentInputConnection();
                if (ic != null) {
                    ic.finishComposingText();
                }

                if( mCandidateView != null )
                    mCandidateView.setSuggestions(null, false, false, (byte)mBestWordIdx);

                //setCandidatesViewShown(false);
                clearRecomWordInput(true);
                mPredicting = false;
            }
            if(mHangulCore != 0){
				HangulCore.Hangul_ClearState(mHangulCore);
			}
        }
    }

    @Override
    public void hideWindow() {
        if(DEBUG) Log.i(TAG, "hideWindow" );
        
        if(mOptionDlg != null) {
            if(mOptionDlg.isShowing()) {
                mOptionDlg.dismiss();
                mOptionDlg = null;
            }
        }

        if(mComposing.length() > 0) {
            InputConnection ic = getCurrentInputConnection();
            ic.finishComposingText();
            mComposing.setLength(0);
        }

        handleClose();
        
        super.hideWindow();
    }

    @Override
    public void onWindowHidden() {
        if(DEBUG) Log.i(TAG, "onWindowHidden");
    }

    @Override
    public void onDisplayCompletions(CompletionInfo[] completions) {
        if (DEBUG) {
            for (int i=0; i<(completions != null ? completions.length : 0); i++) {
                Log.i("onDisplayCompletions:", "  #" + i + ": " + completions[i]);
            }
        }
        if (mCompletionOn) {
            if(DEBUG) Log.i(TAG, "onDisplayCompletions:mCompletionOn=" + mCompletionOn );
            mCompletions = completions;
            if (completions == null) {
                mCandidateView.setSuggestions(null, false, false, (byte)mBestWordIdx);
                mPredicting = false;
                //setCandidatesViewShown(false);
                return;
            }

            List<CharSequence> stringList = new ArrayList<CharSequence>();
            for (int i=0; i<(completions != null ? completions.length : 0); i++) {
                CompletionInfo ci = completions[i];
                    
                if (ci != null) stringList.add(ci.getText());
            }
            //CharSequence typedWord = mWord.getTypedWord();
            mCandidateView.setSuggestions(stringList, true, true, (byte)mBestWordIdx);
            setCandidatesViewShown(isPredictionOn() || mCompletionOn);
        }
    }

    @Override
    public void setCandidatesViewShown(boolean shown) {
        // TODO: Remove this if we support candidates with hard keyboard
        if (DEBUG)
            Log.d(TAG,"setCandidatesViewShown : " + shown);
        final int nKeyboardType = DioComKeyboard.getKeyboardType();
        
        if (onEvaluateInputViewShown()) {
            super.setCandidatesViewShown(shown);
            if(nKeyboardType == CommonData.MODE_FULL_HANDWRITING) {
            	Log.d(TAG,"invalidateFullHwrPanel : " + shown);
            	mInputView.invalidateFullHwrPanel(shown);
            } 
            mCandidateShown= shown;
        }
    }

    boolean isPredictionOn() {
        boolean bRet = false;

        if( mPredictionOn && mRwdUseRecomWord )
            bRet = true;

        if( !mRwdWordCompletion && /*!mRwdWordCorrection &&*/ !mRwdSpellCheck )
            bRet = false;

        return bRet;
    }

    @Override
    public void onComputeInsets(InputMethodService.Insets outInsets) {
        super.onComputeInsets(outInsets);
        outInsets.contentTopInsets = outInsets.visibleTopInsets;
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
    	if(DEBUG) Log.e(TAG, "keyCode :" + keyCode);
    	switch (keyCode) {
        case KeyEvent.KEYCODE_BACK:
            if (event.getRepeatCount() == 0 && mInputView != null) {
                if (mInputView.handleBack()) {
                    return true;
                }
            }
            break;
        default:
        	break;
            		
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_DOWN:
            case KeyEvent.KEYCODE_DPAD_UP:
            case KeyEvent.KEYCODE_DPAD_LEFT:
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                // Enable shift key and DPAD to do selections
                if (mInputView != null && mInputView.isShown() && mInputView.isShifted()) {
                    event = new KeyEvent(event.getDownTime(), event.getEventTime(),
                            event.getAction(), event.getKeyCode(), event.getRepeatCount(),
                            event.getDeviceId(), event.getScanCode(),
                            KeyEvent.META_SHIFT_LEFT_ON | KeyEvent.META_SHIFT_ON);
                    InputConnection ic = getCurrentInputConnection();
                    if (ic != null) ic.sendKeyEvent(event);
                    return true;
                }
                break;
        }
        return super.onKeyUp(keyCode, event);
    }

    private void commitTyped(InputConnection inputConnection) {
        if(DEBUG) Log.i(TAG, "commitTyped: mComposing.length() - " + mComposing.length());
        if (mComposing.length() > 0) {
            if (inputConnection != null) {
                inputConnection.commitText(mComposing, 1);
                mComposing.setLength(0);
                initHangulComposingState();
                clearRecomWordInput(true);
            }
        }
        //updateSuggestions();
    }

    private void initShiftKeyState() {
        mCapsLock = false;
        updateShiftKeyState(getCurrentInputEditorInfo());

    }
    
    public boolean isLandscape(){
    	return mIsLandscape;
    }
    
    public void updateShiftKeyState(EditorInfo attr) {
        if (DEBUG) Log.i(TAG, "updateShiftKeyState(EditorInfo attr)");

        InputConnection ic = getCurrentInputConnection();
        if(ic == null) return;

        if(mInputView != null) {
            if (attr != null && mIMESwitcher.isAlphabetMode()) {
                int caps = 0;
                EditorInfo ei = getCurrentInputEditorInfo();
                if (mAutoCap && ei != null && ei.inputType != EditorInfo.TYPE_NULL) {
                    caps = ic.getCursorCapsMode(attr.inputType);
                }
                mInputView.setShifted(mCapsLock || caps != 0);
            } else {
                mIMESwitcher.toggleShift();
                if(mInputView.isShifted() == true) {
                    mInputView.setShifted(false);
                }
            }
        }

        if (CommonData.USE_RWD && isPredictionOn()) {
            if (RecomWord.RW_INPUT_STRING_LENGTH() == 0) {
                if (mCapsLock) {
                    RecomWord.RW_SetShiftMode(RecomWord.RWD_SHIFT_CAPS);
                } else if (mInputView.isShifted()) {
                    RecomWord.RW_SetShiftMode(RecomWord.RWD_SHIFT_ON);
                } else {
                    RecomWord.RW_SetShiftMode(RecomWord.RWD_SHIFT_OFF);
                }
            }
        }
    }

    private boolean doubleSpace(int primaryCode) {
        if(!CommonData.DOUBLE_SPACE || primaryCode != CommonData.KEYCODE_SPACE_VALUE) {
            return false;
        }

        final InputConnection ic = getCurrentInputConnection();
        if (ic == null) return false;
        CharSequence lastThree = ic.getTextBeforeCursor(2, 0);

        if (lastThree != null && lastThree.length() == 2
                && Character.isLetterOrDigit(lastThree.charAt(0))
                && lastThree.charAt(1) == CommonData.KEYCODE_SPACE_VALUE) {
            ic.beginBatchEdit();
            ic.deleteSurroundingText(1, 0);
            ic.commitText(". ", 1);
            ic.endBatchEdit();
            updateShiftKeyState(getCurrentInputEditorInfo());
            return true;
        }

        return false;
    }
    
    public void onKey(int primaryCode, int[] keyCodes) {
        if (DEBUG) Log.i(TAG, "onKey : " + primaryCode);

        final long when = SystemClock.uptimeMillis();
        if (primaryCode != CommonData.KEYCODE_COMMON_BACKSPACE ||
                when > mLastKeyTime + QUICK_PRESS) {
            mDeleteCount = 0;
        }
        mLastKeyTime = when;

        switch (primaryCode) {
        case CommonData.KEYCODE_NULL:
        case CommonData.KEYCODE_FUNCTION_NULL:
            break;

        case Keyboard.KEYCODE_SHIFT:
            if(DEBUG) Log.i(TAG, "Keyboard.KEYCODE_SHIFT");
            handleShift();
            break;

        case CommonData.KEYCODE_COMMON_SHIFT_LONGPRESS:
            handleShiftLock(); // dhlee 2010/02/10 shift_longpress
            break;

        case CommonData.KEYCODE_COMMON_DOT_COM_LONGPRESS:
            launchDomainList();
            break;

        case CommonData.KEYCODE_COMMON_MODE:
            //
            if(CommonData.MODES.length > 1) {
                if(!isLandscape() && isModes(CommonData.MODE_QWERTY))
                    showInputMethodSelectOptionMenu(); // select input method
            } else {
                mInputView.invalidateAll();
            }
            //hideWindow(); // hide ime
            break;

        case CommonData.KEYCODE_COMMON_MODE_LONGPRESS:
//            mOldInputMethodIndex = mInputMethodIndex;
//            mSettings = true;
//            changeInputMethod(CommonData.MODE_QWERTY);
            launchSettingsMenu(); // setting menu
            //showInputMethodSelectOptionMenu();  // select input method
            break;

        case CommonData.KEYCODE_COMMON_INPUT_RANGE:
            int nInputRange = mInputRangeIndex;
            
//            if(nInputRange == InputRangeMode.SYM.ordinal() || nInputRange == InputRangeMode.NUM.ordinal()) {
//                if(mInputMethodIndex == CommonData.MODE_TEXT_HANDWRITING) {
//                    mInputRangePrevSymIndex = mInputRangeIndex;
//                }
//                nInputRange = mInputRangePrevIndex;
//            } else {
    
            if(CommonData.ONLY_ENGLISH) {
                if(mInputMethodIndex == CommonData.MODE_QWERTY
                        || mInputMethodIndex == CommonData.MODE_HALF_QWERTY) {
                    if( mInputRangeIndex == InputRangeMode.ENG.ordinal() ) {
                        nInputRange = InputRangeMode.SYM.ordinal();
                    } else if( mInputRangeIndex == InputRangeMode.NUM.ordinal() || mInputRangeIndex == InputRangeMode.SYM.ordinal()) {
                        nInputRange = InputRangeMode.ENG.ordinal();
                    } 
                } else {
                    if( mInputRangeIndex == InputRangeMode.ENG.ordinal() ) {
                        nInputRange = InputRangeMode.NUM.ordinal();
                    } else if( mInputRangeIndex == InputRangeMode.NUM.ordinal() ) {
                        nInputRange = InputRangeMode.SYM.ordinal();
                    } else if( mInputRangeIndex == InputRangeMode.SYM.ordinal() ) {
                        nInputRange = InputRangeMode.ENG.ordinal();
                    }
                }
            } else {
                if(mInputMethodIndex == CommonData.MODE_QWERTY
                        || mInputMethodIndex == CommonData.MODE_HALF_QWERTY) {
                    if( mInputRangeIndex == InputRangeMode.KOR.ordinal() ) {
                        nInputRange = InputRangeMode.ENG.ordinal();
                    } else if( mInputRangeIndex == InputRangeMode.ENG.ordinal() ) {
                        nInputRange = InputRangeMode.SYM.ordinal();
                    } else if( mInputRangeIndex == InputRangeMode.NUM.ordinal() || mInputRangeIndex == InputRangeMode.SYM.ordinal()) {
                        nInputRange = InputRangeMode.KOR.ordinal();
                    } 
                } else {
                    if( mInputRangeIndex == InputRangeMode.KOR.ordinal() ) {
                        nInputRange = InputRangeMode.ENG.ordinal();
                    } else if( mInputRangeIndex == InputRangeMode.ENG.ordinal() ) {
                        nInputRange = InputRangeMode.NUM.ordinal();
                    } else if( mInputRangeIndex == InputRangeMode.NUM.ordinal() ) {
                        nInputRange = InputRangeMode.SYM.ordinal();
                    } else if( mInputRangeIndex == InputRangeMode.SYM.ordinal() ) {
                        nInputRange = InputRangeMode.KOR.ordinal();
                    }
                }
            } 
            
            changeInputRange( nInputRange );
            break;

        case CommonData.KEYCODE_COMMON_INPUT_RANGE_LONGPRESS:
 //           launchInputRangeSelectOptionMenu(); // dhlee 2010/02/19 [input range 선택]
           	onKey(CommonData.KEYCODE_COMMON_INPUT_RANGE, null);
            break;

        case CommonData.KEYCODE_SYMBOL_LARROW:
        case CommonData.KEYCODE_SYMBOL_RARROW:
        case CommonData.KEYCODE_SYMBOL_PAGE:
            changeNumSymPage(primaryCode);
            break;

        default:
            if(getCurrentInputEditorInfo().imeOptions != EditorInfo.IME_NULL) {
                if(DEBUG) Log.d(TAG, "========= imeOptions ===== primaryCode: " + primaryCode);
                handleCharacter(primaryCode, keyCodes);
            }
            break;
         }
    }

    protected String getWordSeparators() {
        return mWordSeparators;
    }

    public boolean isWordSeparator(int code) {
        String separators = getWordSeparators();
        return separators.contains(String.valueOf((char)code));
    }

    public boolean isSentenceSeparator(int code) {
        return mSentenceSeparators.contains(String.valueOf((char)code));
    }
    
    public boolean isHangulJaso(int code) {
        if(code >= 0x3131 && code <= 0x3163) {
            return true;
        }

        return false;
    }
    
    public void onText(CharSequence text) {
        if(DEBUG) Log.i(TAG, "onText:text=" + text);
        
        if(mTypeClassDateTime && text.length() > 1)
            return;
        
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        
        ic.beginBatchEdit();
        if (mPredicting) {
            mPredicting = false;
            commitTyped(ic);
        }
        ic.commitText(text, 1);
        ic.endBatchEdit();

        updateShiftKeyState(getCurrentInputEditorInfo());
    }

    private void handleBackspace() {
        if(DEBUG) Log.d(TAG, "handleBackspace()");
        
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        
        mDeleteCount++;
        
        if(mHwrService.bUnistroke || !mCands) {
            if(mComposingRecomm.length() - 1 > 0) {
                mComposingRecomm.delete(mComposingRecomm.length() - 1, mComposingRecomm.length());
                ic.setComposingText(mComposingRecomm, 1);
            } else {
                ic.finishComposingText();
                mComposing.setLength(0);
                mComposingRecomm.setLength(0);
                //setCandidatesViewShown(false);
                mSuggestions.clear();
                if( mCandidateView != null )
                    mCandidateView.setSuggestions(null, false, false, (byte)mBestWordIdx);
                mPredicting = false;

                sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL);
                if (mDeleteCount > DELETE_ACCELERATE_AT) {
                    sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL);
                }
            }
        } else {
            if(mComposing.length() - 1 > 0) {
                mComposing.delete(mComposing.length() - 1, mComposing.length());
                ic.setComposingText(mComposing, 1);
            } else {
                ic.finishComposingText();
                mComposing.setLength(0);
                mComposingRecomm.setLength(0);
                //setCandidatesViewShown(false);
                mSuggestions.clear();
                if( mCandidateView != null )
                    mCandidateView.setSuggestions(null, false, false, (byte)mBestWordIdx);
                mPredicting = false;

                sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL);
                if (mDeleteCount > DELETE_ACCELERATE_AT) {
                    sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL);
                }
            }
        }
        
        updateShiftKeyState(getCurrentInputEditorInfo());
    }

    private void handleShift() {
       // Keyboard currentKeyboard = mInputView.getKeyboard();
        if(DEBUG) Log.i(TAG, "handleShift()");
        if (mIMESwitcher.isAlphabetMode()) {
            // Alphabet keyboard
            checkToggleCapsLock();
            mInputView.setShifted(mCapsLock || !mInputView.isShifted());
        } else {
            mIMESwitcher.toggleShift();
        }

        if(CommonData.USE_RWD && isPredictionOn()) {
            Log.i(TAG, "handleShift isPredictionOn");
            if (RecomWord.RW_INPUT_STRING_LENGTH() == 0) {
                if (mCapsLock) {
                    RecomWord.RW_SetShiftMode(RecomWord.RWD_SHIFT_CAPS);
                } else if (mInputView.isShifted()) {
                    RecomWord.RW_SetShiftMode(RecomWord.RWD_SHIFT_ON);
                } else {
                    RecomWord.RW_SetShiftMode(RecomWord.RWD_SHIFT_OFF);
                }
            }
        } else {
            Log.i(TAG, "handleShift isPredictionOff");
            if ((mInputView.isKeypad(mInputMethodIndex)|| mInputMethodIndex == CommonData.MODE_HALF_QWERTY) 
                    && mInputRangeIndex == InputRangeMode.ENG.ordinal()) {
                if(mComposing.length() > 0) {
                    InputConnection ic = getCurrentInputConnection();
                    if( ic != null ) {
                        ic.commitText(mComposing, 1);
                        mComposing.setLength(0);
                    }
                }
            }
        }
    }

    private void handleShiftLock() {
        if (mIMESwitcher.isAlphabetMode()) {
            if(mCapsLock == true) {
                mCapsLock = false;
                ((DioComKeyboard) mInputView.getKeyboard()).setShifted(false);
            } else { 
                mCapsLock = true;
                ((DioComKeyboard) mInputView.getKeyboard()).setShiftLocked(mCapsLock);
            }
            
            mInputView.setShifted(mCapsLock || mInputView.isShifted());

            if(CommonData.USE_RWD && isPredictionOn()) {
                if (RecomWord.RW_INPUT_STRING_LENGTH() == 0) {
                    if (mCapsLock) {
                        RecomWord.RW_SetShiftMode(RecomWord.RWD_SHIFT_CAPS);
                    } else if (mInputView.isShifted()) {
                        RecomWord.RW_SetShiftMode(RecomWord.RWD_SHIFT_ON);
                    } else {
                        RecomWord.RW_SetShiftMode(RecomWord.RWD_SHIFT_OFF);
                    }
                }
            }
            updateShiftKeyState(getCurrentInputEditorInfo());
        }
    }

    public void initComposing()
	{
		if(mComposing.length() > 0)
		{
			mComposing.setLength(0);
			if(mHangulCore != 0)
				HangulCore.Hangul_ClearState(mHangulCore);
		}	

	}
    
 // when Qwerty opened and hangul enabled
	private boolean handleQwertyHangul( int key){
		if(DEBUG) Log.d(TAG,"key : " +key);
		int ret=0;
		
		// convert qwerty key to hangul key
		InputConnection inputConn = getCurrentInputConnection();
		if(inputConn == null){
			if(DEBUG) Log.e(TAG," inputConnection is null ");
			return false;
		}

		// put the hangul char. to automata engine
		if(mComposing.length() == 0){
			if(mHangulCore != 0){
				if(DEBUG) Log.e(TAG,"procComposingCharacter: Hangul_ClearState");
				HangulCore.Hangul_ClearState(mHangulCore);
			}
		}
	
		char[] rstData = new char[HANGUL_RESULT_SIZE];
		byte[] deleteLen = new byte[1];			
		if(key == KeyEvent.KEYCODE_DEL) {
			key = CommonData.KEYCODE_BACKSPACE_VALUE;
		}
		if (mHangulCore != 0) {
			ret = HangulCore.Hangul_ProcHangulQwerty(mHangulCore, (char)key, rstData, HANGUL_RESULT_SIZE, deleteLen, 0);
		}

		int rstLen = 0;
		for(rstLen = 0; rstData[rstLen] != 0; rstLen++);		
		
		if (ret > 0) {
			
			if (rstLen == 2) {	
				if(DEBUG) Log.e(TAG, "rstLen1 : " + rstLen);
				mComposing.setLength(0);
				mComposing.append(rstData[0]);		
				inputConn.setComposingText( mComposing, 1);
				inputConn.finishComposingText();
				mComposing.setLength(0);
				mComposing.append(rstData[1]);		
				inputConn.setComposingText(	mComposing, 1);				
			} else {	// appendLen == 1
				if (deleteLen[0] > 0) {
					if(DEBUG) Log.e(TAG, "rstLen2 : " + rstLen);
					mComposing.setLength(0);
					mComposing.append(rstData[0]);		
					inputConn.setComposingText(	mComposing, 1);														
				} else {
					if(DEBUG) Log.e(TAG, "rstLen3 : " + rstLen);
					inputConn.finishComposingText();
					mComposing.setLength(0);
					mComposing.append(rstData[0]);		
					inputConn.setComposingText(	mComposing, 1);								
				}
			//}
			}					
		}else {
		    if(DEBUG) Log.e(TAG, "rstLen else : " );
			inputConn.finishComposingText();
            mComposing.setLength(0);
            inputConn.setComposingText(mComposing, mComposing.length());
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL);
            initHangulComposingState();
		}
		
		
		return true; 
	}
	
    private boolean handleKorCharacter(int keyCode) {
        if(DEBUG) Log.e(TAG,"handleCharacterKor - keyCode: "+ keyCode);

        InputConnection ic = getCurrentInputConnection();
        if( ic == null ) return false;

        int nRet = -1;
        int nResultLen = 0;
        int nDeleteLen = 0;
        char cResult[] = new char[HANGUL_RESULT_SIZE];
        byte delLen[] = new byte[1];
                     
        if(keyCode == CommonData.KEYCODE_COMMON_ENTER ) {
            ic.finishComposingText();
            mComposing.setLength(0);
            sendKeyChar((char)CommonData.KEYCODE_ENTER_VALUE);
            updateShiftKeyState(getCurrentInputEditorInfo());
            initHangulComposingState();
            //setCandidatesViewShown(false);
            mSuggestions.clear();
            if( mCandidateView != null )
                mCandidateView.setSuggestions(null, false, false, (byte)mBestWordIdx);
            mPredicting = false;
            return true;
        }
        char charTemp = 0;
        if( mInputView.isMultitapActive() 
                && mInputMethodIndex == CommonData.MODE_HALF_QWERTY) {
            mHangulHalfQwerty.DioHangulProcQwerty((char)CommonData.KEYCODE_BACKSPACE_VALUE, cResult, HANGUL_RESULT_SIZE, delLen, 0);
            charTemp = cResult[0];
        }
        
        int nTempCode = keyCode;
        if(mInputView.isKeypad(mInputMethodIndex)) {
            if(keyCode == CommonData.KEYCODE_COMMON_BACKSPACE)
                keyCode = HangulCore.ITUT_KEY_IDX_BSPACE;
            nRet = mHangulKeypad.DioHangulProcMultitap(keyCode, cResult, HANGUL_RESULT_SIZE, delLen);
        } else if(mInputMethodIndex == CommonData.MODE_QWERTY || mInputMethodIndex == CommonData.MODE_HANDWRITING ||  mInputMethodIndex == CommonData.MODE_FULL_HANDWRITING){
            if( keyCode == CommonData.KEYCODE_COMMON_BACKSPACE )
                keyCode = CommonData.KEYCODE_BACKSPACE_VALUE;
            nRet = mHangulQwerty.DioHangulProcQwerty((char)keyCode, cResult, HANGUL_RESULT_SIZE, delLen, 0);
        } else if(mInputMethodIndex == CommonData.MODE_HALF_QWERTY){
            if( keyCode == CommonData.KEYCODE_COMMON_BACKSPACE )
                keyCode = CommonData.KEYCODE_BACKSPACE_VALUE;
            nRet = mHangulHalfQwerty.DioHangulProcQwerty((char)keyCode, cResult, HANGUL_RESULT_SIZE, delLen, 0);
        }

        if(DEBUG) {
            for(int i=0; i<cResult.length; i++) {
                Log.i(TAG, "============== cResult[" + i + "]: " + (int)cResult[i]);
            }
        }

        keyCode = nTempCode;
        if( nRet <= 0 ) {
            if( keyCode == CommonData.KEYCODE_COMMON_BACKSPACE ) {
                handleBackspace();
                initHangulComposingState();
                
                if( mComposing.length() > 0 && isPredictionOn()) {

                    char[] strWordBuf = new char [RecomWord.MAX_WORD_LEN + 1];

                    String strInput = mComposing.toString();
                    strInput.getChars(0, strInput.length(), strWordBuf, 0);

                    if( doRecomWordInputWord(strWordBuf) > 0 ) {
                        if( doRecomWordSearching(mSuggestions) > 0 ) {
                            mCandidateView.setSuggestions(mSuggestions, true, true, (byte)mBestWordIdx );
                            setCandidatesViewShown(true);
                            mPredicting = true;
                        }
                    }
                    strWordBuf = null;
                    return true;
                }
            } else {
                ic.finishComposingText();
                mComposing.setLength(0);
                sendKeyChar((char)keyCode);
            }
            
            initHangulComposingState();
            updateShiftKeyState(getCurrentInputEditorInfo());
            //setCandidatesViewShown(false);  
            mSuggestions.clear();
            if( mCandidateView != null )
                mCandidateView.setSuggestions(null, false, false, (byte)mBestWordIdx);
            mPredicting = false;
            return true;
        }

        for(nResultLen = 0; cResult[nResultLen] != 0; nResultLen++);
        String strResult = String.valueOf(cResult,0,nResultLen);
        nDeleteLen = delLen[0];
        if( mInputView.isMultitapActive() 
                && mInputMethodIndex == CommonData.MODE_HALF_QWERTY) {
            if(delLen[0] == 0) {
                if(charTemp != 0) {
                    mHangulHalfQwerty.DioHangulProcQwerty((char)keyCode, cResult, HANGUL_RESULT_SIZE, delLen, 0);
                    mComposing.setLength(mComposing.length()>0 ? mComposing.length()-1 : 0);
                    mComposing.append(cResult);
                    ic.setComposingText(mComposing, 1);
                    ic.finishComposingText();
                    mComposing.setLength(0);
                    
                    //mComposing.setLength(mComposing.length());
                    mComposing.append(strResult);
                } else {
                    mComposing.setLength(mComposing.length()>0 ? mComposing.length()-1 : 0);
                    mComposing.append(strResult);
                }
            } else {
                mComposing.setLength(mComposing.length()>0 ? mComposing.length()-1 : 0);
                mComposing.append(strResult);
            }
            ic.setComposingText(mComposing, 1);
            return true;
        }

        
        // RecomWord off
        if(DEBUG) Log.e(TAG, "nDeleteLen : " + nDeleteLen);
        if( isPredictionOn() == false ) {
            if( keyCode == CommonData.KEYCODE_COMMON_BACKSPACE ) {
                if(DEBUG) Log.e(TAG,"Backspace: "+ keyCode);

                if(mComposing.length() > 0) {
                    mComposing.setLength(mComposing.length()-nDeleteLen);
                    mComposing.append(strResult);
                    ic.setComposingText(mComposing, 1);
                } else {
                    ic.finishComposingText();
                    mComposing.setLength(0);
                    ic.setComposingText(mComposing, mComposing.length());
                    sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL);
                    initHangulComposingState();
                }
                updateShiftKeyState(getCurrentInputEditorInfo());
                return true;
            }

            int nIndex = 0;
            if (nResultLen >= 2)
            {
                mComposing.setLength(0);
                if(nDeleteLen == 2) {
                    CharSequence charSeq = ic.getTextBeforeCursor(2, 1);
                    if(charSeq.charAt(0) != cResult[nIndex]){
                        ic.deleteSurroundingText(1, 0);
                    }
                } else {
                    mComposing.append(cResult[nIndex]);
                    ic.commitText(mComposing, 1);
                    mComposing.setLength(0);
                }
                nIndex++;
            } else {
                if(nDeleteLen == 0)
                    ic.finishComposingText();
                else if(nDeleteLen == 2)
                    ic.deleteSurroundingText(1, 0);

                mComposing.setLength(0);
            }

            mComposing.append(cResult[nIndex]);
            ic.setComposingText(mComposing, 1);
            
            updateShiftKeyState(getCurrentInputEditorInfo());
            return true;
        }

        // enable RecomWord: prediction on
        if (mComposing.length() - nDeleteLen >= 0) {
            mComposing.setLength(mComposing.length()-nDeleteLen);
            mComposing.append(strResult);
            ic.setComposingText(mComposing, 1);

            if (mComposing.toString().length() > RecomWord.MAX_WORD_LEN) {
                initHangulComposingState();
                if(mComposing.length() > 0) {
                    ic.finishComposingText();
                    mComposing.setLength(0);
                }
            } else {
                //clearRecomWordInput(false);
                char[] strWordBuf = new char [RecomWord.MAX_WORD_LEN + 1];
                String strInput = mComposing.toString();
                strInput.getChars(0, strInput.length(), strWordBuf, 0);
                
                if( doRecomWordInputWord(strWordBuf) > 0 ) {
                    if( doRecomWordSearching(mSuggestions) > 0 ) {
                        mCandidateView.setSuggestions(mSuggestions, true, true, (byte)mBestWordIdx );
                        setCandidatesViewShown(true);
                        mPredicting = true;
                    }
                }
                strWordBuf = null;
            }
        }
        
        updateShiftKeyState(getCurrentInputEditorInfo());
        
        return true;
    }
    
    private boolean handleEngCharacter(int keyCode, int[] keyCodes) {
        if(DEBUG) Log.i(TAG,"handleEngCharacter - keyCode:" + keyCode );

        InputConnection ic = getCurrentInputConnection();
        if( ic == null ) return true;
        mPredicting = false;

        if((keyCode >= 0x30 && keyCode <= 0x39) || 
                keyCode == 0x22 || keyCode == 0x27 || keyCode == 0x2b || 
                keyCode == 0x3f || keyCode == 0x2f || keyCode == 0x40 ||
                keyCode == 0x2d || keyCode == 0x21) { // dhlee 2010/03/22 [0~9]
            if(mInputView.isMultitapActive() && mComposing.length()>=1) {
                mComposing.delete(mComposing.length()-1, mComposing.length());
                mComposing.append((char)keyCode);
                ic.commitText(mComposing, 1);
                mComposing.setLength(0);
            } else {
                ic.finishComposingText();
                mComposing.setLength(0);
                sendKeyChar((char)keyCode);
            }

            updateShiftKeyState(getCurrentInputEditorInfo()); //dhlee 2010/03/24
            mSuggestions.clear();
            if( mCandidateView != null )
                mCandidateView.setSuggestions(null, false, false, (byte)mBestWordIdx);
            mPredicting = false;

            return true;
        }

        if(keyCode == CommonData.KEYCODE_COMMON_ENTER ) {
            ic.finishComposingText();
            mComposing.setLength(0);
            sendKeyChar((char)CommonData.KEYCODE_ENTER_VALUE);

            updateShiftKeyState(getCurrentInputEditorInfo());
            //setCandidatesViewShown(false);
            mSuggestions.clear();
            if( mCandidateView != null )
                mCandidateView.setSuggestions(null, false, false, (byte)mBestWordIdx);
            mPredicting = false;

            return true;
        }
        
        // RecomWord off
        if( isPredictionOn() == false ) {
            // do not use RecomWord
            if( keyCode == CommonData.KEYCODE_COMMON_BACKSPACE ) {
                handleBackspace();
                updateShiftKeyState(getCurrentInputEditorInfo());
            } else if( keyCode == CommonData.KEYCODE_SPACE_VALUE ||
                    keyCode == CommonData.KEYCODE_COMMON_SPACE ) {
                ic.finishComposingText();
                mComposing.setLength(0);
                sendKeyChar((char)CommonData.KEYCODE_SPACE_VALUE);
            } else {
                if(mInputView.isKeypad(mInputMethodIndex)
                        && !(mInputView.getKeyIndex() > 13) ) { // *, #, @, /, .  commit
                    if(!mInputView.isMultitapActive()) {
                        ic.finishComposingText();
                    }

                    mComposing.setLength(0);
                    mComposing.append((char)keyCode);
                    ic.setComposingText(mComposing, 1);
                } else if (mInputMethodIndex == CommonData.MODE_HALF_QWERTY 
                        && keyCodes.length>1
                        && !(mInputView.getKeyIndex() > 13)) {
                    if(!mInputView.isMultitapActive()) {
                        ic.finishComposingText();
                    }

                    mComposing.setLength(0);
                    mComposing.append((char)keyCode);
                    ic.setComposingText(mComposing, 1);
                } else {
                    ic.finishComposingText();
                    mComposing.setLength(0);
                    sendKeyChar((char)keyCode);
                    updateShiftKeyState(getCurrentInputEditorInfo());
                }
            }
            return true;
        }

        // enable RecomWord: prediction on
        if( keyCode == CommonData.KEYCODE_BACKSPACE_VALUE || 
                keyCode == CommonData.KEYCODE_COMMON_BACKSPACE) {
            keyCode = CommonData.KEYCODE_BACKSPACE_VALUE;
            handleBackspace();
            if( mComposing.length() > 0 ) {
                clearRecomWordInput(false);
                if( doRecomWordInputChar((char)keyCode, null) > 0 ) {
                    if( doRecomWordSearching(mSuggestions) > 0 ) {
                        mCandidateView.setSuggestions(mSuggestions, true, true, (byte)mBestWordIdx );
                        //setCandidatesViewShown(true);
                        mPredicting = true;
                    }
                }
            } else {
                clearRecomWordInput(true);
                //setCandidatesViewShown(false);
                mSuggestions.clear();
                if( mCandidateView != null )
                    mCandidateView.setSuggestions(null, false, false, (byte)mBestWordIdx);
                mPredicting = false;
            }
            updateShiftKeyState(getCurrentInputEditorInfo());
            return true;
        } else if( keyCode == CommonData.KEYCODE_SPACE_VALUE ||
                keyCode == CommonData.KEYCODE_COMMON_SPACE ) {
        	if(DEBUG) Log.i(TAG, "mBestWordIdx : " + mBestWordIdx);
        	if(mBestWordIdx != 0 && mSuggestions.size() > 0) {
        		ic.commitText(mSuggestions.get(mBestWordIdx), 1);	// ★
        	}
        	ic.finishComposingText();
            mComposing.setLength(0);
            sendKeyChar((char)CommonData.KEYCODE_SPACE_VALUE);
            clearRecomWordInput(true);
            //setCandidatesViewShown(false);
            mSuggestions.clear();
            if( mCandidateView != null )
                mCandidateView.setSuggestions(null, false, false, (byte)mBestWordIdx);
            mPredicting = false;

            updateShiftKeyState(getCurrentInputEditorInfo());
            
            mBestWordIdx = 0;

            return true;
        }
        
        // case of multi-tap inactive & no letter, commit! 
        if( !Character.isLetter((char)keyCode) ) {
            if(mInputView.isKeypad(mInputMethodIndex) && 
                    !(mInputView.getKeyIndex() > 13) ) { // *, #, @, /, .  commit
                if(!mInputView.isMultitapActive()) {
                    ic.finishComposingText();
                }
                mComposing.setLength(0);
                mComposing.append((char)keyCode);
                ic.setComposingText(mComposing, 1);
            } else {
                ic.finishComposingText();
                mComposing.setLength(0);
                
                sendKeyChar((char)keyCode);
            }
            
            clearRecomWordInput(true);
            mSuggestions.clear();
            if( mCandidateView != null )
                mCandidateView.setSuggestions(null, false, false, (byte)mBestWordIdx);
            mPredicting = false;
            
            if(!mInputView.isMultitapActive() && mInputView.getKeyIndex() != 1) {
                updateShiftKeyState(getCurrentInputEditorInfo());
            }
            return true;
        }
        
        // process letter
        if( mInputView.isMultitapActive() ) {
            if( mComposing.length() > 0 ) {
                mComposing.setLength(mComposing.length()-1);
                clearRecomWordInput(false); // delete one input letter
            }
        } else {
            if( mComposing.length() > 0 ) {
                if( !Character.isLetter(mComposing.charAt(mComposing.length()-1)) ) {
                    ic.finishComposingText();
                    mComposing.setLength(0);
                    if(mHwrService.bUnistroke || mCands) {
                        mComposingRecomm.setLength(0);
                    }
                }
            }
            if(!mHwrService.bUnistroke || !mCands) {
                mComposing.setLength(mComposing.length());
            } else {
                mComposingRecomm.setLength(mComposingRecomm.length());
            }
        }
        
        // dhlee 2010/08/27 [유니스트로크가 아닐때만 추가]
        if(!mHwrService.bUnistroke || !mCands) {
            mComposing.append((char)keyCode);
            ic.setComposingText(mComposing, 1);
        } else {
            ic.beginBatchEdit();
            String strComposing = mComposingRecomm.toString();
            mComposingRecomm.setLength(0);
            if(strComposing.length() > 0) {
                mComposingRecomm.append(strComposing.substring(0, strComposing.length()-1));
            }
            mComposingRecomm.append((char)keyCode);
            ic.commitText(mComposingRecomm, 1);
            ic.finishComposingText();
            ic.deleteSurroundingText(mComposingRecomm.length(), 0);
            ic.setComposingText(mComposingRecomm, 1);
            ic.endBatchEdit();
        }
        
        if( mComposing.toString().length() >= RecomWord.MAX_WORD_LEN ) {
            ic.finishComposingText();
            mComposing.setLength(0);
            clearRecomWordInput(true);
            //setCandidatesViewShown(false);
            mSuggestions.clear();
            if( mCandidateView != null )
                mCandidateView.setSuggestions(null, false, false, (byte)mBestWordIdx);
            mPredicting = false;
        } else {
            char[] regionArray = new char [6];
            int nIMIdx = (mInputView.isKeypad(mInputMethodIndex)) ? 0 : 1;

            char code = Character.toLowerCase((char)keyCode);
            CommonData.wordKeyMap[code - 'a'][nIMIdx].getChars(0, CommonData.wordKeyMap[code - 'a'][nIMIdx].length(), regionArray, 0);
            
            if( doRecomWordInputChar((char)keyCode, regionArray) > 0 ) {
                if( doRecomWordSearching(mSuggestions) > 0 ) {
                    mCandidateView.setSuggestions(mSuggestions, true, true, (byte)mBestWordIdx );
                    setCandidatesViewShown(true);
                    mPredicting = true;
                }
            }

            if( mInputMethodIndex == CommonData.MODE_QWERTY ) {
                updateShiftKeyState(getCurrentInputEditorInfo());
            }

            regionArray = null;
        }

        return true;
    }
    
    private void handleCharacter(int primaryCode, int[] keyCodes) {
        if(DEBUG)
            Log.e(TAG,"handleCharacter primaryCode = "+primaryCode);

        if(doubleSpace(primaryCode)) {
            return;
        }
        
        InputConnection ic = getCurrentInputConnection();
        if( ic == null ) return;
    
        if(primaryCode == CommonData.KEYCODE_COMMON_DOT_COM) {
            ic.finishComposingText();
            ic.commitText(".com", 1);
            mComposing.setLength(0);
            updateShiftKeyState(getCurrentInputEditorInfo());
            return;
        }

        // ejjeon 2010/08/26 united unistroke test {
        if ((primaryCode == CommonData.KEYCODE_COMMON_ENTER) //KEYCODE_ENTER_VALUE
        	|| (primaryCode == CommonData.KEYCODE_SPACE_VALUE) //KEYCODE_COMMON_SPACE
        	|| (primaryCode == CommonData.KEYCODE_COMMON_BACKSPACE))
        	mHwrService.setUnistrokeContextState();
        // ejjeon 2010/08/26 united unistroke test }
        
        if( mInputRangeIndex == InputRangeMode.KOR.ordinal() ) {
            handleKorCharacter(primaryCode);
            return;
        } else if ( mInputRangeIndex == InputRangeMode.ENG.ordinal() ) {
            handleEngCharacter(primaryCode, keyCodes);
            return;
        }
        
        if( mInputRangeIndex == InputRangeMode.SYM.ordinal() ) {
            if(isHangulJaso(primaryCode)) {
                handleKorCharacter(primaryCode);
                return;
            } else if(Character.isLetter(primaryCode)) {
                handleEngCharacter(primaryCode, keyCodes);
                return;
            }
        }

        switch( primaryCode ) {
        case CommonData.KEYCODE_COMMON_ENTER:
            ic.finishComposingText();
            mComposing.setLength(0);
            sendKeyChar((char)CommonData.KEYCODE_ENTER_VALUE);
            updateShiftKeyState(getCurrentInputEditorInfo());
            return;

        case CommonData.KEYCODE_COMMON_BACKSPACE:
            handleBackspace();
            return;

        case CommonData.KEYCODE_SPACE_VALUE:
            sendKeyChar((char)primaryCode);
            updateShiftKeyState(getCurrentInputEditorInfo());
            return;
        }

        ic.finishComposingText();
        mComposing.setLength(0);
        mComposingRecomm.setLength(0);
        sendKeyChar((char)primaryCode);

        updateShiftKeyState(getCurrentInputEditorInfo());
    }


    public void initMultitapComposingState() {
        if( mPredicting ) return;

        mComposing.setLength(0);
        InputConnection ic = getCurrentInputConnection();
        if( ic != null )
            ic.finishComposingText();
    }

    public DioHwrMethodService getHwrService() {
        return mHwrService;
    }

    private boolean setHangulKeypad(int nKeypad, char[] cKeyData) {
        if( mHangulKeypad != null ) {
            mHangulKeypad.DioHangulDestroy();
            mHangulKeypad = new DioHangulCoreMethodService();
            mHangulKeypad.DioHangulCreate(nKeypad);
            mHangulKeypad.DioHangulSetMultitapKeymap(cKeyData, cKeyData.length);
            mHangulKeypad.DioHangulClearState();
            return true;
        }

        return false;
    }

    
    public DioHangulCoreMethodService getHangulService() {
        switch( getInputMethodIndex() ) {
        case CommonData.MODE_KEYPAD_SKY2:
            if(setHangulKeypad(HangulCore.USE_LAN_KOR_SKY2_HANGUL, CommonData.KeyData_Sky2))
                return mHangulKeypad;
            break;
        case CommonData.MODE_KEYPAD_CJI:
            if(setHangulKeypad(HangulCore.USE_LAN_KOR_CHYNJYIN_HANGUL, CommonData.KeyData_Cji))
                return mHangulKeypad;
            break;

        case CommonData.MODE_KEYPAD_NARA:
            if(setHangulKeypad(HangulCore.USE_LAN_KOR_NARAGUL_HANGUL, CommonData.KeyData_Naragul))
                return mHangulKeypad;
            break;

        case CommonData.MODE_KEYPAD_MOTO:
            if(setHangulKeypad(HangulCore.USE_LAN_KOR_MOTOROLA_HANGUL, CommonData.KeyData_Motorola))
                return mHangulKeypad;
            break;
        case CommonData.MODE_HALF_QWERTY:
            return mHangulHalfQwerty;

        case CommonData.MODE_QWERTY:
            return mHangulQwerty;
        }
        
        return null;
    }

    private void initHangulComposingState() {
        if(!CommonData.ONLY_ENGLISH) {
        	if (mInputView == null) {
        		Log.e(TAG, "initHangulComposingState() mInputView is null. return");
        		return;
        	}
        	if(mInputView.isKeypad(mInputMethodIndex)) {
        		if (mHangulKeypad == null) {
            		Log.e(TAG, "initHangulComposingState() mHangulKeypad is null. return");
            		return;
            	}
                mHangulKeypad.DioHangulClearState();
                mHangulKeypad.DioHangulResetMultiTap();
            } else if(mInputMethodIndex == CommonData.MODE_QWERTY) {
            	if (mHangulQwerty == null) {
            		Log.e(TAG, "initHangulComposingState() mHangulQwerty is null. return");
            		return;
            	}
                mHangulQwerty.DioHangulClearState();
            } else if(mInputMethodIndex == CommonData.MODE_HALF_QWERTY) {
            	if (mHangulHalfQwerty == null) {
            		Log.e(TAG, "initHangulComposingState() mHangulHalfQwerty is null. return");
            		return;
            	}
                mHangulHalfQwerty.DioHangulClearState();
            }
        }
    }

    private void updateCandidates() {
        if (DEBUG) Log.d(TAG, "updateCandidates");
        if (!mCompletionOn) {
            if (mComposing.length() > 0) {
                ArrayList<CharSequence> list = new ArrayList<CharSequence>();
                list.add(mComposing.toString());
                setSuggestions(list, true, true);
            } else {
                setSuggestions(null, false, false);
            }
        }
    }

//    private void handleSeparator(int primaryCode) {
//        // Handle separator
//        if (DEBUG) Log.e(TAG," handleSeparator ");
//        InputConnection ic = getCurrentInputConnection();
//        if (ic != null) {
//            ic.beginBatchEdit();
//        }
//
//        if (ic != null) {
//            ic.endBatchEdit();
//        }
//    }

    private void handleClose() {
        commitTyped(getCurrentInputConnection());
        requestHideSelf(0);
        if(mInputView != null)
            mInputView.closing();
    }

    private void checkToggleCapsLock() {
        if (mInputView.getKeyboard().isShifted()) {
            toggleCapsLock();
        }
    }

    private void toggleCapsLock() {
        mCapsLock = !mCapsLock;
        if (mIMESwitcher.isAlphabetMode()) {
            ((DioComKeyboard) mInputView.getKeyboard()).setShiftLocked(mCapsLock);
        }
    }
    
    public boolean isCapsLock() {
    	return mCapsLock;
    }
    
    public boolean isCandidateView()
    {
    	if(mCandidateView != null) return true;
    	else return false;
    }

//    private void updateSuggestions() {
//
//    }

//    private void pickDefaultSuggestion() {
//        // Complete any pending candidate query first
//
//    }

    public void pickSuggestionManually(int index, CharSequence suggestion) {
        if (DEBUG) Log.d(TAG, "pickSuggestionManually()");

        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        
        if(mUnistroke && mCands) {
            if(DEBUG) Log.d(TAG, "suggestion.charAt(0): " + suggestion.charAt(0));
            
            if(!isHangulJaso(suggestion.charAt(0)) && !Character.isLetter(suggestion.charAt(0))) {
                if( mCandidateView != null ) {
                    mCandidateView.setSuggestions(null, false, false, (byte)mBestWordIdx);
                }
            }
            onKey(suggestion.charAt(0), null);
            mUnistroke = false;
            return;
        }

        if( mCompletionOn ) {
            CompletionInfo ci = mCompletions[index];
            if( ci != null )
                ic.commitCompletion(ci);

            if( mCandidateView != null )
                mCandidateView.setSuggestions(null, false, false, (byte)mBestWordIdx);
            mPredicting = false;
            clearRecomWordInput(true);
            initHangulComposingState();
            return;
        }

        if(mInputRangeIndex != InputRangeMode.KOR.ordinal() && 
                mCands && mHwrService.bUnistroke && 
                (mInputMethodIndex == CommonData.MODE_HANDWRITING || mInputMethodIndex == CommonData.MODE_FULL_HANDWRITING)) {
            if( mComposingRecomm.length() > 0 ) {
                ic.beginBatchEdit();
//              if(mComposingRecomm.length() > 0)
                ic.commitText(mComposingRecomm, 1);
                ic.finishComposingText();
                ic.deleteSurroundingText(mComposingRecomm.length(), 0);
                ic.commitText(suggestion, 1);
                ic.endBatchEdit();

              
                mComposingRecomm.setLength(0);
                mComposing.setLength(0);

                if( mPredicting ) {
                    mPredicting = false;
                    initHangulComposingState();

                    mPredicting = false;

                    if( mAutoSpace )
                        sendKeyChar((char)0x20);

                    // Add UserDB
                    if(mCandidateView.getCandidateSelectionIndex() == 0) {
                        int [] nBestWordIdx = new int[1];
                        if(RecomWord.RW_DoSearchingWord(nBestWordIdx) >= 0) {
                            if(nBestWordIdx[0] > 0)
                                addWordToDictionary(suggestion.toString());
                        }

                    }
                    clearRecomWordInput(true);
                    if( mCandidateView != null )
                        mCandidateView.setSuggestions(null, false, false, (byte)mBestWordIdx);
                    mSuggestions.clear();
                }
            }
            return;
        }

        if( mComposing.length() > 0 ) {
            ic.commitText(suggestion,1);
            mComposing.setLength(0);

            if( mPredicting ) {
                mPredicting = false;
                initHangulComposingState();

                mPredicting = false;

                if( mAutoSpace )
                    sendKeyChar((char)0x20);

                // Add UserDB
                if(mCandidateView.getCandidateSelectionIndex() == 0) {
                    int [] nBestWordIdx = new int[1];
                    if(RecomWord.RW_DoSearchingWord(nBestWordIdx) >= 0) {
                        if(nBestWordIdx[0] > 0)
                            addWordToDictionary(suggestion.toString());
                    }
                    
                }
                clearRecomWordInput(true);
                if( mCandidateView != null )
                    mCandidateView.setSuggestions(null, false, false, (byte)mBestWordIdx);
                mSuggestions.clear();
            }
            //mCandidateView.setSuggestions(null, false, false, (byte)0);
        }
    }

    public boolean addWordToDictionary(String word) {
        if( mUserDictionary == null ) return false;

        if(mUserDictionary.isValidWord(word) == false) {
            mUserDictionary.addWord(word, 128);
            if(DEBUG) Log.i(TAG,"addWordToDictionary:addWord=" + word);
            return true;
        }

        return false;
    }

    public void setSuggestions(List<CharSequence> suggestions, boolean completions,
            boolean typedWordValid, boolean bCands) {
        if (DEBUG) Log.d(TAG, "setSuggestions()");

        mCands = bCands;
        
        mUnistroke = true;
        if(!bCands) {
            setComposingText(suggestions.get(0));
            return;
        }
        
        mUnistroke = true;
        setSuggestions(suggestions, completions, typedWordValid);
    }
    
    public boolean getUnistroke() {
        return mUnistroke;
    }
    
    public void setSuggestions(List<CharSequence> suggestions, boolean completions,
            boolean typedWordValid) {
        if (DEBUG) Log.d(TAG, "setSuggestions()");
        
        InputConnection ic = getCurrentInputConnection();
        if(ic == null){
            if (DEBUG) Log.e(TAG,"setSuggestions: getCurrentInputConnection() is null");
            return;
        }
        
        if (mCandidateView == null)
            return;
        
        mCandidateView.setSuggestions(suggestions, completions, typedWordValid, (byte)0);

        if (suggestions != null && suggestions.size() > 0) {
            if(mUnistroke || mCands) {
                String strComposing;
                if(mComposing.length() > 0) {
                    ic.deleteSurroundingText(mComposing.length(), 0);
                    mComposingRecomm.append(mComposing.toString());
                }
                mComposingRecomm.append(suggestions.get(0));
                if (mComposingRecomm.length() > 0) {
                    commitComposingText();
//                    ic.finishComposingText();
                }
//                setComposing(suggestions.get(0));
//                commitComposingText();
            } else {
                if (mComposing.length() > 0) {
                    commitComposingText();
                    ic.finishComposingText();
                }
                setComposing(suggestions.get(0));
                commitComposingText();
            }
            setCandidatesViewShown(true);
        } else {
            //setCandidatesViewShown(false);
        }

        updateShiftKeyState(getCurrentInputEditorInfo());
    }

    public void commitComposingText() {
        InputConnection ic = getCurrentInputConnection();
        if(ic == null){
            if (DEBUG) Log.e(TAG,"setSuggestions: getCurrentInputConnection() is null");
            return;
        }

        if(mUnistroke || mCands) {
//            String strComposing = mComposingRecomm.toString() + mComposing.toString();
            ic.beginBatchEdit();
//            if(mComposingRecomm.length() > 0)
            ic.commitText(mComposingRecomm, 1);
            ic.finishComposingText();
            ic.deleteSurroundingText(mComposingRecomm.length(), 0);
            ic.setComposingText(mComposingRecomm, 1);
            ic.endBatchEdit();
        } else {
            ic.setComposingText(mComposing,1); //CURSOR_POS_ERROR
        }
    }

    public boolean setComposingText(CharSequence charSequence) {
        // TODO Auto-generated method stub
        if(DEBUG) Log.d(TAG, "setComposingText charSequence: " +charSequence);

        if(charSequence == null && mCandidateView != null) return false;

        InputConnection ic = getCurrentInputConnection();
        if( ic == null || charSequence == null) return false;

        if( isPredictionOn() && ((RecomWord.RW_INPUT_STRING_LENGTH()+1) >= RecomWord.MAX_WORD_LEN)) {
            ic.finishComposingText();
            ic.commitText(charSequence, 1);
            mComposing.setLength(0);
            clearRecomWordInput(true);
            mCandidateView.setSuggestions(null, true, true, (byte)0 );
            mPredicting = false;
        } else {
            int nInputRange = -1;
            if(isHangulJaso(charSequence.charAt(0))) {
                nInputRange = InputRangeMode.KOR.ordinal();
            } else if(Character.isLetter(charSequence.charAt(0))) {
                nInputRange = InputRangeMode.ENG.ordinal();
            }
            
            
            if( isPredictionOn() && (mInputRangeIndex == InputRangeMode.ENG.ordinal() || nInputRange == InputRangeMode.ENG.ordinal()) 
                    && charSequence.toString().length() < RecomWord.MAX_WORD_LEN ) {
                for( int i = 0 ; i < charSequence.length() ; i++ ) {
                    doRecomWordInputChar((char)charSequence.charAt(i), null);
                    mComposing.append(charSequence.charAt(i));
                }

                if( doRecomWordSearching(mSuggestions) > 0 ) {
                    if(mHwrService.bUnistroke && mCands) {
                        ic.setComposingText(mComposingRecomm, 1);
                    } else {
                        ic.setComposingText(mComposing, 1);
                    }
                    mCandidateView.setSuggestions(mSuggestions, true, true, (byte)mBestWordIdx );
                    setCandidatesViewShown(true);
                    mPredicting = true;
                } else {
                    ic.commitText(mComposing, 1);
                }
                
            } else if( isPredictionOn() && (mInputRangeIndex == InputRangeMode.KOR.ordinal() || nInputRange == InputRangeMode.KOR.ordinal()) 
                    && charSequence.toString().length() < RecomWord.MAX_WORD_LEN ) {
                
                mComposing.append(charSequence);

                char[] strWordBuf = new char [RecomWord.MAX_WORD_LEN];
                String strInput = mComposing.toString();
                strInput.getChars(0, strInput.length(), strWordBuf, 0);
                
                if( doRecomWordInputWord(strWordBuf) > 0 ) {
                    if( doRecomWordSearching(mSuggestions) > 0 ) {
                        ic.setComposingText(mComposing, 1);
                        mCandidateView.setSuggestions(mSuggestions, true, true, (byte)mBestWordIdx);
                        setCandidatesViewShown(true);
                        mPredicting = true;
                    } else {
                        ic.commitText(mComposing, 1);
                    }
                }
            } else {
                ic.finishComposingText();
                ic.commitText(charSequence, 1);
                mComposing.setLength(0);
                mPredicting = false;
            }
        }

        return true;
    }

    public boolean setComposingJaso(int keyCode) {
        handleCharacter(keyCode, null);
        return true;
    }

    /**
     *    set InputMethod Index
     */
    public void setInputMethodIndex(int index) {
    	mInputMethodIndex = index;
    }

    /**
     *    get InputMethod Index
     *    @return    IM Index
     */
    public int getInputMethodIndex() {
        return mInputMethodIndex;
    }

    public void setInputRangeIndex(int index) {
        mInputRangeIndex = index;
    }

    public int getInputRangeIndex() {
        return mInputRangeIndex;
    }

    DialogInterface.OnClickListener onPopupCancelListener = new OnClickListener() {
        public void onClick(DialogInterface arg0, int arg1) {
            mInputView.invalidateAll();
        }
    };

    /**
     *    change InputMethod
     */
    private void changeInputMethod(int index) {
        if (DEBUG) Log.d(TAG,"changeInputMethod : index : "+index);

//        // dhlee 2010/03/23 [setting 제거]
//        if(index >= CommonData.KeyboardIM.length -1) {
//            launchSettingsMenu();
//            return; 
//        }

        // RESTORE_INPUT_METHOD
        SharedPreferences mySharedPref = this.getSharedPreferences(PREF_RESTORE_INPUTMETHOD,
                                                  Activity.MODE_PRIVATE);
        SharedPreferences.Editor editor = mySharedPref.edit();
        int nIndex = index;


        
        if(editor != null){
            editor.putInt(PREF_RESTORE_INPUTEMTHOD_KEY, CommonData.MODES[nIndex]);
            editor.commit();
        }

        mInputMethodIndex = CommonData.MODES[nIndex];

        mSymPage = 0;
        setSymbolPage(mSymPage);
        mIMESwitcher.setKeyboardMode(mHwrService.bUnistroke); // ejjeon 2010/08/27 united unistroke test
        
        if(mComposing.length() > 0) {
            InputConnection ic = getCurrentInputConnection();
            if( ic != null )
                ic.finishComposingText();
            mComposing.setLength(0);
        }
        
        initHangulComposingState();
        clearRecomWordInput(true);
        mSuggestions.clear();
        if( mCandidateView != null )
            mCandidateView.setSuggestions(null, true, true, (byte)0);
        mPredicting = false;
        setCandidatesViewShown(false);
        initShiftKeyState();
    }

    // dhlee 2010/03/10 [Domain list]
    public void launchDomainList() {
        if(DEBUG) Log.d(TAG,"launchDomainList");

        AlertDialog.Builder Dialog = new AlertDialog.Builder(this);
        Dialog.setCancelable(true);
        Dialog.setNegativeButton(android.R.string.cancel, null);
        Dialog.setItems(CommonData.domainList,
                new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface di, int position){
                InputConnection ic = getCurrentInputConnection();
                ic.commitText(CommonData.domainList[position], 1);
                return;
            }
        }
        );
        
        dialogShow(Dialog, getResources().getString(R.string.label_domain_list_title)); // dhlee 2010/03/10 [공통모듈 처리]
    }
    
    private void showInputMethodSelectOptionMenu() {
        AlertDialog.Builder Dialog = new AlertDialog.Builder(this);
        Dialog.setCancelable(true);
        Dialog.setNegativeButton(android.R.string.cancel, onPopupCancelListener);
        
        int nInputMethodIndex = 0;
        for (int i=0;i<CommonData.MODES.length;i++){
 
        	if (CommonData.MODES[i] == mInputMethodIndex) {
        		nInputMethodIndex = i;
        	}
        }

        Dialog.setSingleChoiceItems(mKeyboaerList , nInputMethodIndex,
                new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface di, int position){
                changeInputMethod(position);
                di.dismiss();
                return;
            }
        }
        );

        dialogShow(Dialog, getResources().getString(R.string.label_ime_title)); // dhlee 2010/03/10 [공통모듈 처리]
    }

    public void launchSettingsMenu() {
        if(DEBUG) Log.d(TAG,"launchSettingsMenu");
        Intent intent = new Intent();
        intent.setClass(this, DiopenSettings.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        this.startActivity(intent);
        hideWindow();
    }

    private void launchInputRangeSelectOptionMenu() {
        if(DEBUG) Log.d(TAG,"launchInputRangeSelectOptionMenu");

        int nInputRangeList = 0;

        int nInputRangeIndex = mInputRangeIndex;
        if(mInputMethodIndex == CommonData.MODE_QWERTY 
                || mInputMethodIndex == CommonData.MODE_HALF_QWERTY) {
            nInputRangeList = InputRangeMode.getMax();
            if(nInputRangeIndex == InputRangeMode.SYM.ordinal())
                nInputRangeIndex = InputRangeMode.NUM.ordinal();
        } else {
            nInputRangeList = InputRangeMode.getMax() + 1;
        }

        String[] InputRangeList = new String[nInputRangeList];
        String strInputRangeName;

        int nTemp = 0;
        for(int i=0; i< nInputRangeList; i++) {
            nTemp = i;
            if(mInputMethodIndex == CommonData.MODE_QWERTY) {
                if(i == InputRangeMode.NUM.ordinal()) nTemp = InputRangeMode.SYM.ordinal();
            }

            if( mLocale.regionMatches(true, 0, "ko", 0, 2) ) {
                strInputRangeName = (InputRangeMode.values())[nTemp].getKorName();
            }else {
                strInputRangeName = (InputRangeMode.values())[nTemp].getEngName();
            }

            if(mInputMethodIndex == CommonData.MODE_QWERTY && 
                    i == InputRangeMode.NUM.ordinal()) {
                strInputRangeName = getResources().getString(R.string.label_sip_numsym);
            }

            InputRangeList[i] = strInputRangeName;
        }

        AlertDialog.Builder Dialog = new AlertDialog.Builder(this);
        Dialog.setCancelable(true);
        Dialog.setNegativeButton(android.R.string.cancel, null);
        Dialog.setSingleChoiceItems(InputRangeList , nInputRangeIndex,
                new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface di, int position){
                changeInputRange(position);
                di.dismiss();
                return;
            }
        }
        );

        dialogShow(Dialog, getResources().getString(R.string.label_sip_title)); // dhlee 2010/03/10 [공통모듈 처리]
    }

    private void dialogShow(AlertDialog.Builder Dialog, String strTitle) {
        Dialog.setTitle(strTitle);
        mOptionDlg = Dialog.create();
        Window win = mOptionDlg.getWindow();
        WindowManager.LayoutParams wlp = win.getAttributes();
        wlp.token = mInputView.getWindowToken();
        wlp.type = WindowManager.LayoutParams.TYPE_APPLICATION_ATTACHED_DIALOG;
        mOptionDlg.show();
        
        return;
    }

    private void setKeyboardList() {
        if (DEBUG) Log.d(TAG,"setKeyboardList");

        CommonData.KeyboardIM.add(getResources().getString(R.string.label_ime_qwerty));
        CommonData.KeyboardIM.add(getResources().getString(R.string.label_ime_keypad_sky2));
        CommonData.KeyboardIM.add(getResources().getString(R.string.label_ime_keypad_cji));
        CommonData.KeyboardIM.add(getResources().getString(R.string.label_ime_keypad_nara));
        CommonData.KeyboardIM.add(getResources().getString(R.string.label_ime_keypad_moto));
        CommonData.KeyboardIM.add(getResources().getString(R.string.label_ime_hwr));
        CommonData.KeyboardIM.add(getResources().getString(R.string.label_ime_full_hwr));
        CommonData.KeyboardIM.add(getResources().getString(R.string.label_ime_half_qwerty));
        
        mKeyboaerList = new CharSequence[CommonData.MODES.length];
        for (int i=0;i<CommonData.MODES.length;i++) {
            mKeyboaerList[i] = CommonData.KeyboardIM.get(CommonData.MODES[i]);
        }
    }

    private void changeInputRange(int index) {
        if (DEBUG) Log.i(TAG,"changeLanguage index : " + index);

        if( index == mInputRangeIndex ) return;

        mInputRangeIndex = index;

        mSymPage = 0;
        setSymbolPage(mSymPage);
        mIMESwitcher.setKeyboardMode(mHwrService.bUnistroke); // ejjeon 2010/08/27 united unistroke test
        
        if(mComposing.length() > 0) {
            InputConnection ic = getCurrentInputConnection();
            ic.finishComposingText();
            mComposing.setLength(0);
        }
        
        if( isPredictionOn() ) {
            setRecomWordLanguage( index );
            clearRecomWordInput(true);
            setCandidatesViewShown(false); 
            mSuggestions.clear();
            if( mCandidateView != null )
                mCandidateView.setSuggestions(null, true, true, (byte)mBestWordIdx);
            mPredicting = false;
        }
        
        initShiftKeyState();
        initHangulComposingState();
    	if (mHwrService != null) // ejjeon 2010/08/20 united unistroke test unistroke state init 입력모드 변경될 때
    		mHwrService.setUnistrokeContextState();
    }

    private void changeNumSymPage(int code) {
        int nMaxPage = 0;
        if(mInputMethodIndex == CommonData.MODE_QWERTY) {
            nMaxPage = DioKeyboardSwitcher.KBD_MODE_QWERTY_SYM_MAX;
        } else if(mInputMethodIndex == CommonData.MODE_HALF_QWERTY ) {
            nMaxPage = DioKeyboardSwitcher.KBD_MODE_HALF_QWERTY_SYM_MAX;
        } else if (mInputView.isKeypad(mInputMethodIndex)) {
            nMaxPage = DioKeyboardSwitcher.KBD_MODE_KEYPAD_SYM_MAX;
        } else if (mInputMethodIndex == CommonData.MODE_PHONE_NUMBER) {
            nMaxPage = DioKeyboardSwitcher.KBD_MODE_PHONE_NUM_MAX;
        }

        if(code == CommonData.KEYCODE_SYMBOL_RARROW) {
            mSymPage++;
            if(mSymPage > nMaxPage-1)
                mSymPage = 0;
        } else if(code == CommonData.KEYCODE_SYMBOL_LARROW) {
            mSymPage--;
            if(mSymPage < 0)
                mSymPage = nMaxPage-1;
        }

        setSymbolPage(mSymPage);
        mIMESwitcher.setKeyboardMode(mHwrService.bUnistroke); // ejjeon 2010/08/27 united unistroke test
    }

    public void setSymbolPage(int symPage) {
        mSymPage = symPage;
    }

    public int getSymbolPage() {
        return mSymPage;
    }

    public void setComposing(CharSequence vComposerStr) {
        if (DEBUG) Log.d(TAG, "setComposing vComposerStr : "+vComposerStr);
        mComposing.setLength(0);
        mComposing.append(vComposerStr);
    }

    private void updateRingerMode() {
        if (mAudioManager == null) {
            mAudioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        } else {
            mSilentMode = (mAudioManager.getRingerMode() != AudioManager.RINGER_MODE_NORMAL);
        }
    }

    private void playKeyClick(int primaryCode) {
        // if mAudioManager is null, we don't have the ringer state yet
        // mAudioManager will be set by updateRingerMode
        if (mInputView != null) {
            updateRingerMode();
        }
        
        if (mSoundOn && !mSilentMode) {
            // FIXME: Volume and enable should come from UI settings
            // FIXME: These should be triggered after auto-repeat logic
            int sound = AudioManager.FX_KEYPRESS_STANDARD;
            switch (primaryCode) {
                case CommonData.KEYCODE_COMMON_BACKSPACE://Keyboard.KEYCODE_DELETE:
                    sound = AudioManager.FX_KEYPRESS_DELETE;
                    break;
                case CommonData.KEYCODE_COMMON_ENTER://KEYCODE_ENTER:
                    sound = AudioManager.FX_KEYPRESS_RETURN;
                    break;
                case CommonData.KEYCODE_COMMON_SPACE://KEYCODE_SPACE:
                    sound = AudioManager.FX_KEYPRESS_SPACEBAR;
                    break;
            }
            mAudioManager.playSoundEffect(sound, FX_VOLUME);
        }
    }

    private void vibrate() {
        if (!mVibrateOn) {
            return;
        }
        if (mVibrator == null) {
            mVibrator = (Vibrator)getSystemService(Context.VIBRATOR_SERVICE);
        }
        mVibrator.vibrate(mVibrateDuration);
    }


    private boolean mRwdUseRecomWord;
    private boolean mRwdUseRecomWordBackup;
    private boolean mRwdWordCompletion;
    private boolean mRwdWordCorrection;
    private boolean mRwdSpellCheck;
    private boolean mRwdAutoAppendToUDB;
    private boolean mRwdJasoSrch;
    private byte    mRwdInputLimit;
    private static final String PREF_RWD_USE_WORD_RECOMMENDATION = "use_word_recommendation";
    private static final String PREF_RWD_WORD_COMPLETION = "word_completion";
    //private static final String PREF_RWD_WORD_CORRECTION = "word_correction";
    private static final String PREF_RWD_SPELL_CHECK = "spell_check";
    //private static final String PREF_RWD_AUTO_APPEND_TO_UDB = "auto_append_to_udb";
    private static final String PREF_RWD_JASO_SRCH = "hangul_jaso_srch";
    //private static final String PREF_RWD_INPUT_LIMIT_POINT = "set_input_limit";

    private void rwdUpdateSettings() {
        if (DEBUG) Log.i(TAG,"[RWD] rwdUpdateSettings");

        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this);

        mRwdUseRecomWord = sp.getBoolean(PREF_RWD_USE_WORD_RECOMMENDATION, true);
        mRwdUseRecomWordBackup = mRwdUseRecomWord;
        mRwdWordCompletion = sp.getBoolean(PREF_RWD_WORD_COMPLETION, true);
        mRwdWordCorrection = true; //sp.getBoolean(PREF_RWD_WORD_CORRECTION, false);
        mRwdSpellCheck = sp.getBoolean(PREF_RWD_SPELL_CHECK, true);
        mRwdAutoAppendToUDB = true; //sp.getBoolean(PREF_RWD_AUTO_APPEND_TO_UDB, false);
        mRwdJasoSrch = sp.getBoolean(PREF_RWD_JASO_SRCH, true);
        mRwdInputLimit = 1; //(byte) Integer.parseInt(sp.getString(PREF_RWD_INPUT_LIMIT_POINT, "1"));

        if (DEBUG) {
            Log.i(TAG,"[RWD] mRwdUseRecomWord : " + mRwdUseRecomWord);
            Log.i(TAG,"[RWD] mRwdWordCompletion : " + mRwdWordCompletion);
            Log.i(TAG,"[RWD] mRwdWordCorrection : " + mRwdWordCorrection);
            Log.i(TAG,"[RWD] mRwdSpellCheck : " + mRwdSpellCheck);
            Log.i(TAG,"[RWD] mRwdAutoAppendToUDB : " + mRwdAutoAppendToUDB);
            Log.i(TAG,"[RWD] mRwdJasoSrch : " + mRwdJasoSrch);
            Log.i(TAG,"[RWD] mRwdInputLimit : " + mRwdInputLimit);
        }
        
        RecomWord.RW_SetMinLimit(mRwdInputLimit);
        RecomWord.RW_SetOptionWordCompletion(mRwdWordCompletion);
        RecomWord.RW_SetOptionWordCorrection(mRwdWordCorrection);
        RecomWord.RW_SetOptionSpellCheck(mRwdSpellCheck);

        RecomWord.RW_SetOptionHangulJasoSrch(mRwdJasoSrch);
        RecomWord.RW_SetOptionAutoAppendToUDB(mRwdAutoAppendToUDB);
    }

    private int    mHwrRecogTime;
    private int    mHwrPenColor;
    private int    mHwrPenThickness;
    private static final String PREF_HWR_RECOG_TIME = "set_hwr_recog_time";
    private static final String PREF_HWR_PEN_COLOR = "set_hwr_pen_color";
	private static final String PREF_HWR_PEN_THICKNESS = "set_hwr_pen_thickness";


    private void hwrUnistrokeUpdateSettings() {
        if (DEBUG) Log.d(TAG,"[HWR] hwrUnistrokeUpdateSettings");

        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences mySharedPref = this.getSharedPreferences(PREF_RESTORE_INPUTMETHOD, Activity.MODE_PRIVATE);

        // ejjeon 2010/08/12 united unistroke test { getBoolean, getInt 의 두번째 인자의 값이 초기값임
        if(mHwrService != null) {
            mHwrService.bUnistroke = sp.getBoolean("unistroke", true);
            mHwrService.bUnistrokeCand = sp.getBoolean("unistroke_cand", true);
            mHwrService.setUnistrokeContextState(sp.getBoolean("check_context", true)); // context setting 정보 변경시
            mHwrService.setShift(sp.getBoolean("han_shift", true), sp.getBoolean("eng_shift", true), sp.getBoolean("num_shift", true), (byte)mySharedPref.getInt(PREF_RESTORE_SHIFT_DIRECTION, DHWR.DHWR_SHIFT_DIRECT_LEFT), (byte)mySharedPref.getInt(PREF_RESTORE_SHIFT_RANGE, 25));
            int[][] numShiftValue = new int[10][1];
            numShiftValue[0][0] = mySharedPref.getInt(PREF_RESTORE_SHIFT_NUM0, ')');
            numShiftValue[1][0] = mySharedPref.getInt(PREF_RESTORE_SHIFT_NUM1, '!');;
            numShiftValue[2][0] = mySharedPref.getInt(PREF_RESTORE_SHIFT_NUM2, '@');;
            numShiftValue[3][0] = mySharedPref.getInt(PREF_RESTORE_SHIFT_NUM3, '#');;
            numShiftValue[4][0] = mySharedPref.getInt(PREF_RESTORE_SHIFT_NUM4, '$');;
            numShiftValue[5][0] = mySharedPref.getInt(PREF_RESTORE_SHIFT_NUM5, '%');;
            numShiftValue[6][0] = mySharedPref.getInt(PREF_RESTORE_SHIFT_NUM6, '^');;
            numShiftValue[7][0] = mySharedPref.getInt(PREF_RESTORE_SHIFT_NUM7, '&');;
            numShiftValue[8][0] = mySharedPref.getInt(PREF_RESTORE_SHIFT_NUM8, '*');;
            numShiftValue[9][0] = mySharedPref.getInt(PREF_RESTORE_SHIFT_NUM9, '(');;
            mHwrService.setNumShiftValue(numShiftValue);
        }
        // ejjeon 2010/08/12 united unistroke test }
    }

    private void hwrUpdateSettings() {
        if (DEBUG) Log.d(TAG,"[HWR] hwrUpdateSettings");

        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this);

        mHwrRecogTime = Integer.parseInt(sp.getString(PREF_HWR_RECOG_TIME, "500"));
        if (DEBUG) Log.d(TAG,"[HWR] mHwrRecogTime: " +mHwrRecogTime);
        mHwrPenColor = Integer.parseInt(sp.getString(PREF_HWR_PEN_COLOR, "2"));
        if (DEBUG) Log.d(TAG,"[HWR] mHwrPenColor: " +mHwrPenColor);
        mHwrPenThickness = Integer.parseInt(sp.getString(PREF_HWR_PEN_THICKNESS, "5"));
        if (DEBUG) Log.d(TAG,"[HWR] mHwrPenThickness: " +mHwrPenThickness);
    }

    public int getSettingHwrRecogTime() {
        if (DEBUG) Log.d(TAG,"[HWR] getSettingHwrRecogTime");
        return mHwrRecogTime;
    }

    public int getSettingHwrPenColor() {
        if (DEBUG) Log.d(TAG,"[HWR] getSettingHwrPenColor");
        return CommonData.HWR_PEN_COLOR[mHwrPenColor];
     }

    public int getSettingHwrPenThickness() {
        if (DEBUG) Log.d(TAG,"[HWR] getSettingHwrPenThickness");
        return CommonData.HWR_PEN_THICKNESS[mHwrPenThickness];
    }

    private void clearRecomWordInput(boolean bAll) {
        if(CommonData.USE_RWD) {
            if( bAll == true ) {
                RecomWord.RW_ClearInputStringAll();
            }else {
                RecomWord.RW_ClearInputStringOne();
            }
        }
    }
    
    private int setRecomWordLanguage(int langIndex) {

        if (DEBUG) Log.i(TAG,"rwdSetLanguage langIndex : "+langIndex);
        int ret = -1;

        if (langIndex == InputRangeMode.KOR.ordinal()) {
            ret = RecomWord.RW_SetLanguage(RecomWord.RWD_LANG_KOR);
        } else {
            ret = RecomWord.RW_SetLanguage(RecomWord.RWD_LANG_ENG_US);
        }

        if (DEBUG) Log.i(TAG,"[RWD] rwdSetLanguage : ret=" + ret );

        return ret;
    }

    // input single char
    private int doRecomWordInputChar( char inputChar, char[] regionArray) {
        if (DEBUG) Log.i(TAG,"doRecomWordInputChar:strInput=" + inputChar);
        
        int nRet = 0;
        
        if( inputChar != 0x08 ) {
            nRet = RecomWord.RW_DoInputString(inputChar, regionArray);
            if( nRet < 0 ){
                if(DEBUG) Log.i(TAG,"doRecomWordInputChar:DoInputString-nRet=" + nRet );
                return 0;
            }
        }
        
        return 1;
    }

    // input word. use KOREAN
    private int doRecomWordInputWord( char[] inputWord ) {
        int nRet = RecomWord.RW_DoInputStringWord(inputWord);
        if( nRet < 0 ) {
            if(DEBUG) Log.i(TAG, "doRecomWordInputWord:DoInputStringWord-nRet=" + nRet );
            return 0;
        }
        
        return 1;
    }

    // do searching
    private int doRecomWordSearching( List<CharSequence> candList ) {
        int [] nBestWordIdx = new int[1];
        //int nWordNum = RecomWord.RW_DoSearchingWord(nBestWordIdx);
        int nWordNum = RecomWord.RW_DoSearchingWord(nBestWordIdx);
        
        // save a value of the nBestWrodIdx to the mBestWordIdx
        if(isPredictionOn() && mInputRangeIndex == InputRangeMode.ENG.ordinal()) {
        	mBestWordIdx = nBestWordIdx[0];
        }
        else if(isPredictionOn() && mInputRangeIndex == InputRangeMode.KOR.ordinal()){
        	mBestWordIdx = 0;
        }
        
        
        if(DEBUG) Log.i(TAG,"rwdSearing:nWordNum=" + nWordNum );
        
        if( nWordNum <= 0 ) {
            //nBestWordIdx = null;
            if(DEBUG) Log.i(TAG, "rwdSearing:DoSearchingWord-nWordNum=" + nWordNum );
            return 0;
        }
        
        char[][] strResult = new char[nWordNum][RecomWord.MAX_WORD_LEN];
        int nRet = RecomWord.RW_GetResultList(strResult, nWordNum);
        
        if( nRet < 0 ) {
            //nBestWordIdx = null;
            strResult = null;
            if(DEBUG) Log.i(TAG, "rwdSearing:GetResultList-nRet=" + nRet);
            return 0;
        }
        
        candList.clear();
        //candList.add(0, "a");
        
        mWord.reset();
        mUDBList.clear();
        
        int nNumUserDic = 0;
        int nFirstIdx = 0;

        // search UDB & append list
        if( mWord != null && mUDBList != null ) {
            if(mHwrService.bUnistroke && mCands) {
                for(int j = 0; j < mComposingRecomm.length(); j++) {
                    int[] codes = new int[2];

                    codes[0] = mComposingRecomm.charAt(j);
                    if(Character.isLowerCase(mComposingRecomm.charAt(j))) {
                        codes[1] = Character.toUpperCase(mComposingRecomm.charAt(j));
                    } else if(Character.isUpperCase(mComposingRecomm.charAt(j))) {
                        codes[1] = Character.toLowerCase(mComposingRecomm.charAt(j));
                    } else {
                        codes[1] = -1;
                    }
                    mWord.add(mComposingRecomm.charAt(j), codes);
                }
            } else {
                for(int j = 0; j < mComposing.length(); j++) {
                    int[] codes = new int[2];

                    codes[0] = mComposing.charAt(j);
                    if(Character.isLowerCase(mComposing.charAt(j))) {
                        codes[1] = Character.toUpperCase(mComposing.charAt(j));
                    } else if(Character.isUpperCase(mComposing.charAt(j))) {
                        codes[1] = Character.toLowerCase(mComposing.charAt(j));
                    } else {
                        codes[1] = -1;
                    }
                    mWord.add(mComposing.charAt(j), codes);
                }
            }

            mUDBList = mSuggest.getSuggestions(mInputView, mWord, false);

            if( mUDBList.isEmpty() == false ) {
                nNumUserDic = mUDBList.size();
                for(int k = 0; k < nNumUserDic; k++){
                    candList.add(k, mUDBList.get(k));
                }
            }
            nFirstIdx = 1;
        }

        for(int i = nFirstIdx ; i < nWordNum ; i++) {
            String strWord ="";
            for(int j = 0; j < RecomWord.MAX_WORD_LEN; j++){
                if(strResult[i][j] == 0x0000){
                    break;
                }
                strWord += strResult[i][j];
            }
            if (DEBUG) Log.i(TAG,"[RWD] (" + i + ") " + strWord);
            candList.add(nNumUserDic + i - nFirstIdx, strWord);

            strWord = null;
        }

        if (candList.size() < 2) {
        	mBestWordIdx = 0;
            return candList.size();
        }

        List<CharSequence> strPool = new ArrayList<CharSequence>();

        int i = 1;
        // Don't cache suggestions.size(), since we may be removing items
        while (i < candList.size()) {
            final CharSequence cur = candList.get(i);
            // Compare each candidate with each previous candidate
            for (int j = 0; j < i; j++) {
                CharSequence previous = candList.get(j);
                if (TextUtils.equals(cur, previous)) {
                    CharSequence garbage = candList.remove(i);
                    if (garbage != null && garbage instanceof StringBuilder) {
                        strPool.add(garbage);
                    }
                    i--;
                    break;
                }
            }
            i++;
        }
        
        strPool = null;
        //nBestWordIdx = null;
        strResult = null;
        
        return nWordNum;
    }
    private int handleShiftHardKey(int key)
    {
    	int ret = key;
    	switch(ret)
    	{
    	case 59: case 60:
			ret = CommonData.KEYCODE_COMMON_SHIFT;
    	}    	
    	return ret;
    }
    
	public boolean RightShiftInputRange(){
		
		if(mInputMethodIndex == CommonData.MODE_HALF_QWERTY 
				|| mInputMethodIndex == CommonData.MODE_HANDWRITING
				|| mInputMethodIndex == CommonData.MODE_FULL_HANDWRITING){
			return false;
		}
		int nInputRange = mInputRangeIndex;
	    
		  if(CommonData.ONLY_ENGLISH) {
		      if(mInputMethodIndex == CommonData.MODE_QWERTY) {
		          if( mInputRangeIndex == InputRangeMode.ENG.ordinal() ) {
		              nInputRange = InputRangeMode.SYM.ordinal();
		          } else if( mInputRangeIndex == InputRangeMode.NUM.ordinal() || mInputRangeIndex == InputRangeMode.SYM.ordinal()) {
		              nInputRange = InputRangeMode.ENG.ordinal();
		          } 
		      } else {
		          if( mInputRangeIndex == InputRangeMode.ENG.ordinal() ) {
		              nInputRange = InputRangeMode.NUM.ordinal();
		          } else if( mInputRangeIndex == InputRangeMode.NUM.ordinal() ) {
		              nInputRange = InputRangeMode.SYM.ordinal();
		          } else if( mInputRangeIndex == InputRangeMode.SYM.ordinal() ) {
		              nInputRange = InputRangeMode.ENG.ordinal();
		          }
		      }
		  } else {
		      if(mInputMethodIndex == CommonData.MODE_QWERTY) {
		          if( mInputRangeIndex == InputRangeMode.KOR.ordinal() ) {
		              nInputRange = InputRangeMode.ENG.ordinal();
		          } else if( mInputRangeIndex == InputRangeMode.ENG.ordinal() ) {
		              nInputRange = InputRangeMode.SYM.ordinal();
		          } else if( mInputRangeIndex == InputRangeMode.NUM.ordinal() || mInputRangeIndex == InputRangeMode.SYM.ordinal()) {
		              nInputRange = InputRangeMode.KOR.ordinal();
		          } 
		      } else {
		          if( mInputRangeIndex == InputRangeMode.KOR.ordinal() ) {
		              nInputRange = InputRangeMode.ENG.ordinal();
		          } else if( mInputRangeIndex == InputRangeMode.ENG.ordinal() ) {
		              nInputRange = InputRangeMode.NUM.ordinal();
		          } else if( mInputRangeIndex == InputRangeMode.NUM.ordinal() ) {
		              nInputRange = InputRangeMode.SYM.ordinal();
		          } else if( mInputRangeIndex == InputRangeMode.SYM.ordinal() ) {
		              nInputRange = InputRangeMode.KOR.ordinal();
		          }
		      }
		  } 
		  changeInputRange( nInputRange );
		  return true;
	}
	
	public boolean LeftShiftInputRange(){
		if(mInputMethodIndex == CommonData.MODE_HALF_QWERTY 
				|| mInputMethodIndex == CommonData.MODE_HANDWRITING
				|| mInputMethodIndex == CommonData.MODE_FULL_HANDWRITING){
			return false;
		}
		int nInputRange = mInputRangeIndex;
	    
		  if(CommonData.ONLY_ENGLISH) {
		      if(mInputMethodIndex == CommonData.MODE_QWERTY
		              || mInputMethodIndex == CommonData.MODE_HALF_QWERTY) {
		          if( mInputRangeIndex == InputRangeMode.ENG.ordinal() ) {
		              nInputRange = InputRangeMode.SYM.ordinal();
		          } else if( mInputRangeIndex == InputRangeMode.NUM.ordinal() || mInputRangeIndex == InputRangeMode.SYM.ordinal()) {
		              nInputRange = InputRangeMode.ENG.ordinal();
		          } 
		      } else {
		          if( mInputRangeIndex == InputRangeMode.ENG.ordinal() ) {
		        	  nInputRange = InputRangeMode.SYM.ordinal();
		          } else if( mInputRangeIndex == InputRangeMode.NUM.ordinal() ) {
		        	  nInputRange = InputRangeMode.ENG.ordinal();
		          } else if( mInputRangeIndex == InputRangeMode.SYM.ordinal() ) {
		        	  nInputRange = InputRangeMode.NUM.ordinal();
		          }
		      }
		  } else {
		      if(mInputMethodIndex == CommonData.MODE_QWERTY
		              || mInputMethodIndex == CommonData.MODE_HALF_QWERTY) {
		          if( mInputRangeIndex == InputRangeMode.KOR.ordinal() ) {
		              nInputRange = InputRangeMode.ENG.ordinal();
		          } else if( mInputRangeIndex == InputRangeMode.ENG.ordinal() ) {
		              nInputRange = InputRangeMode.SYM.ordinal();
		          } else if( mInputRangeIndex == InputRangeMode.NUM.ordinal() || mInputRangeIndex == InputRangeMode.SYM.ordinal()) {
		              nInputRange = InputRangeMode.KOR.ordinal();
		          } 
		      } else {
		          if( mInputRangeIndex == InputRangeMode.KOR.ordinal() ) {
		        	  nInputRange = InputRangeMode.SYM.ordinal();
		          } else if( mInputRangeIndex == InputRangeMode.ENG.ordinal() ) {
		        	  nInputRange = InputRangeMode.KOR.ordinal();
		          } else if( mInputRangeIndex == InputRangeMode.NUM.ordinal() ) {
		        	  nInputRange = InputRangeMode.ENG.ordinal();
		          } else if( mInputRangeIndex == InputRangeMode.SYM.ordinal() ) {
		        	  nInputRange = InputRangeMode.NUM.ordinal();
		          }
		      }
		  } 
		  changeInputRange( nInputRange );
		  return true;
	}
}