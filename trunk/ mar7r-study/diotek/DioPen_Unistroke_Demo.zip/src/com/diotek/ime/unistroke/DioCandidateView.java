package com.diotek.ime.unistroke;

import java.util.ArrayList;
import java.util.List;

import com.diotek.ime.unistroke.R;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;

public class DioCandidateView extends View {

    private static final boolean DEBUG = CommonData.IME_DEBUG;
    private static final String TAG = "DioCandidateView";

    private static final int OUT_OF_BOUNDS = -1;
    private static final int SCROLL_PIXELS = 20;
    private static final List<CharSequence> EMPTY_LIST = new ArrayList<CharSequence>();
    public static final int MAX_SUGGESTIONS = 20;// maximum number of suggestions words...
    private static final int X_GAP = 10;
    private static final int mFixedWidth = 35;
    private static final int LAST_STRIP_SIZE = 3;
    private DioInputMethodService mService;

    private List<CharSequence> mSuggestionList = EMPTY_LIST;
    /**
     * for suggestion sub-string(Hanja hun)
     */
    private List<CharSequence> mSuggestionSubList = EMPTY_LIST;
    private boolean mIsDisplaySuggestionSubString = false;
    
    private int mSelectionIndex;
    private CharSequence mSelectionString;
    private Drawable mSelectionHighlight;
    private int mTouchPosX = OUT_OF_BOUNDS;
    //private int mCurrentWordIndex; // prevent_unused_warning
    private boolean mTypedWordValid;
    
    private int[] mSuggestionWordWidth = new int[MAX_SUGGESTIONS];
    private int[] mSuggestionWordPosX = new int[MAX_SUGGESTIONS];

    private Rect mBgPadding;
    private int mColorNormal;
    private int mColorRecommended;
    private int mColorOther;
    private int mColorStripsFirst;
    private int mColorStripsSeconds;
    private int mColorStripsThird;
    private int mVerticalPadding;
    private Paint mPaint;
    private boolean mScrolled;
    private int mTargetScrollX;
    private int mTotalWidth;
    private int mCandidateViewWidth;
    private GestureDetector mGestureDetector;
    private byte mbActiveWordIndex = 0;

    private int mLeftPostion = 0;
    
    /**
     * Construct a CandidateView for showing suggested words for completion.
     * @param context
     * @param attrs
     */
    public DioCandidateView(Context context, AttributeSet attrs) {
        super(context, attrs);
        if(DEBUG) Log.i(TAG,"DioCandidateView()");
        
        mSelectionHighlight = context.getResources().getDrawable(
                android.R.drawable.list_selector_background);
        mSelectionHighlight.setState(new int[] {
                android.R.attr.state_enabled,
                android.R.attr.state_focused,
                android.R.attr.state_window_focused,
                android.R.attr.state_pressed
        });

        Resources r = context.getResources();
        /* // prevent_unused_warning
        LayoutInflater inflate =
            (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        */
        //this.setBackgroundColor(0x000000FF);
/////////////////////////////////////////////////////////////////////////
        mColorNormal = context.getResources().getColor(R.color.candidate_normal);
        mColorRecommended = 0xFFE35900;//context.getResources().getColor(R.color.candidate_recommended);
        mColorOther = context.getResources().getColor(R.color.candidate_other);
        mColorStripsFirst     = getResources().getColor(R.color.candidate_strip_line_first);
        mColorStripsSeconds = getResources().getColor(R.color.candidate_strip_line_second);
        mColorStripsThird     = getResources().getColor(R.color.candidate_strip_line_third);;
        mPaint = new Paint();
        mPaint.setColor(mColorNormal);
        mPaint.setAntiAlias(true);
        mPaint.setTextSize(r.getDimensionPixelSize(R.dimen.candidate_font_height));
        mPaint.setStrokeWidth(0);
        mCandidateViewWidth = this.getWidth();
        
        mGestureDetector = new GestureDetector(new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onScroll(MotionEvent e1, MotionEvent e2,
                    float distanceX, float distanceY) {
                if(mTotalWidth <= mCandidateViewWidth){
                    mScrolled = true;
                    return true;
                }
                mScrolled = true;
                int sx = getScrollX();
                sx += distanceX;
                if (sx < 0) {
                    sx = 0;
                }
                if (sx + getWidth() > mTotalWidth) {
                    sx -= distanceX;
                }
                mTargetScrollX = sx;
                scrollTo(sx, getScrollY());
                updateScrollPosition(sx);
                invalidate();
                requestLayout();
                return true;
            }
        });
        setHorizontalFadingEdgeEnabled(true);
        setWillNotDraw(false);
        setHorizontalScrollBarEnabled(false);
        setVerticalScrollBarEnabled(false);
    }
    
    /**
     * A connection back to the service to communicate with the text field
     * @param listener
     */
    public void setService(DioInputMethodService listener) {
        if(DEBUG) Log.i(TAG,"setService()");
        mService = listener;
    }
    
    @Override
    public int computeHorizontalScrollRange() {
        if(DEBUG) Log.i(TAG,"computeHorizontalScrollRange()");
        return mTotalWidth;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int measuredWidth = resolveSize(50, widthMeasureSpec);
        if(DEBUG) Log.i(TAG,"CandidateView.onMeasure()");
        // Get the desired height of the icon menu view (last row of items does
        // not have a divider below)
        Rect padding = new Rect();
        mSelectionHighlight.getPadding(padding);
        final int desiredHeight = ((int)mPaint.getTextSize()) + mVerticalPadding
                + padding.top + padding.bottom;
        
        // Maximum possible width and desired height
        setMeasuredDimension(measuredWidth,
                resolveSize(desiredHeight, heightMeasureSpec));
    }

    /**
     * If the canvas is null, then only touch calculations are performed to pick the target
     * candidate.
     */
    @Override
    protected void onDraw(Canvas canvas) {
        if(DEBUG) Log.i(TAG,"onDraw()");
        if (canvas != null) {
            super.onDraw(canvas);
        }
        mTotalWidth = 0;
        mCandidateViewWidth = this.getWidth();
        if (mSuggestionList == null) return;
        
        if (mBgPadding == null) {
            mBgPadding = new Rect(0, 0, 0, 0);
            if (getBackground() != null) {
                getBackground().getPadding(mBgPadding);
            }
        }

        int x = 0;
        final int count = mSuggestionList.size(); 
        final int height = getHeight();
        final Rect bgPadding = mBgPadding;
        final Paint paint = mPaint;
        final int touchX = mTouchPosX;
        final int scrollX = getScrollX();
        final boolean scrolled = mScrolled;
        final boolean typedWordValid = mTypedWordValid;
        final int y = (int) (((height - mPaint.getTextSize()) / 2) - mPaint.ascent());

        if(count == mSuggestionSubList.size()){
            mIsDisplaySuggestionSubString = true;
        }else{
            mIsDisplaySuggestionSubString = false;
        }

        for (int i = 0; (i < count && i < MAX_SUGGESTIONS); i++) { //EXCEPTION
            float subTextWidth = 0;
            int subWordWidth = 0;
            
            CharSequence suggestion = mSuggestionList.get(i);
            CharSequence suggestionSub=null;
            if(mIsDisplaySuggestionSubString){
                suggestionSub = mSuggestionSubList.get(i);
                if(suggestionSub != null){
                    subTextWidth = paint.measureText(suggestionSub,0,suggestionSub.length());
                    subWordWidth = (int)subTextWidth + X_GAP;
                }
            }

            float textWidth = paint.measureText(suggestion,0,suggestion.length());
            int wordWidth = (int) textWidth + X_GAP * 2;

            wordWidth += subWordWidth; 
            if(wordWidth < mFixedWidth){
                wordWidth = mFixedWidth;
            }
            
            mSuggestionWordPosX[i] = x;
            mSuggestionWordWidth[i] = wordWidth;
            paint.setColor(mColorNormal);
            if (touchX + scrollX >= x && touchX + scrollX < x + wordWidth && !scrolled) {
                if (canvas != null) {
                    canvas.translate(x+1, 0);
                    mSelectionHighlight.setBounds(0, bgPadding.top, wordWidth-1, height -4);
                    mSelectionHighlight.draw(canvas);
                    canvas.translate(-(x+1), 0);
                }
                mSelectionString = suggestion;
                mSelectionIndex = i;
            }


            if (canvas != null) {
                if ((i == mbActiveWordIndex && typedWordValid)) {
                    paint.setFakeBoldText(true);
                    paint.setColor(mColorRecommended);
                }else {
                    paint.setFakeBoldText(true);
                    paint.setColor(mColorOther); 
                }

                canvas.drawText(suggestion, 0,suggestion.length(), x + X_GAP, y, paint);
                if(mIsDisplaySuggestionSubString && suggestionSub != null){
                    int textPositionX = x + X_GAP*2 + (int)textWidth;
                    canvas.drawText(suggestionSub, 0,suggestionSub.length(), textPositionX, y, paint);
                }

                int nLastIndex = (count<MAX_SUGGESTIONS)?count:MAX_SUGGESTIONS;
                if(i < nLastIndex-1) {
                    paint.setColor(mColorStripsFirst); 
                    canvas.drawLine(x + wordWidth + 0.5f, bgPadding.top, 
                            x + wordWidth + 0.5f, height -2, paint);
                    paint.setColor(mColorStripsSeconds); 
                    canvas.drawLine(x + wordWidth + 0.5f+1, bgPadding.top, 
                            x + wordWidth + 0.5f+1, height -2, paint);
                    paint.setColor(mColorStripsThird); 
                    canvas.drawLine(x + wordWidth + 0.5f+2, bgPadding.top, 
                            x + wordWidth + 0.5f+1, height -2, paint);
                }
                wordWidth += LAST_STRIP_SIZE;

                paint.setFakeBoldText(false);
            }
            x += wordWidth;
        }
        mTotalWidth = x;
        if (mTargetScrollX != getScrollX()) {
            scrollToTarget();
        }
    }
    
    public int getLeftPostion() {
        return mLeftPostion;
    }
    
    private void scrollToTarget() {
        int sx = getScrollX();
        if (mTargetScrollX > sx) {
            sx += SCROLL_PIXELS;
            if (sx >= mTargetScrollX) {
                sx = mTargetScrollX;
                requestLayout();
            }
        } else {
            sx -= SCROLL_PIXELS;
            if (sx <= mTargetScrollX) {
                sx = mTargetScrollX;
                requestLayout();
            }
        }
        scrollTo(sx, getScrollY());
        
        invalidate();
    }
    
    public void setSuggestions(List<CharSequence> suggestions, boolean completions,
            boolean typedWordValid, byte bActiveWordIndex) {
        if(DEBUG) Log.i(TAG,"setSuggestions()");
        clear();
        if (suggestions != null) {
            mSuggestionList = new ArrayList<CharSequence>(suggestions);
        }
        mTypedWordValid = typedWordValid;
        mbActiveWordIndex = bActiveWordIndex;
        scrollTo(0, 0);
        mTargetScrollX = 0;
        // Compute the total width
        onDraw(null);
        invalidate();
        requestLayout();
    }
    
    public void setSubSuggestions(List<CharSequence> suggestions){
        if(DEBUG) Log.i(TAG,"setSubSuggestions()");
        mSuggestionSubList = EMPTY_LIST;
        if (suggestions != null) {
            mSuggestionSubList = new ArrayList<CharSequence>(suggestions);
        }
    }
    
    public int getSuggestionListNum(){
        return(mSuggestionList.size());
    }

    public void scrollPrev() {
        if(DEBUG) Log.i(TAG,"scrollPrev");
        int nScrollX = getScrollX();
                
        int i = 0;
        final int count = mSuggestionList.size();
        int firstItem = 0; // Actually just before the first item, if at the boundary

        while (i < count && i < MAX_SUGGESTIONS) {//EXCEPTION
            if (mSuggestionWordPosX[i] < nScrollX // CANDIDATE_SCROLL_ERROR
                    && mSuggestionWordPosX[i] + mSuggestionWordWidth[i] >= nScrollX - 1) {
                firstItem = i;
                break;
            } else if(mSuggestionWordPosX[i] >= nScrollX) {
                firstItem = i - 1;
                if(firstItem < 0) firstItem = 0;
                break;
            }
            i++;
        }

        int leftEdge = mSuggestionWordPosX[firstItem] + mSuggestionWordWidth[firstItem] - getWidth();
        if (leftEdge < 0) leftEdge = 0;

        updateScrollPosition(leftEdge);
    }

    public void scrollNext() {
        if(DEBUG) Log.i(TAG, "scrollNext");

        int i = 0;
        int targetX = getScrollX();
        final int count = mSuggestionList.size();
        int rightEdge = targetX + getWidth();

        while (i < count && i < MAX_SUGGESTIONS) {
            if (mSuggestionWordPosX[i] <= rightEdge &&
                    mSuggestionWordPosX[i] + mSuggestionWordWidth[i] >= rightEdge) {
                targetX = Math.min(mSuggestionWordPosX[i], mTotalWidth - getWidth());
                break;
            } else {
                if(i+1 < count && i+1 < MAX_SUGGESTIONS){
                    if(mSuggestionWordPosX[i] <= rightEdge && mSuggestionWordPosX[i+1] > rightEdge){
                        targetX = Math.min(mSuggestionWordPosX[i], mTotalWidth - getWidth());
                        break;
                    }
                }
            }
            i++;
        }
        
        if(rightEdge + LAST_STRIP_SIZE  > computeHorizontalScrollRange())
            targetX = mTotalWidth - getWidth();
        
        updateScrollPosition(targetX);
    }

    /**
     * Set suggestion word index and draw candidate region.
     * @param suggestions suggestions list.
     * @param completions Word completion is or not.
     * @param typedWordValid Word type is valid/invalid.
     * @param bActiveWordIndex Suggestions word select index.
     */
    public void setMoveSuggestions(List<CharSequence> suggestions, boolean completions,
        boolean typedWordValid, byte bActiveWordIndex) {
        if(DEBUG) Log.i(TAG,"setSuggestions()");

        clear();

        if (suggestions != null) {
            mSuggestionList = new ArrayList<CharSequence>(suggestions);
        }
        mTypedWordValid = typedWordValid;
        mbActiveWordIndex = bActiveWordIndex;
        // Compute the total width
        onDraw(null);
        invalidate();
        requestLayout();
    }
    
    private void updateScrollPosition(int targetX) {
        if(DEBUG) Log.i(TAG,"updateScrollPosition");
        int mScrollX = getScrollX();
        
        if (targetX != mScrollX) {
            mTargetScrollX = targetX;
            requestLayout();
            invalidate();
            mScrolled = true;
        }
        
        mLeftPostion = mTargetScrollX;
    }
    
    public void clear() {
        if(DEBUG) Log.i(TAG,"CandidateView.clear()");
        mSuggestionList = EMPTY_LIST;
        mTouchPosX = OUT_OF_BOUNDS;
        mSelectionString = null;
        mSelectionIndex = -1;
        mLeftPostion = 0;
        invalidate();
    }
    
    @Override
    public boolean onTouchEvent(MotionEvent me) {

        if (mGestureDetector.onTouchEvent(me)) {
            return true;
        }

        int action = me.getAction();
        int x = (int) me.getX();
        int y = (int) me.getY();
        mTouchPosX = x;

        switch (action) {
        case MotionEvent.ACTION_DOWN:
            mScrolled = false;
            invalidate();
            break;
        case MotionEvent.ACTION_MOVE:
            if (y <= 0) {
                // Fling up!?
                if (mSelectionIndex >= 0) {
                    mService.pickSuggestionManually(mSelectionIndex,mSelectionString);
                    mSelectionIndex = -1;
                    mSelectionString = null;
                }
            }
            invalidate();
            break;
        case MotionEvent.ACTION_UP:
            if (!mScrolled) {
                if (mSelectionIndex >= 0) {
                    mService.pickSuggestionManually(mSelectionIndex,mSelectionString);
                }
            }
            mSelectionIndex = -1;
            mSelectionString = null;
            removeHighlight();
            requestLayout();
            break;
        }
        return true;
    }
    
    /**
     * For flick through from keyboard, call this method with the x coordinate of the flick 
     * gesture.
     * @param x
     */
    public void takeSuggestionAt(float x) {
        mTouchPosX = (int) x;
        // To detect candidate
        onDraw(null);
        if (mSelectionIndex >= 0) {
            mService.pickSuggestionManually(mSelectionIndex,mSelectionString);
        }
        invalidate();
    }

    private void removeHighlight() {
        mTouchPosX = OUT_OF_BOUNDS;
        invalidate();
    }
    /**
     * Return current suggestion word index.
     */
    public int getCandidateSelectionIndex() {
        return mSelectionIndex;
    }
}
