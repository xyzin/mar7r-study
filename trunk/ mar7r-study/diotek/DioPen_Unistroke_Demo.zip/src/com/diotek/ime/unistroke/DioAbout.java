package com.diotek.ime.unistroke;

import com.diotek.ime.unistroke.R;

import android.app.Activity;
import android.os.Bundle;

public class DioAbout extends Activity{
    @Override
	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.about);
    }
}
