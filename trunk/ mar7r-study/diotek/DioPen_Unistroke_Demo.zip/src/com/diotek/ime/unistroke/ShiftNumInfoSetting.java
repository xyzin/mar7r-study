package com.diotek.ime.unistroke;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.widget.EditText;
import android.widget.RadioGroup;

import com.diotek.dhwr.unistroke.DHWR;
import com.diotek.ime.unistroke.R;

public class ShiftNumInfoSetting extends Activity{
	EditText[] mEditText = new EditText[10];
   @Override
	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.shift_num_info);
        
        mEditText[0] = (EditText)findViewById(R.id.EditText01);
        mEditText[1] = (EditText)findViewById(R.id.EditText02);
        mEditText[2] = (EditText)findViewById(R.id.EditText03);
        mEditText[3] = (EditText)findViewById(R.id.EditText04);
        mEditText[4] = (EditText)findViewById(R.id.EditText05);
        mEditText[5] = (EditText)findViewById(R.id.EditText06);
        mEditText[6] = (EditText)findViewById(R.id.EditText07);
        mEditText[7] = (EditText)findViewById(R.id.EditText08);
        mEditText[8] = (EditText)findViewById(R.id.EditText09);
        mEditText[9] = (EditText)findViewById(R.id.EditText10);
        SharedPreferences mySharedPref = this.getSharedPreferences(DioInputMethodService.PREF_RESTORE_INPUTMETHOD, Activity.MODE_PRIVATE);
        Integer nShiftNum = mySharedPref.getInt(DioInputMethodService.PREF_RESTORE_SHIFT_NUM0, ')');
        mEditText[0].setText(String.format("%c", nShiftNum));
        nShiftNum = mySharedPref.getInt(DioInputMethodService.PREF_RESTORE_SHIFT_NUM1, '!');
        mEditText[1].setText(String.format("%c", nShiftNum));
        nShiftNum = mySharedPref.getInt(DioInputMethodService.PREF_RESTORE_SHIFT_NUM2, '@');
        mEditText[2].setText(String.format("%c", nShiftNum));
        nShiftNum = mySharedPref.getInt(DioInputMethodService.PREF_RESTORE_SHIFT_NUM3, '#');
        mEditText[3].setText(String.format("%c", nShiftNum));
        nShiftNum = mySharedPref.getInt(DioInputMethodService.PREF_RESTORE_SHIFT_NUM4, '$');
        mEditText[4].setText(String.format("%c", nShiftNum));
        nShiftNum = mySharedPref.getInt(DioInputMethodService.PREF_RESTORE_SHIFT_NUM5, '%');
        mEditText[5].setText(String.format("%c", nShiftNum));
        nShiftNum = mySharedPref.getInt(DioInputMethodService.PREF_RESTORE_SHIFT_NUM6, '^');
        mEditText[6].setText(String.format("%c", nShiftNum));
        nShiftNum = mySharedPref.getInt(DioInputMethodService.PREF_RESTORE_SHIFT_NUM7, '&');
        mEditText[7].setText(String.format("%c", nShiftNum));
        nShiftNum = mySharedPref.getInt(DioInputMethodService.PREF_RESTORE_SHIFT_NUM8, '*');
        mEditText[8].setText(String.format("%c", nShiftNum));
        nShiftNum = mySharedPref.getInt(DioInputMethodService.PREF_RESTORE_SHIFT_NUM9, '(');
        mEditText[9].setText(String.format("%c", nShiftNum));
    }
    @Override
    protected void onDestroy() {
    	// TODO Auto-generated method stub
        // RESTORE_INPUT_METHOD
        SharedPreferences mySharedPref = this.getSharedPreferences(DioInputMethodService.PREF_RESTORE_INPUTMETHOD, Activity.MODE_PRIVATE);
        SharedPreferences.Editor editor = mySharedPref.edit();
        if(editor != null){
        	int nShiftNum;
        	Editable tEditable = mEditText[0].getText();
        	if (tEditable != null)
        	{
        		nShiftNum = tEditable.charAt(0);
        		editor.putInt(DioInputMethodService.PREF_RESTORE_SHIFT_NUM0, nShiftNum);
        	}
        	tEditable = mEditText[1].getText();
        	if (tEditable != null)
        	{
        		nShiftNum = tEditable.charAt(0);
        		editor.putInt(DioInputMethodService.PREF_RESTORE_SHIFT_NUM1, nShiftNum);
        	}
        	tEditable = mEditText[2].getText();
        	if (tEditable != null)
        	{
        		nShiftNum = tEditable.charAt(0);
        		editor.putInt(DioInputMethodService.PREF_RESTORE_SHIFT_NUM2, nShiftNum);
        	}
        	tEditable = mEditText[3].getText();
        	if (tEditable != null)
        	{
        		nShiftNum = tEditable.charAt(0);
        		editor.putInt(DioInputMethodService.PREF_RESTORE_SHIFT_NUM3, nShiftNum);
        	}
        	tEditable = mEditText[4].getText();
        	if (tEditable != null)
        	{
        		nShiftNum = tEditable.charAt(0);
        		editor.putInt(DioInputMethodService.PREF_RESTORE_SHIFT_NUM4, nShiftNum);
        	}
        	tEditable = mEditText[5].getText();
        	if (tEditable != null)
        	{
        		nShiftNum = tEditable.charAt(0);
        		editor.putInt(DioInputMethodService.PREF_RESTORE_SHIFT_NUM5, nShiftNum);
        	}
        	tEditable = mEditText[6].getText();
        	if (tEditable != null)
        	{
        		nShiftNum = tEditable.charAt(0);
        		editor.putInt(DioInputMethodService.PREF_RESTORE_SHIFT_NUM6, nShiftNum);
        	}
        	tEditable = mEditText[7].getText();
        	if (tEditable != null)
        	{
        		nShiftNum = tEditable.charAt(0);
        		editor.putInt(DioInputMethodService.PREF_RESTORE_SHIFT_NUM7, nShiftNum);
        	}
        	tEditable = mEditText[8].getText();
        	if (tEditable != null)
        	{
        		nShiftNum = tEditable.charAt(0);
        		editor.putInt(DioInputMethodService.PREF_RESTORE_SHIFT_NUM8, nShiftNum);
        	}
        	tEditable = mEditText[9].getText();
        	if (tEditable != null)
        	{
        		nShiftNum = tEditable.charAt(0);
        		editor.putInt(DioInputMethodService.PREF_RESTORE_SHIFT_NUM9, nShiftNum);
        	}
            editor.commit();
        }
    	super.onDestroy();
    }
}
