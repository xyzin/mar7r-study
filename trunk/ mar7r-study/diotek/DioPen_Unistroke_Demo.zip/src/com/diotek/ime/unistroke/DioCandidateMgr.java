package com.diotek.ime.unistroke;

import com.diotek.ime.unistroke.R;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.LinearLayout;

public class DioCandidateMgr extends LinearLayout implements OnTouchListener {

    private static final boolean DEBUG = CommonData.IME_DEBUG;
    private static final String TAG = "DioCandidateMgr";
    private View mButtonLeft;
    private View mButtonRight;

    private View mButtonLeftDim;
    private View mButtonRightDim;

    private DioCandidateView mCandidates;

    public DioCandidateMgr(Context context, AttributeSet attrs) {
        super(context, attrs);
        if(DEBUG) Log.i(TAG,"DioCandidateMgr()");
    }

    public void initViews() {
        if(DEBUG) Log.i(TAG,"initViews()");
        if (mCandidates == null) {
            mButtonLeft = findViewById(R.id.candidate_left);
            mButtonLeftDim = findViewById(R.id.candidate_left_dim);
            if (mButtonLeft != null && mButtonLeftDim != null) {
                mButtonLeft.setOnTouchListener(this);
            }

            mButtonRight = findViewById(R.id.candidate_right);
            mButtonRightDim = findViewById(R.id.candidate_right_dim);
            if (mButtonRight != null && mButtonRightDim != null) {
                mButtonRight.setOnTouchListener(this);
            }

            mCandidates = (DioCandidateView) findViewById(R.id.candidates);
        }
    }

    @Override
    public void requestLayout() {
        if(DEBUG) Log.i(TAG,"requestLayout()");
        if (mCandidates != null) {
            int availableWidth = mCandidates.getWidth();
            int neededWidth = mCandidates.computeHorizontalScrollRange();

            final int nLeftX = mCandidates.getLeftPostion();

            boolean leftVisible =  nLeftX > 0;
            boolean rightVisible = nLeftX + availableWidth < neededWidth;

            if(mButtonLeft != null && mButtonLeftDim != null) { 
                mButtonLeft.setVisibility((leftVisible == true) ? VISIBLE : GONE);
                mButtonLeftDim.setVisibility((leftVisible == true) ? GONE : VISIBLE);
            }

            if(mButtonRight != null && mButtonRightDim != null) {
                mButtonRight.setVisibility((rightVisible == true) ? VISIBLE : GONE);
                mButtonRightDim.setVisibility((rightVisible == true) ? GONE : VISIBLE);
            }
        }
        super.requestLayout();
    }

    public boolean onTouch(View v, MotionEvent event) {
        if(DEBUG) Log.i(TAG,"onTouch() evet.getAction(): " + event.getAction());

    	requestLayout();
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            if (v == mButtonRight) {
               mCandidates.scrollNext();
            } else if (v == mButtonLeft) {
               mCandidates.scrollPrev();
            }
        }
        return false;
    }
}
