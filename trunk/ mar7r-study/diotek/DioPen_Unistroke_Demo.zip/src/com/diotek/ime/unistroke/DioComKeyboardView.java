package com.diotek.ime.unistroke;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.Paint.Align;
import android.graphics.Region.Op;
import android.graphics.drawable.Drawable;
import android.inputmethodservice.Keyboard;
import android.inputmethodservice.KeyboardView;
import android.inputmethodservice.Keyboard.Key;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.util.Log;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.view.WindowManager;
import android.view.Display;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.diotek.dhwr.unistroke.DHWR;
import com.diotek.dhwr.unistroke.DioHwrMethodService;
import com.diotek.flick.DioFlickMethodService;
import com.diotek.hangul.DioHangulCoreMethodService;
import com.diotek.ime.unistroke.R;
import com.diotek.ime.unistroke.DioComKeyboard;
import com.diotek.ime.unistroke.DioFullHwrView;
import com.diotek.ime.unistroke.DioInputMethodService;
import com.diotek.ime.unistroke.CommonData.InputRangeMode;

public class DioComKeyboardView extends KeyboardView {

	private static final String TAG = "DioComKeyboardView";
	private static final boolean DEBUG = CommonData.IME_DEBUG;
	private static final int NOT_A_KEY = -1;
	private static final int[] LONG_PRESSABLE_STATE_SET = { R.attr.state_long_pressable };

	private Keyboard mKeyboard;
	private int mCurrentKeyIndex = NOT_A_KEY;
	private int mLabelTextSize;
	private int mSmallLabelTextSize;
	private int mLabelTextSizeFunc;
	private int mKeyTextColor;
	private float mShadowRadius;
	private int mShadowColor;
	private float mBackgroundDimAmount;

	// Variables for dealing with multiple pointers
	private int mOldPointerCount = 1;
	private float mOldPointerX;
	private float mOldPointerY;

	// Hangul keyboard
	public DioHangulCoreMethodService mHangulService;

	// Flick
	private int mDirection;
	private DioFlickMethodService mFlickService = new DioFlickMethodService();

	// Handwriting
	private DioHwrMethodService mHwrService;
	private int mHwrBackgroundColor;
	private int mHwrRecogTime;
	private int mHwrPenColor;
	private int mHwrPenThickness;
	private boolean mHwrPreviewEnable = false;
	private Drawable mHwrPrevBackground;

	// IMPLEMETATION: HWR Member value declare ...
	private Rect mHwrRectArea = new Rect();
	private Rect mHwrRectBackground = new Rect();// APPLIED_GUI
	private Rect mPrevHwrRectArea = new Rect();

	/**
	 * HWR drawing start position
	 */
	private float mHwrDrawingPosX = 0.0f;
	private float mHwrDrawingPosY = 0.0f;

	private boolean mbIsUpdateRequestNone = false;
	private int mHwrAreaIndex = -1;

	private Runnable mCallback = null; // PREPROCESS_HWR

	private TextView mPreviewText;
	private PopupWindow mPreviewPopup;
	private int mPreviewTextSizeLarge;
	private int mPreviewOffset;
	private int mPreviewHeight;
	private int mPreviewWidth;
	private int[] mOffsetInWindow;

	private PopupWindow mPopupKeyboard;
	private boolean mMiniKeyboardOnScreen;
	private View mPopupParent;
	private int mMiniKeyboardOffsetX;
	private int mMiniKeyboardOffsetY;
	private Map<Key, View> mMiniKeyboardCache;
	private Key[] mKeys;

	/** Listener for {@link OnKeyboardActionListener}. */
	private OnKeyboardActionListener mKeyboardActionListener;

	private static final int MSG_SHOW_PREVIEW = 1;
	private static final int MSG_REMOVE_PREVIEW = 2;
	private static final int MSG_REPEAT = 3;
	private static final int MSG_LONGPRESS = 4;
	private static final int MSG_MULTITAP_TIME_OUT = 5;

	private static final int DELAY_BEFORE_PREVIEW = 70;
	private static final int DELAY_AFTER_PREVIEW = 60;
	// hwr-full scr
	private PopupWindow mFullHwrPanel;
	private DioFullHwrView mFullHwrView;

	private int mVerticalCorrection;
	private int mProximityThreshold;

	private boolean mPreviewCentered = false;
	private boolean mShowPreview = true;
	private boolean mShowTouchPoints = false;
	private int mPopupPreviewX;
	private int mPopupPreviewY;

	private int mLastX;
	private int mLastY;
	private int mStartX;
	private int mStartY;
	// dhlee 2010/04/30 [Key margin]
	private int mCurrentTouchKeyIndex;

	private boolean mProximityCorrectOn;

	private Paint mPaint;
	private Rect mPadding;
	private int mPaddingLeft;
	private int mPaddingRight;
	private int mPaddingTop;
	private int mPaddingBottom;

	private long mDownTime;
	private long mLastMoveTime;
	private int mLastKey;
	private int mLastCodeX;
	private int mLastCodeY;
	private int mCurrentKey = NOT_A_KEY;
	private long mLastKeyTime;
	private long mCurrentKeyTime;
	private int mPressedKey;
	private int mPrevKey = NOT_A_KEY;
	private boolean mIsTouchDown = false;
	private int mStrokeCount = 0;
	private int[] mKeyIndices = new int[12];
	private GestureDetector mGestureDetector;
	private int mRepeatKeyIndex = NOT_A_KEY;
	private int mPopupLayout;
	private boolean mAbortKey;
	private Key mInvalidatedKey;
	private Rect mClipRegion = new Rect(0, 0, 0, 0);

	private Drawable mKeyBackground;
	// private Drawable mHwrContiModeImg;
	private static final int REPEAT_INTERVAL = 30; // ~20 keys per second
	private static final int REPEAT_START_DELAY = 400;
	private static final int LONGPRESS_TIMEOUT = 800;
	// Deemed to be too short : ViewConfiguration.getLongPressTimeout();

	private static int MAX_NEARBY_KEYS = 12;
	private int[] mDistances = new int[MAX_NEARBY_KEYS];

	// Multitap
	private int mLastSentIndex;
	private long mLastTapTime;
	private boolean mInMultiTapKey;
	private boolean mIsMultiTap;
	private int mTapCount;
	private static final int MULTITAP_INTERVAL = 1500; // milliseconds
	private String mPreviewLabel;

	/** Whether the keyboard bitmap needs to be redrawn before it's blitted. **/
	private boolean mDrawPending;
	/** The dirty region in the keyboard bitmap */
	private Rect mDirtyRect = new Rect();
	/** The keyboard bitmap for faster updates */
	private Bitmap mBuffer;
	/** The canvas for the above mutable keyboard bitmap */
	private Canvas mCanvas;

	private Context mContext;

	Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case MSG_SHOW_PREVIEW:
				showKey(msg.arg1);
				break;
			case MSG_REMOVE_PREVIEW:
				mPreviewText.setVisibility(INVISIBLE);
				break;
			case MSG_REPEAT:
				if (repeatKey()) {
					Message repeat = Message.obtain(this, MSG_REPEAT);
					sendMessageDelayed(repeat, REPEAT_INTERVAL);
				}
				break;
			case MSG_LONGPRESS:
				openPopupIfRequired((MotionEvent) msg.obj);
				break;
			case MSG_MULTITAP_TIME_OUT:
				multitapTimeout();
				break;
			}
		}
	};

	private void multitapTimeout() {
		if (DEBUG)
			Log.d(TAG, "multitapTimeout");

		resetMultiTap();

		DioInputMethodService inputMethodService = (DioInputMethodService) DioComKeyboard
				.getIMService();

		if (inputMethodService.getInputRangeIndex() == InputRangeMode.ENG
				.ordinal()) {
			inputMethodService.initMultitapComposingState();
			inputMethodService.updateShiftKeyState(inputMethodService
					.getCurrentInputEditorInfo());
		}
	}

	public DioComKeyboardView(Context context, AttributeSet attrs) {
		super(context, attrs);

		mContext = context;
		mPrevKey = NOT_A_KEY;
		resetMultiTap();
		initGestureDetector();
	}

	private void initKeyboardInfo() {
		/**
		 * Get attributes and setting from local xml(attrs.xml & styles.xml)
		 */
		TypedArray a = mContext.obtainStyledAttributes(
				R.style.DioComKeyboardView, R.styleable.DioComKeyboardView);

		LayoutInflater inflate = (LayoutInflater) mContext
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

		int previewLayout = 0;

		int n = a.getIndexCount();
		for (int i = 0; i < n; i++) {
			int attr = a.getIndex(i);

			switch (attr) {
			case R.styleable.DioComKeyboardView_keyBackground:
				mKeyBackground = a.getDrawable(attr);
//				mKeyBackground.setAlpha(1000);
				break;
			case R.styleable.DioComKeyboardView_verticalCorrection:
				mVerticalCorrection = a.getDimensionPixelOffset(attr, 0);
				break;
			case R.styleable.DioComKeyboardView_keyPreviewLayout:
				previewLayout = a.getResourceId(attr, 0);
				break;
			case R.styleable.DioComKeyboardView_keyPreviewOffset:
				mPreviewOffset = a.getDimensionPixelOffset(attr, 0);
				break;
			case R.styleable.DioComKeyboardView_keyTextColor:
				mKeyTextColor = a.getColor(attr, 0xFF000000);
				break;
			case R.styleable.DioComKeyboardView_labelTextSize:
				mLabelTextSize = a.getDimensionPixelSize(attr, 12);
				break;
			case R.styleable.DioComKeyboardView_smallLabelTextSize:
				mSmallLabelTextSize = a.getDimensionPixelSize(attr, 6);
				break;
			case R.styleable.DioComKeyboardView_popupLayout:
				mPopupLayout = a.getResourceId(attr, 0);
				break;
			case R.styleable.DioComKeyboardView_shadowColor:
				mShadowColor = a.getColor(attr, 0);
				break;
			case R.styleable.DioComKeyboardView_shadowRadius:
				mShadowRadius = a.getFloat(attr, 0f);
				break;
			}
		}

		// Hangul Core
		mHangulService = ((DioInputMethodService) DioComKeyboard.getIMService())
				.getHangulService();

		// Handwriting
		DioInputMethodService inputMethodService = (DioInputMethodService) DioComKeyboard
				.getIMService();

		mHwrService = inputMethodService.getHwrService();
		mHwrBackgroundColor = 0xFF454545;
		
		// ejjeon 2010/07/23 united unistroke test { Ÿ�̸Ӹ� �ִ��� ����
		if ((mHwrService != null) && mHwrService.bUnistroke)
			mHwrRecogTime = 1;
		else
		// ejjeon 2010/07/23 united unistroke test }
		mHwrRecogTime = inputMethodService.getSettingHwrRecogTime();
		
		mHwrPenColor = inputMethodService.getSettingHwrPenColor();
		mHwrPenThickness = inputMethodService.getSettingHwrPenThickness();

		mHwrPreviewEnable = false;

		mLabelTextSizeFunc = (int) getResources().getDimension(
				R.dimen.labelTextSizeFunc);

		mBackgroundDimAmount = 0.5f;
		mPreviewPopup = new PopupWindow(mContext);
		if (previewLayout != 0) {
			mPreviewText = (TextView) inflate.inflate(previewLayout, null);
			mPreviewTextSizeLarge = (int) getResources().getDimension(
					R.dimen.qwerty_keyboard_key_preview_font_size);
			mPreviewPopup.setContentView(mPreviewText);
			mPreviewPopup.setBackgroundDrawable(null);
		} else {
			mShowPreview = false;
		}
		mPreviewHeight = (int) getResources().getDimension(
				R.dimen.qwerty_keyboard_key_preview_height);
		mPreviewWidth = (int) getResources().getDimension(
				R.dimen.qwerty_keyboard_key_preview_width);
		mPreviewPopup.setTouchable(false);

		mPopupKeyboard = new PopupWindow(mContext);
		mPopupKeyboard.setBackgroundDrawable(null);
		// mPopupKeyboard.setClippingEnabled(false);

		mPopupParent = this;
		// mPredicting = true;

		mPaint = new Paint();
		mPaint.setAntiAlias(true);
		mPaint.setTextAlign(Align.CENTER);

		mPadding = new Rect(0, 0, 0, 0);
		mMiniKeyboardCache = new HashMap<Key, View>();
		if (mKeyBackground != null) {
			mKeyBackground.getPadding(mPadding);
		} else {
			mKeyBackground = getResources().getDrawable(
					R.drawable.kbd_normal_atype_key);
			mKeyBackground.getPadding(mPadding);
		}
	}

	// Do not call
	public DioComKeyboardView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
	}

	private void initGestureDetector() {
		mGestureDetector = new GestureDetector(getContext(),
				new GestureDetector.SimpleOnGestureListener() {
					@Override
					public boolean onFling(MotionEvent me1, MotionEvent me2,
							float velocityX, float velocityY) {
						final float absX = Math.abs(velocityX);
						final float absY = Math.abs(velocityY);
						if (velocityX > 2000 && absY < absX) {
							swipeRight();
							return true;
						} else if (velocityX < -2000 && absY < absX) {
							swipeLeft();
							return true;
						} else if (velocityY < -2000 && absX < absY) {
							swipeUp();
							return true;
						} else if (velocityY > 1000 && absX < 200) {
							swipeDown();
							return true;
						} else if (absX > 800 || absY > 800) {
							return true;
						}
						return false;
					}
				});

		mGestureDetector.setIsLongpressEnabled(false);
	}

	@Override
	public void setOnKeyboardActionListener(OnKeyboardActionListener listener) {
		mKeyboardActionListener = listener;
	}

	/**
	 * Returns the {@link OnKeyboardActionListener} object.
	 * 
	 * @return the listener attached to this keyboard
	 */
	@Override
	protected OnKeyboardActionListener getOnKeyboardActionListener() {
		return mKeyboardActionListener;
	}

	/**
	 * Attaches a keyboard to this view. The keyboard can be switched at any
	 * time and the view will re-layout itself to accommodate the keyboard.
	 * 
	 * @see Keyboard
	 * @see #getKeyboard()
	 * @param keyboard
	 *            the keyboard to display in this view
	 */
	@Override
	public void setKeyboard(Keyboard keyboard) {
		if (mKeyboard != null) {
			showPreview(NOT_A_KEY);
		}

		initKeyboardInfo();

		mKeyboard = keyboard;
		List<Key> keys = mKeyboard.getKeys();
		mKeys = keys.toArray(new Key[keys.size()]);
		requestLayout();
		// Release buffer, just in case the new keyboard has a different size.
		// It will be reallocated on the next draw.
		mBuffer = null;
		invalidateAll();
		computeProximityThreshold(keyboard);
		mMiniKeyboardCache.clear(); // Not really necessary to do every time,
									// but will free up views

		final int nInputMethodIndex = DioComKeyboard.getKeyboardType();

		if (nInputMethodIndex != CommonData.MODE_FULL_HANDWRITING) {
			dismissFullHwrPanelWindow();
		}
		if ((nInputMethodIndex == CommonData.MODE_HANDWRITING || nInputMethodIndex == CommonData.MODE_FULL_HANDWRITING)
				&& mHwrService != null) {
			// Hwr setting
			// if( mHwrService != null ) {
			final int nCurrRange = ((DioInputMethodService) DioComKeyboard
					.getIMService()).getInputRangeIndex();
			mHwrService
					.setHwrInputLanguage((InputRangeMode.values())[nCurrRange]);
			mHwrService.clearInk();
			// setHWRPanelArea();
			// }
			if (nInputMethodIndex == CommonData.MODE_HANDWRITING) {
				setHWRPanelArea();
			} else if (nInputMethodIndex == CommonData.MODE_FULL_HANDWRITING) {
				initFullHwrMode();
			}
			// boolean isFullScreen = ((DioInputMethodService)
			// DioComKeyboard.getIMService()).isFullscreenMode();
			// if(nInputMethodIndex == CommonData.MODE_HANDWRITING &&
			// isFullScreen){
			// this.setBackgroundDrawable(getResources().getDrawable(R.drawable.sip_keypad_bg));
			// } else {
			// this.setBackgroundDrawable(getResources().getDrawable(R.drawable.sip_qwerty_bg));
			// }
		}
	}

	private void initFullHwrMode() {
		if (mFullHwrPanel == null) {
			if (DEBUG)
				Log.d(TAG, "create mFullHwrPanel ["
						+ new Throwable().getStackTrace()[0].getLineNumber()
						+ "]");
			mFullHwrPanel = new PopupWindow(mContext);
		}
		mFullHwrPanel.setBackgroundDrawable(null);

		if (mFullHwrView == null) {
			if (DEBUG)
				Log.d(TAG, "create mFullHwrView ["
						+ new Throwable().getStackTrace()[0].getLineNumber()
						+ "]");
			mFullHwrView = new DioFullHwrView(mContext);
		}

		mFullHwrView.setHwrService(mHwrService);
		mFullHwrView.updataHwrSetting();
		mFullHwrView.setHwrPanelAttribute(this);

		mFullHwrView.setOnKeyboardActionListener(mKeyboardActionListener);
	}

	/**
	 * Returns the current keyboard being displayed by this view.
	 * 
	 * @return the currently attached keyboard
	 * @see #setKeyboard(Keyboard)
	 */
	@Override
	public Keyboard getKeyboard() {
		return mKeyboard;
	}

	/**
	 * Sets the state of the shift key of the keyboard, if any.
	 * 
	 * @param shifted
	 *            whether or not to enable the state of the shift key
	 * @return true if the shift key state changed, false if there was no change
	 * @see KeyboardView#isShifted()
	 */
	@Override
	public boolean setShifted(boolean shifted) {
		if (mKeyboard != null) {
			if (DEBUG)
				Log.i(TAG, "setShifted: " + shifted);
			if (mKeyboard.setShifted(shifted)) {
				// The whole keyboard probably needs to be redrawn
				invalidateAll();
				return true;
			}
		}
		return false;
	}

	/**
	 * Returns the state of the shift key of the keyboard, if any.
	 * 
	 * @return true if the shift is in a pressed state, false otherwise. If
	 *         there is no shift key on the keyboard or there is no keyboard
	 *         attached, it returns false.
	 * @see KeyboardView#setShifted(boolean)
	 */
	@Override
	public boolean isShifted() {
		if (mKeyboard != null) {
			return mKeyboard.isShifted();
		}
		return false;
	}

	/**
	 * Enables or disables the key feedback popup. This is a popup that shows a
	 * magnified version of the depressed key. By default the preview is
	 * enabled.
	 * 
	 * @param previewEnabled
	 *            whether or not to enable the key feedback popup
	 * @see #isPreviewEnabled()
	 */
	@Override
	public void setPreviewEnabled(boolean previewEnabled) {
		mShowPreview = previewEnabled;
	}

	/**
	 * Returns the enabled state of the key feedback popup.
	 * 
	 * @return whether or not the key feedback popup is enabled
	 * @see #setPreviewEnabled(boolean)
	 */
	@Override
	public boolean isPreviewEnabled() {
		return mShowPreview;
	}

	@Override
	public void setVerticalCorrection(int verticalOffset) {

	}

	@Override
	public void setPopupParent(View v) {
		mPopupParent = v;
	}

	@Override
	public void setPopupOffset(int x, int y) {
		mMiniKeyboardOffsetX = x;
		mMiniKeyboardOffsetY = y;
		if (mPreviewPopup.isShowing()) {
			mPreviewPopup.dismiss();
		}
	}

	/**
	 * Enables or disables proximity correction. When enabled,
	 * {@link OnKeyboardActionListener#onKey} gets called with key codes for
	 * adjacent keys. Otherwise only the primary code is returned.
	 * 
	 * @param enabled
	 *            whether or not the proximity correction is enabled
	 * @hide Pending API Council approval
	 */
	@Override
	public void setProximityCorrectionEnabled(boolean enabled) {
		mProximityCorrectOn = enabled;
	}

	/**
	 * Returns the enabled state of the proximity correction.
	 * 
	 * @return true if proximity correction is enabled, false otherwise
	 * @hide Pending API Council approval
	 */
	@Override
	public boolean isProximityCorrectionEnabled() {
		return mProximityCorrectOn;
	}

	/**
	 * Popup keyboard close button clicked.
	 * 
	 * @hide
	 */
	@Override
	public void onClick(View v) {
		dismissPopupKeyboard();
	}
	private CharSequence adjustCase(CharSequence label) {
		if (mKeyboard.isShifted() && label != null /* && label.length() < 3 */
				&& Character.isLowerCase(label.charAt(0))) {
			label = label.toString().toUpperCase();
		} else if (mKeyboard.isShifted() && label != null) {
			int nInputRangeIndex = ((DioInputMethodService) DioComKeyboard
					.getIMService()).getInputRangeIndex();

			if (nInputRangeIndex == InputRangeMode.KOR.ordinal()) {
				label = Character.toString((char) getShiftedChar(label
						.charAt(0)));
			} else if (nInputRangeIndex == InputRangeMode.ENG.ordinal()) {
				label = label.toString().toUpperCase();
			}
		}
		return label;
	}

	private int adjustCase(int code) {
		if (mKeyboard.isShifted() && Character.isLowerCase(code)) {
			code = Character.toUpperCase(code);
		}
		return code;
	}

	private int adjustCaseHangul(int code) {
		if (mKeyboard.isShifted()
				&& ((DioInputMethodService) DioComKeyboard.getIMService())
						.getInputRangeIndex() == InputRangeMode.KOR.ordinal()) {
			code = getShiftedChar(code);
		}
		return code;
	}

	private int getShiftedChar(int keyCode) {
		int code = keyCode;

		switch (code) {
		case 0x3131:
		case 0x3137:
		case 0x3142:
		case 0x3145:
		case 0x3148:
			code++;
			break;
		case 0x3150:
		case 0x3154:
			code += 2;
			break;
		}

		return code;
	}

	@Override
	public void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		// Round up a little
		if (mKeyboard == null) {
			setMeasuredDimension(mPaddingLeft + mPaddingRight, mPaddingTop
					+ mPaddingBottom);
		} else {
			int width = mKeyboard.getMinWidth() + mPaddingLeft + mPaddingRight;
			if (MeasureSpec.getSize(widthMeasureSpec) < width + 10) {
				width = MeasureSpec.getSize(widthMeasureSpec);
			}
			setMeasuredDimension(width, mKeyboard.getHeight() + mPaddingTop
					+ mPaddingBottom);
		}
	}

	/**
	 * Compute the average distance between adjacent keys (horizontally and
	 * vertically) and square it to get the proximity threshold. We use a square
	 * here and in computing the touch distance from a key's center to avoid
	 * taking a square root.
	 * 
	 * @param keyboard
	 */
	private void computeProximityThreshold(Keyboard keyboard) {
		if (keyboard == null)
			return;
		final Key[] keys = mKeys;
		if (keys == null)
			return;
		int length = keys.length;
		int dimensionSum = 0;
		for (int i = 0; i < length; i++) {
			Key key = keys[i];
			dimensionSum += Math.min(key.width, key.height) + key.gap;
		}
		if (dimensionSum < 0 || length == 0)
			return;
		mProximityThreshold = (int) (dimensionSum * 1.4f / length);
		mProximityThreshold *= mProximityThreshold; // Square it
	}

	@Override
	public void onSizeChanged(int w, int h, int oldw, int oldh) {
		super.onSizeChanged(w, h, oldw, oldh);
		// Release the buffer, if any and it will be reallocated on the next
		// draw
		mBuffer = null;
	}

	@Override
	public void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		if (mDrawPending || mBuffer == null) {
			onBufferDraw();
		}
		canvas.drawBitmap(mBuffer, 0, 0, null);
	}

	private void onBufferDraw() {
		if (mBuffer == null) {
			mBuffer = Bitmap.createBitmap(getWidth(), getHeight(),
					Bitmap.Config.ARGB_8888);
			mCanvas = new Canvas(mBuffer);
			invalidateAll();
		}
		final int nKeyboardType = DioComKeyboard.getKeyboardType();
		final int nInputRange = ((DioInputMethodService) DioComKeyboard
				.getIMService()).getInputRangeIndex();

		if (nKeyboardType == CommonData.MODE_FULL_HANDWRITING
				&& mFullHwrPanel.isShowing() == false) {
			if (DEBUG)
				Log.d(TAG, "onBufferDraw: fullHwrFanle is show = false");
			if (nInputRange == InputRangeMode.NUM.ordinal()
					|| nInputRange == InputRangeMode.SYM.ordinal()) {
				showFullHwrPanelWindow(true);
			} else {
				showFullHwrPanelWindow(false);
			}
		}

		final Canvas canvas = mCanvas;
		canvas.clipRect(mDirtyRect, Op.REPLACE);

		if (mKeyboard == null)
			return;

		final Paint paint = mPaint;
		Drawable keyBackground = mKeyBackground;
		final Rect clipRegion = mClipRegion;
		final Rect padding = mPadding;
		final int kbdPaddingLeft = mPaddingLeft;
		final int kbdPaddingTop = mPaddingTop;
		final Key[] keys = mKeys;
		final Key invalidKey = mInvalidatedKey;
		paint.setAlpha(255);
		paint.setColor(mKeyTextColor);
		boolean drawSingleKey = false;
		if (invalidKey != null && canvas.getClipBounds(clipRegion)) {
			// Is clipRegion completely contained within the invalidated key?
			if (invalidKey.x + kbdPaddingLeft - 1 <= clipRegion.left
					&& invalidKey.y + kbdPaddingTop - 1 <= clipRegion.top
					&& invalidKey.x + invalidKey.width + kbdPaddingLeft + 1 >= clipRegion.right
					&& invalidKey.y + invalidKey.height + kbdPaddingTop + 1 >= clipRegion.bottom) {
				drawSingleKey = true;
			}
		}
		if (!mbIsUpdateRequestNone) {
			canvas.drawColor(0xFF000000, PorterDuff.Mode.CLEAR);
		}
		
		final int keyCount = keys.length;
		for (int i = 0; i < keyCount; i++) {
			final Key key = keys[i];
			if (drawSingleKey && invalidKey != key) {
				continue;
			}

			if (key.codes[0] == CommonData.KEYCODE_HWR_PANEL) {
				if (!mbIsUpdateRequestNone) {
					onHWRPanelDraw();
					
					// ejjeon 2010/08/05 united unistroke test { shift line draw
					Rect mShiftRect = new Rect(); // Rect mShiftRect = mHwrRectArea �ϸ� mShiftRect �� mHwrRectArea ��ü�� ������ �ϰ� �� 
					mShiftRect.bottom = mHwrRectArea.bottom;
					mShiftRect.top = mHwrRectArea.top;
					mShiftRect.left = mHwrRectArea.left;
					mShiftRect.right = mHwrRectArea.right;
					
					if ((mHwrService != null) && mHwrService.GetShiftRect(mShiftRect))
					{
					//	paint.setAlpha(128);
						paint.setStrokeWidth(1);
						paint.setColor(0xFFFF0000);
						canvas.drawLine(mShiftRect.left, mShiftRect.top, mShiftRect.right, mShiftRect.bottom, paint);
						Log.w(TAG,"[JEJLOG] mShiftRect left " + mShiftRect.left + " right " + mShiftRect.right + " top " + mShiftRect.top + " bottom " + mShiftRect.bottom);
					}
					// ejjeon 2010/08/05 united unistroke test } shift line draw
				}
				continue;
			}

			paint.setColor(mKeyTextColor);

			int[] drawableState = key.getCurrentDrawableState();
			keyBackground = getKeyBackground(key);

			String strKeyLabel;
			if (nInputRange == InputRangeMode.SYM.ordinal()
					|| key.codes[0] == CommonData.KEYCODE_COMMON_ENTER
					|| key.codes[0] == CommonData.KEYCODE_COMMON_DOT_COM) {
				strKeyLabel = key.label == null ? null : (key.label).toString();
			} else {
				strKeyLabel = key.label == null ? null : adjustCase(key.label)
						.toString();
			}
			if (strKeyLabel != null || key.icon != null)
				keyBackground.setState(drawableState); // dhlee 2010/02/10

			final Rect bounds = keyBackground.getBounds();
			if (key.width != bounds.right || key.height != bounds.bottom) {
				keyBackground.setBounds(0, 0, key.width, key.height);
			}
			canvas.translate(key.x + kbdPaddingLeft, key.y + kbdPaddingTop);
			keyBackground.draw(canvas);
			Drawable shiftKeyCircle;
			if (key.codes[0] == CommonData.KEYCODE_SHIFT_VALUE && ((DioInputMethodService) DioComKeyboard
					.getIMService()).getInputRangeIndex() == InputRangeMode.ENG.ordinal()) {
				if (((DioInputMethodService) DioComKeyboard.getIMService())
						.isCapsLock()) {
					shiftKeyCircle = getResources().getDrawable(
							R.drawable.keypad_icon_shift_on);
				} else {
					shiftKeyCircle = getResources().getDrawable(
							R.drawable.keypad_icon_shift_off);
				}
				if (shiftKeyCircle != null) {
					final Rect circleBounds = shiftKeyCircle.getBounds();
					if (key.width != circleBounds.right
							|| key.height != circleBounds.bottom) {
						shiftKeyCircle.setBounds(0, 0, key.width, key.height);
					}
					shiftKeyCircle.draw(canvas);
				}
			}

			if (strKeyLabel != null) {
				int nSubTextSize = mLabelTextSize - 8;
				paint.setFakeBoldText(true);
				paint.setShadowLayer(mShadowRadius, 0, 0, mShadowColor);

				switch (key.codes.length) {
				case 1:
					if (key.codes[0] == CommonData.KEYCODE_COMMON_ENTER
							|| key.codes[0] == CommonData.KEYCODE_COMMON_DOT_COM
							|| key.codes[0] == CommonData.KEYCODE_SYMBOL_LARROW
							|| key.codes[0] == CommonData.KEYCODE_SYMBOL_PAGE
							|| key.codes[0] == CommonData.KEYCODE_SYMBOL_RARROW) {
						paint.setTextSize(mLabelTextSizeFunc);
						paint.setFakeBoldText(false);
					} else {
						if(DioComKeyboard.getKeyboardType() == CommonData.MODE_HALF_QWERTY 
								&& (nInputRange == InputRangeMode.KOR.ordinal()
								|| nInputRange == InputRangeMode.ENG.ordinal())){
							paint.setTextSize(nSubTextSize);
						} else
							paint.setTextSize(mLabelTextSize);
					}
					
					canvas.drawText(strKeyLabel,
							(key.width - padding.left - padding.right) / 2
									+ padding.left,
							(key.height - padding.top - padding.bottom) / 2
									+ (paint.getTextSize() - paint.descent())
									/ 2 + padding.top, paint);
					break;

				default:
					if(DioComKeyboard.getKeyboardType() == CommonData.MODE_HALF_QWERTY 
							&& (nInputRange == InputRangeMode.KOR.ordinal()
							|| nInputRange == InputRangeMode.ENG.ordinal())){
						paint.setTextSize(nSubTextSize);
					} else
						paint.setTextSize(mLabelTextSize);
					if (strKeyLabel.length() == 3
							&& nInputRange == InputRangeMode.KOR.ordinal()) {
						strKeyLabel = strKeyLabel.substring(0, 2);
						canvas.drawText(strKeyLabel,
								(key.width - padding.left - padding.right) / 2
										+ padding.left, (key.height
										- padding.top - padding.bottom)
										/ 2
										+ (paint.getTextSize() - paint
												.descent()) / 2 + padding.top,
								paint);
					} else {
						canvas.drawText(strKeyLabel,
								(key.width - padding.left - padding.right) / 2
										+ padding.left, (key.height
										- padding.top - padding.bottom)
										/ 2
										+ (paint.getTextSize() - paint
												.descent()) / 2 + padding.top,
								paint);
					}
					break;
				}
				// for Small Label in HalfQwerty
				if ((DioComKeyboard.getKeyboardType() == CommonData.MODE_HALF_QWERTY || DioComKeyboard
						.getKeyboardType() == CommonData.MODE_HALF_QWERTY)
						&& CommonData.half_qwerty_flic_keys.length > i
						&& nInputRange != InputRangeMode.SYM.ordinal()) {
					paint.setTypeface(Typeface.DEFAULT);
					paint.setTextSize(mSmallLabelTextSize);
					String strSmallKeyLabel;
					if (CommonData.half_qwerty_flic_keys[i][1] != CommonData.KEYCODE_NULL) {
						strSmallKeyLabel = String
								.valueOf((char) CommonData.half_qwerty_flic_keys[i][1]);
						canvas
								.drawText(
										strSmallKeyLabel,
										(key.width - padding.left - padding.right)
												/ 2 + padding.left,
										(key.height - padding.top - padding.bottom)
												- (key.height - padding.top - padding.bottom)
												/ 8
												+ (paint.getTextSize() - paint
														.descent())
												/ 2
												+ padding.top, paint);
					}
					if (CommonData.half_qwerty_flic_keys[i][0] != CommonData.KEYCODE_NULL) {
						strSmallKeyLabel = String
								.valueOf((char) CommonData.half_qwerty_flic_keys[i][0]);
						canvas.drawText(strSmallKeyLabel, (key.width
								- padding.left - padding.right)
								/ 2 + padding.left,
								(key.height - padding.top - padding.bottom)
										/ 3
										- (paint.getTextSize() - paint
												.descent()) / 2 + padding.top,
								paint);
					}
				}

				paint.setShadowLayer(0, 0, 0, 0);
			} else if (key.icon != null) {
				final int drawableX = (key.width - padding.left - padding.right - key.icon
						.getIntrinsicWidth())
						/ 2 + padding.left;
				final int drawableY = (key.height - padding.top
						- padding.bottom - key.icon.getIntrinsicHeight())
						/ 2 + padding.top;
				canvas.translate(drawableX, drawableY);
				key.icon.setBounds(0, 0, key.icon.getIntrinsicWidth(), key.icon
						.getIntrinsicHeight());
				key.icon.draw(canvas);
				canvas.translate(-drawableX, -drawableY);
			}
			canvas.translate(-key.x - kbdPaddingLeft, -key.y - kbdPaddingTop);
		}
		mInvalidatedKey = null;

		// Overlay a dark rectangle to dim the keyboard
		if (mMiniKeyboardOnScreen) {
			paint.setColor((int) (mBackgroundDimAmount * 0xFF) << 24);
			canvas.drawRect(0, 0, getWidth(), getHeight(), paint);
		}

		if (DEBUG && mShowTouchPoints) {
			paint.setAlpha(128);
			paint.setColor(0xFFFF0000);
			canvas.drawCircle(mStartX, mStartY, 3, paint);
			canvas.drawLine(mStartX, mStartY, mLastX, mLastY, paint);
			paint.setColor(0xFF0000FF);
			canvas.drawCircle(mLastX, mLastY, 3, paint);
			paint.setColor(0xFF00FF00);
			canvas.drawCircle((mStartX + mLastX) / 2, (mStartY + mLastY) / 2,
					2, paint);
		}
		
		mDrawPending = false;
		mDirtyRect.setEmpty();
	}
	private int getKeyIndices(int x, int y, int[] allKeys) {
		final Key[] keys = mKeys;
		int primaryIndex = NOT_A_KEY;
		int closestKey = NOT_A_KEY;
		int closestKeyDist = mProximityThreshold + 1;
		java.util.Arrays.fill(mDistances, Integer.MAX_VALUE);
		int[] nearestKeyIndices = mKeyboard.getNearestKeys(x, y);
		final int keyCount = nearestKeyIndices.length;
		for (int i = 0; i < keyCount; i++) {
			final Key key = keys[nearestKeyIndices[i]];
			int dist = 0;
			boolean isInside = key.isInside(x, y);
			if (((mProximityCorrectOn && (dist = key.squaredDistanceFrom(x, y)) < mProximityThreshold) || isInside)
					&& key.codes[0] > 32) {
				// Find insertion point
				final int nCodes = key.codes.length;
				if (dist < closestKeyDist) {
					closestKeyDist = dist;
					closestKey = nearestKeyIndices[i];
				}

				if (allKeys == null)
					continue;

				for (int j = 0; j < mDistances.length; j++) {
					if (mDistances[j] > dist) {
						// Make space for nCodes codes
						System.arraycopy(mDistances, j, mDistances, j + nCodes,
								mDistances.length - j - nCodes);
						System.arraycopy(allKeys, j, allKeys, j + nCodes,
								allKeys.length - j - nCodes);
						for (int c = 0; c < nCodes; c++) {
							allKeys[j + c] = key.codes[c];
							mDistances[j + c] = dist;
						}
						break;
					}
				}
			}

			if (isInside) {
				primaryIndex = nearestKeyIndices[i];
			}
		}
		if (primaryIndex == NOT_A_KEY) {
			primaryIndex = closestKey;
		}
		return primaryIndex;
	}
	// dhlee 2010/04/07 isKeypad
	public boolean isKeypad(int nKeypadIndex) {
		switch (nKeypadIndex) {
		case CommonData.MODE_KEYPAD_SKY2:
		case CommonData.MODE_KEYPAD_CJI:
		case CommonData.MODE_KEYPAD_NARA:
		case CommonData.MODE_KEYPAD_MOTO:
			return true;
		}
		return false;
	}

	private Drawable getKeyBackground(Key aKey) {

		Drawable keyBackgd = mKeyBackground;
		int code = aKey.codes[0];

		final int nKeyboardType = DioComKeyboard.getKeyboardType();

		if (code == CommonData.KEYCODE_COMMON_BACKSPACE
				|| code == CommonData.KEYCODE_COMMON_ENTER
				|| code == CommonData.KEYCODE_COMMON_INPUT_RANGE
				|| code == CommonData.KEYCODE_COMMON_MODE
				|| code == CommonData.KEYCODE_SPACE_VALUE) {
			keyBackgd = getResources().getDrawable(
			R.drawable.kbd_function_atype_key);
		}

		if (code == CommonData.KEYCODE_SHIFT_VALUE) {
			return mKeyBackground;
		}

		return keyBackgd;
	}

	private void detectAndSendKey(int x, int y, long eventTime) {
		int nCurrentKey = mCurrentKey;

		if (nCurrentKey == NOT_A_KEY || nCurrentKey >= mKeys.length)
			return;

		final Key key = mKeys[nCurrentKey];

		if (key.text != null) {
			mKeyboardActionListener.onText(key.text);
			mKeyboardActionListener.onRelease(NOT_A_KEY);
			mLastSentIndex = nCurrentKey;
			mLastTapTime = eventTime;

			return;
		}

		int code = key.codes[0];
		int[] codes = new int[MAX_NEARBY_KEYS];
		Arrays.fill(codes, NOT_A_KEY);
		getKeyIndices(x, y, codes);

		final int nKeyboardType = DioComKeyboard.getKeyboardType();

		if (nKeyboardType == CommonData.MODE_HANDWRITING) {
			if (mPressedKey == nCurrentKey) {
				if (code == CommonData.KEYCODE_HWR_PANEL)
					return;

				code = adjustCase(code);
				code = adjustCaseHangul(code);
				mKeyboardActionListener.onKey(code, codes);
				mKeyboardActionListener.onRelease(code);

				if (code == CommonData.KEYCODE_COMMON_ENTER)
					handlePreProcessSendKey();
			} else {
				handlePreProcessSendKey();
			}
		} else if (isKeypad(nKeyboardType)) {
			if (mPressedKey == NOT_A_KEY)
				mPressedKey = nCurrentKey;

			Key pressedKey = mKeys[mPressedKey];
			code = pressedKey.codes[0];

			int nInputRangeIndex = ((DioInputMethodService) DioComKeyboard
					.getIMService()).getInputRangeIndex();
			// Multi-tap

			if (mIsMultiTap || nInputRangeIndex == InputRangeMode.ENG.ordinal()) {
				mTapCount = (mTapCount == -1) ? 0 : mTapCount;
				code = key.codes[mTapCount];
			}

			if (mPressedKey == nCurrentKey) {
				code = adjustCase(code);
				code = adjustCaseHangul(code);

				mKeyboardActionListener.onKey(code, codes);
				mKeyboardActionListener.onRelease(code);

				if (nInputRangeIndex == InputRangeMode.ENG.ordinal()) {
					mHandler.removeMessages(MSG_MULTITAP_TIME_OUT);
					Message msg = mHandler.obtainMessage(MSG_MULTITAP_TIME_OUT);

					mHandler.sendMessageDelayed(msg, MULTITAP_INTERVAL);
				}

				mLastSentIndex = mPressedKey;
			}
		} else if (DioComKeyboard.getKeyboardType() == CommonData.MODE_HALF_QWERTY) {
			if (mPressedKey == NOT_A_KEY)
				mPressedKey = nCurrentKey;

			Key pressedKey = mKeys[mPressedKey];
			code = pressedKey.codes[0];

			// Multi-tap
			if (mIsMultiTap) {
				mTapCount = (mTapCount == -1) ? 0 : mTapCount;
				code = key.codes[mTapCount];
			}

			if (mDirection != mFlickService.FlickInvalid
					|| (mDirection == mFlickService.FlickInvalid && mPressedKey != nCurrentKey)) {
				code = getFlickData(mKeys, mPressedKey);

				code = adjustCase(code);
				code = adjustCaseHangul(code);

				mKeyboardActionListener.onKey(code, codes);
				mKeyboardActionListener.onRelease(code);
				mDirection = mFlickService.FlickInvalid;
				DioInputMethodService inputMethodService = (DioInputMethodService) DioComKeyboard
						.getIMService();
				inputMethodService.updateShiftKeyState(inputMethodService
						.getCurrentInputEditorInfo());

			} else if (mPressedKey == nCurrentKey) {
				code = adjustCase(code);
				code = adjustCaseHangul(code);
				mKeyboardActionListener.onKey(code, codes);
				mKeyboardActionListener.onRelease(code);
				mHandler.removeMessages(MSG_MULTITAP_TIME_OUT);
				if (code != CommonData.KEYCODE_COMMON_SHIFT
						&& code != CommonData.KEYCODE_SHIFT_VALUE) {
					Message msg = mHandler.obtainMessage(MSG_MULTITAP_TIME_OUT);

					mHandler.sendMessageDelayed(msg, MULTITAP_INTERVAL);
				}
				mLastSentIndex = mPressedKey;
			} else {
				code = adjustCase(code);
				code = adjustCaseHangul(code);
				mKeyboardActionListener.onKey(code, codes);
				mKeyboardActionListener.onRelease(code);

				DioInputMethodService inputMethodService = (DioInputMethodService) DioComKeyboard
						.getIMService();
				inputMethodService.updateShiftKeyState(inputMethodService
						.getCurrentInputEditorInfo());

				mLastSentIndex = nCurrentKey;
			}
		} else {
			code = adjustCase(code);
			code = adjustCaseHangul(code);

			mKeyboardActionListener.onKey(code, codes);
			mKeyboardActionListener.onRelease(code);

			mLastSentIndex = nCurrentKey;
		}

		mLastTapTime = eventTime;
	}

	public int getKeyIndex() {
		return mPressedKey;
	}

	/**
	 * Handle multi-tap keys by producing the key label for the current
	 * multi-tap state.
	 */
	private CharSequence getPreviewText(Key key) {
		if (DEBUG) {
			Log.e(TAG, "mInMultiTapKey : " + mInMultiTapKey);
			Log.e(TAG, "mTapCount : " + mTapCount);
		}

		if (mInMultiTapKey) {
			mPreviewLabel = String.valueOf(key.label.charAt(mTapCount < 0 ? 0
					: mTapCount));
			if (DEBUG)
				Log.e(TAG, "mPreviewLabel : " + mPreviewLabel);
			return adjustCase(mPreviewLabel);
		} else if (key.codes.length > 1 && key.codes.length < 4) {
			return adjustCase(String.valueOf(key.label.charAt(0)));
		} else {
			return adjustCase(key.label);
		}
	}

	private void showPreview(int keyIndex) {
		int oldKeyIndex = mCurrentKeyIndex;
		final PopupWindow previewPopup = mPreviewPopup;

		mCurrentKeyIndex = keyIndex;
		// Release the old key and press the new key
		final Key[] keys = mKeys;
		if (oldKeyIndex != mCurrentKeyIndex) {
			if (oldKeyIndex != NOT_A_KEY && keys.length > oldKeyIndex) {
				keys[oldKeyIndex].onReleased(mCurrentKeyIndex == NOT_A_KEY);
				invalidateKey(oldKeyIndex, 0);
			}
			if (mCurrentKeyIndex != NOT_A_KEY && keys.length > mCurrentKeyIndex) {
				keys[mCurrentKeyIndex].onPressed();
				invalidateKey(mCurrentKeyIndex, 0);
			}
		}

		final int nKeyboardType = DioComKeyboard.getKeyboardType();

		// If key changed and preview is on ...
		if (nKeyboardType != CommonData.MODE_HANDWRITING) {
			if (oldKeyIndex != mCurrentKeyIndex && mShowPreview) {
				mHandler.removeMessages(MSG_SHOW_PREVIEW);
				if (previewPopup.isShowing()) {
					if (keyIndex == NOT_A_KEY) {
						mHandler.sendMessageDelayed(mHandler
								.obtainMessage(MSG_REMOVE_PREVIEW),
								DELAY_AFTER_PREVIEW);
					} else if (keys[keyIndex].codes[0] < 0
							|| keys[keyIndex].codes[0] == 0x08
							|| keys[keyIndex].codes[0] == 0x20) {
						mHandler.sendMessageDelayed(mHandler
								.obtainMessage(MSG_REMOVE_PREVIEW),
								DELAY_AFTER_PREVIEW);
					}
				}

				if (keyIndex != NOT_A_KEY && keys[keyIndex].codes[0] >= 0) {
					if (nKeyboardType == CommonData.MODE_QWERTY
							&& (keys[keyIndex].codes[0] == 0x08 || keys[keyIndex].codes[0] == 0x20)) {
						return;
					}

					if (previewPopup.isShowing()
							&& mPreviewText.getVisibility() == VISIBLE) {
						// Show right away, if it's already visible and finger
						// is moving around
						showKey(keyIndex);

					} else {
						mHandler.sendMessageDelayed(mHandler.obtainMessage(
								MSG_SHOW_PREVIEW, keyIndex, 0),
								DELAY_BEFORE_PREVIEW);
					}
				}
			}
		}
	}
	private void showKey(final int keyIndex) {
		final PopupWindow previewPopup = mPreviewPopup;
		final Key[] keys = mKeys;
		Key key = keys[keyIndex];

		final int nInputRangeIndex = ((DioInputMethodService) DioComKeyboard
				.getIMService()).getInputRangeIndex();

		if (key.icon != null) {
			mPreviewText.setCompoundDrawables(null, null, null,
					key.iconPreview != null ? key.iconPreview : key.icon);
			mPreviewText.setText(null);
		} else {
			mPreviewText.setCompoundDrawables(null, null, null, null);
			if (nInputRangeIndex == InputRangeMode.SYM.ordinal())
				mPreviewText.setText(key.label);
			else
				mPreviewText.setText(getPreviewText(key));

			if (key.label.length() > 1 && key.codes.length < 2) {
				mPreviewText.setTextSize(mPreviewTextSizeLarge);
				mPreviewText.setTypeface(Typeface.DEFAULT_BOLD);
			} else {
				mPreviewText.setTextSize(mPreviewTextSizeLarge);
				mPreviewText.setTypeface(Typeface.DEFAULT);
			}
		}
		mPreviewText.measure(MeasureSpec.makeMeasureSpec(0,
				MeasureSpec.UNSPECIFIED), MeasureSpec.makeMeasureSpec(0,
				MeasureSpec.UNSPECIFIED));

		int popupWidth = Math.max(mPreviewWidth, key.width
				+ mPreviewText.getPaddingLeft()
				+ mPreviewText.getPaddingRight());

		if (nInputRangeIndex == InputRangeMode.SYM.ordinal()
				&& key.label.length() >= 2)
			popupWidth = (mPreviewText.getPaddingLeft() * 4)
					+ mPreviewText.getMeasuredWidth();

		final int popupHeight = mPreviewHeight;
		LayoutParams lp = mPreviewText.getLayoutParams();
		if (lp != null) {
			lp.width = popupWidth;
			lp.height = popupHeight;
		}
		if (!mPreviewCentered) {
			mPopupPreviewX = key.x - (popupWidth - key.width) / 2;
			mPopupPreviewY = key.y - popupHeight + mPreviewOffset;
		} else {
			// Fix this if centering is brought back
			mPopupPreviewX = 160 - mPreviewText.getMeasuredWidth() / 2;
			mPopupPreviewY = -mPreviewText.getMeasuredHeight();
		}
		mHandler.removeMessages(MSG_REMOVE_PREVIEW);
		if (mOffsetInWindow == null) {
			mOffsetInWindow = new int[2];
			getLocationInWindow(mOffsetInWindow);
			mOffsetInWindow[0] += mMiniKeyboardOffsetX; // Offset may be zero
			mOffsetInWindow[1] += mMiniKeyboardOffsetY; // Offset may be zero
		}
		// Set the preview background state
		mPreviewText.getBackground().setState(
				key.popupResId != 0 ? LONG_PRESSABLE_STATE_SET
						: EMPTY_STATE_SET);
		if (previewPopup.isShowing()) {
			previewPopup.update(mPopupPreviewX + mOffsetInWindow[0],
					mPopupPreviewY + mOffsetInWindow[1], popupWidth,
					popupHeight);
		} else {
			previewPopup.setWidth(popupWidth);
			previewPopup.setHeight(popupHeight);
			previewPopup.showAtLocation(mPopupParent, Gravity.NO_GRAVITY,
					mPopupPreviewX + mOffsetInWindow[0], mPopupPreviewY
							+ mOffsetInWindow[1]);
		}
		mPreviewText.setVisibility(VISIBLE);
	}

	public void invalidateAll() {
		mDirtyRect.union(0, 0, getWidth(), getHeight());
		mDrawPending = true;
		invalidate();
	}
	private void invalidateKey(int keyIndex, int oldKeyIdx) {
		if (keyIndex < 0 || keyIndex >= mKeys.length) {
			return;
		}
		final Key key = mKeys[keyIndex];
		mInvalidatedKey = key;
		mDirtyRect.union(key.x + mPaddingLeft, key.y + mPaddingTop, key.x
				+ key.width + mPaddingLeft, key.y + key.height + mPaddingTop);
		if (mPressedKey != NOT_A_KEY
				&& mKeys[mPressedKey].codes[0] != CommonData.KEYCODE_HWR_PANEL) {
			onBufferDraw();
		}
		invalidate(key.x + mPaddingLeft, key.y + mPaddingTop, key.x + key.width
				+ mPaddingLeft, key.y + key.height + mPaddingTop);
	}

	private boolean openPopupIfRequired(MotionEvent me) {
		// Check if we have a popup layout specified first.
		if (mPopupLayout == 0) {
			return false;
		}
		if (mCurrentKey < 0 || mCurrentKey >= mKeys.length) {
			return false;
		}

		// Key popupKey = mKeys[mCurrentKey];
		Key popupKey = mKeys[mPressedKey];

		Log.i(TAG, "openPopupIfRequired: mPressedKey= " + mPressedKey);

		boolean result = onLongPress(popupKey, mPressedKey);
		if (result) {
			mAbortKey = true;
			showPreview(NOT_A_KEY);
		}
		return result;
	}
	protected boolean onLongPress(Key popupKey, int nKeyIndex) {
		if (DEBUG)
			Log.e(TAG, "onLongPress popupKey: " + popupKey + " ,nKeyIndex: "
					+ nKeyIndex);

		final int nKeyboardType = DioComKeyboard.getKeyboardType();
		final int nInputRangeIndex = ((DioInputMethodService) DioComKeyboard
				.getIMService()).getInputRangeIndex();

		if (popupKey.codes[0] == CommonData.KEYCODE_COMMON_MODE) {
			getOnKeyboardActionListener().onKey(
					CommonData.KEYCODE_COMMON_MODE_LONGPRESS, null);
			return true;
		} else if (popupKey.codes[0] == CommonData.KEYCODE_COMMON_INPUT_RANGE) {
			getOnKeyboardActionListener().onKey(
					CommonData.KEYCODE_COMMON_INPUT_RANGE_LONGPRESS, null);
			return true;
		} else if (popupKey.codes[0] == CommonData.KEYCODE_SHIFT_VALUE) {
			getOnKeyboardActionListener().onKey(
					CommonData.KEYCODE_COMMON_SHIFT_LONGPRESS, null);
			invalidateAll();
			return true;
		} else if (popupKey.codes[0] == CommonData.KEYCODE_COMMON_DOT_COM) {
			getOnKeyboardActionListener().onKey(
					CommonData.KEYCODE_COMMON_DOT_COM_LONGPRESS, null);
			invalidateAll();
			return true;
		} else if (isKeypad(nKeyboardType)
				&& nInputRangeIndex == InputRangeMode.ENG.ordinal()
				&& popupKey.codes[0] == '*') {
			getOnKeyboardActionListener().onKey(
					CommonData.KEYCODE_COMMON_STAR_LONGPRESS, null);
			return true;
		} else if ((nKeyboardType == CommonData.MODE_PHONE_NUMBER || isKeypad(nKeyboardType))
				&& popupKey.codes[0] == 0x30) {
			getOnKeyboardActionListener().onKey(43, null);
			return true;
		}

		if (isKeypad(nKeyboardType)) {
			if ((popupKey.codes[0] >= 0 && popupKey.codes[0] <= 9)) {
				getOnKeyboardActionListener().onKey(popupKey.codes[0] + 48,
						null);
				return true;
				// } else if(popupKey.codes[0] == '*' || popupKey.codes[0] ==
				// '#') {
				// getOnKeyboardActionListener().onKey(popupKey.codes[0], null);
				// return true;
			} else if (popupKey.codes[0] >= 0x41 && popupKey.codes[0] <= 0x7a
					|| popupKey.codes[0] == 0x40 || popupKey.codes[0] == 0x2e) {
				int chNum = -1;

				if (nInputRangeIndex == InputRangeMode.ENG.ordinal()) {
					switch (nKeyIndex) {
					case 0:
						chNum = 0x31;
						break;
					case 1:
						chNum = 0x32;
						break;
					case 2:
						chNum = 0x33;
						break;
					case 4:
						chNum = 0x34;
						break;
					case 5:
						chNum = 0x35;
						break;
					case 6:
						chNum = 0x36;
						break;
					case 8:
						chNum = 0x37;
						break;
					case 9:
						chNum = 0x38;
						break;
					case 10:
						chNum = 0x39;
						break;
					case 13:
						chNum = 0x30;
						break;
					}
				}

				if (chNum != -1) {
					getOnKeyboardActionListener().onKey(chNum, null);
					resetMultiTap();
					return true;
				}
			}
		}

		return false;
	}

	// dhlee 2010/04/30 [Key margin] {
	int getTheNearestKeyIndex(int TouchX, int TouchY, int[] nearKeys) {
		final List<Key> keys = mKeyboard.getKeys();
		int theNearestKeyIndex = -1;
		int minDistance = Integer.MAX_VALUE;
		for (int i = 0; i < nearKeys.length; i++) {
			int currentDistance = 0;
			Key currentKey = keys.get(nearKeys[i]);
			int keyX = currentKey.x;
			int keyY = currentKey.y;

			currentDistance = getDistanceSquare(keyX, keyY, keyX
					+ currentKey.width, keyY + currentKey.height, TouchX,
					TouchY);

			if (currentDistance < minDistance) {
				minDistance = currentDistance;
				theNearestKeyIndex = nearKeys[i];
			}
		}
		return theNearestKeyIndex;
	}

	private int getDistanceSquare(int keyLeft, int keyTop, int keyRight,
			int keyBottom, int x, int y) {
		int distanceSquare = 0;
		if (keyTop > y) {
			if (keyLeft > x) {
				distanceSquare = (keyTop - y) * (keyTop - y) + (keyLeft - x)
						* (keyLeft - x); // left top
			} else if (keyLeft <= x && keyRight >= x) {
				distanceSquare = (keyTop - y) * (keyTop - y); // center top
			} else {
				distanceSquare = (keyTop - y) * (keyTop - y) + (x - keyRight)
						* (x - keyRight); // right top
			}
		} else if (keyTop <= y && keyBottom >= y) {
			if (keyLeft > x) {
				distanceSquare = (keyLeft - x) * (keyLeft - x); // left center
			} else if (keyLeft <= x && keyRight >= x) {
				distanceSquare = 0; // center center
			} else {
				distanceSquare = (x - keyRight) * (x - keyRight); // right
																	// center
			}
		} else {
			if (keyLeft > x) {
				distanceSquare = (y - keyBottom) * (y - keyBottom)
						+ (keyLeft - x) * (keyLeft - x);
			} else if (keyLeft <= x && keyRight >= x) {
				distanceSquare = (y - keyBottom) * (y - keyBottom);
			} else {
				distanceSquare = (y - keyBottom) * (y - keyBottom)
						+ (x - keyRight) * (x - keyRight);
			}
		}
		return distanceSquare;
	}

	// dhlee 2010/04/30 [Key margin] }
	@Override
	public boolean onTouchEvent(MotionEvent me) {
       	// ejjeon 2010/08/05 united unistroke test �Ʒ��� Ű������ ��Ƽ ��ġ(���� ��ġ��) ������ �ִ� �������� 2.0 �̻��� ���������� ������ ������. �׷��Ƿ� 1.6 ������ unistroke ������ �ϰ� �Ϸ��� ����		
/* 
		// Convert multi-pointer up/down events to single up/down events to
		// deal with the typical multi-pointer behavior of two-thumb typing

		boolean result = false;
		int pointerCount = me.getPointerCount();
		if (pointerCount != mOldPointerCount) {
			long now = me.getEventTime();
			if (pointerCount == 1) {
				// Send a down event for the latest pointer
				MotionEvent down = MotionEvent.obtain(now, now,
						MotionEvent.ACTION_DOWN, me.getX(), me.getY(), me
								.getMetaState());
				result = onModifiedTouchEvent(down);
				down.recycle();
				// If it's an up action, then deliver the up as well.
				if (me.getAction() == MotionEvent.ACTION_UP) {
					result = onModifiedTouchEvent(me);
				}
			} else {
				// Send an up event for the last pointer
				MotionEvent up = MotionEvent.obtain(now, now,
						MotionEvent.ACTION_UP, mOldPointerX, mOldPointerY, me
								.getMetaState());
				result = onModifiedTouchEvent(up);
				up.recycle();
			}
		} else {
			if (pointerCount == 1) {
				mOldPointerX = me.getX();
				mOldPointerY = me.getY();
				result = onModifiedTouchEvent(me);
			} else {
				// Don't do anything when 2 pointers are down and moving.
				result = true;
			}
		}
		mOldPointerCount = pointerCount;
		return result;
	}

	private boolean onModifiedTouchEvent(MotionEvent me) {
*/		
		int touchX = (int) me.getX() - mPaddingLeft;
		int touchY = (int) me.getY() + mVerticalCorrection - mPaddingTop;
		int action = me.getAction();
		long eventTime = me.getEventTime();
		// int nKeyIndex = getKeyIndices(touchX, touchY, null);

		// dhlee 2010/04/30 [Key margin] {
		mCurrentTouchKeyIndex = getKeyIndices(touchX, touchY, null);
		if (mCurrentTouchKeyIndex == -1) {
			if (DEBUG)
				Log.w(TAG, "keyIndex == -1 -> start get nearest key index!");
			int[] keyIndices = mKeyboard.getNearestKeys(touchX, touchY);
			if (keyIndices != null && keyIndices.length > 0) {
				mCurrentTouchKeyIndex = getTheNearestKeyIndex(touchX, touchY,
						keyIndices);
			}
		}

		int nKeyIndex = mCurrentTouchKeyIndex;
		// dhlee 2010/04/30 [Key margin] }

// ejjeon 2010/08/05 united unistroke test { �ʿ���� �α� ����
//		if (DEBUG)
//			Log.e(TAG, "onModifiedTouchEvent action: " + action);
//		if (DEBUG)
//			Log.e(TAG, "keyIndex: " + nKeyIndex);
// ejjeon 2010/08/05 united unistroke test }			

		final int nKeyboardType = DioComKeyboard.getKeyboardType();
		if (nKeyboardType == CommonData.MODE_HANDWRITING) {
			return onHandwritingTouchEvent(me);
		}

		// Qwerty, 4x4 Keypad
		if (nKeyIndex != NOT_A_KEY
				&& nKeyboardType != CommonData.MODE_HALF_QWERTY) {
			if (mGestureDetector.onTouchEvent(me)) {
				showPreview(NOT_A_KEY);
				mHandler.removeMessages(MSG_REPEAT);
				mHandler.removeMessages(MSG_LONGPRESS);
				return true;
			}

			// Needs to be called after the gesture detector gets a turn, as it
			// may have
			// displayed the mini keyboard
			if (mMiniKeyboardOnScreen) {
				return true;
			}
		}

		switch (action) {
		case MotionEvent.ACTION_DOWN:
			mAbortKey = false;
			mStartX = touchX;
			mStartY = touchY;
			mLastCodeX = touchX;
			mLastCodeY = touchY;
			mLastKeyTime = 0;
			mCurrentKeyTime = 0;
			mLastKey = NOT_A_KEY;
			mCurrentKey = nKeyIndex;
			mPressedKey = NOT_A_KEY;
			mDownTime = me.getEventTime();
			mLastMoveTime = mDownTime;
			checkMultiTap(eventTime, nKeyIndex);
			mKeyboardActionListener
					.onPress(nKeyIndex != NOT_A_KEY ? mKeys[nKeyIndex].codes[0]
							: 0);

			mPressedKey = nKeyIndex;
			// Flick
			if (((DioInputMethodService) DioComKeyboard.getIMService())
					.isModes(CommonData.MODE_HALF_QWERTY)) {
				mFlickService.DioFlickClearPoint();
				mFlickService.DioFlickEnable();
				mFlickService.DioFlickAddPoint(touchX, touchY);
			}


			int nInputRangeIndex = ((DioInputMethodService) DioComKeyboard
					.getIMService()).getInputRangeIndex();
			if ((isKeypad(nKeyboardType) || nKeyboardType == CommonData.MODE_HALF_QWERTY)
					&& nInputRangeIndex == InputRangeMode.ENG.ordinal()) {
				if (mPrevKey != nKeyIndex) {
					final int prevKeyCode = (mPrevKey >= 0 && mPrevKey < mKeys.length) ? mKeys[mPrevKey].codes[0]
							: 0;
					final int KeyCode = (nKeyIndex >= 0 && nKeyIndex < mKeys.length) ? mKeys[nKeyIndex].codes[0]
							: 0;

					if (prevKeyCode != Keyboard.KEYCODE_SHIFT
							&& KeyCode != Keyboard.KEYCODE_SHIFT) {
						DioInputMethodService inputMethodService = (DioInputMethodService) DioComKeyboard
								.getIMService();
						inputMethodService
								.updateShiftKeyState(inputMethodService
										.getCurrentInputEditorInfo());
					}
				}

				mPrevKey = nKeyIndex;
			}

			if (mCurrentKey >= 0 && mKeys[mCurrentKey].repeatable) {
				mRepeatKeyIndex = mCurrentKey;
				repeatKey();
				Message msg = mHandler.obtainMessage(MSG_REPEAT);
				mHandler.sendMessageDelayed(msg, REPEAT_START_DELAY);
			}
			if (mCurrentKey != NOT_A_KEY) {
				Message msg = mHandler.obtainMessage(MSG_LONGPRESS,
						mCurrentKey, 0);
				mHandler.sendMessageDelayed(msg, LONGPRESS_TIMEOUT);
			}

			if (nKeyboardType == CommonData.MODE_QWERTY && !isPreviewEnabled()) {
				setPreviewEnabled(true);
			}
			showPreview(nKeyIndex);
			break;

		case MotionEvent.ACTION_MOVE:
			boolean continueLongPress = false;

			if (nKeyIndex != NOT_A_KEY) {
				if (mCurrentKey == NOT_A_KEY) {
					mCurrentKey = nKeyIndex;
					mCurrentKeyTime = eventTime - mDownTime;
				} else {
					if (nKeyIndex == mCurrentKey) {
						mCurrentKeyTime += eventTime - mLastMoveTime;
						continueLongPress = true;
					} else {
						resetMultiTap();
						if (isKeypad(nKeyboardType)) {
							mHangulService.DioHangulResetMultiTap();
						}
						if (nKeyboardType == CommonData.MODE_QWERTY
								&& !isPreviewEnabled()) {
							setPreviewEnabled(true);
						}
						mLastKey = mCurrentKey;
						mLastCodeX = mLastX;
						mLastCodeY = mLastY;
						mLastKeyTime = mCurrentKeyTime + eventTime
								- mLastMoveTime;
						mCurrentKey = nKeyIndex;
						mCurrentKeyTime = 0;
					}
				}
				if (nKeyIndex != mRepeatKeyIndex) {
					mHandler.removeMessages(MSG_REPEAT);
					mRepeatKeyIndex = NOT_A_KEY;
				}
			}
			if (!continueLongPress) {
				// Cancel old longpress
				mHandler.removeMessages(MSG_LONGPRESS);
				// Start new longpress if key has changed
				if (nKeyIndex != NOT_A_KEY) {
					Message msg = mHandler.obtainMessage(MSG_LONGPRESS,
							nKeyIndex, 0);
					mHandler.sendMessageDelayed(msg, LONGPRESS_TIMEOUT);
				}
			}
			// Flick
			if (((DioInputMethodService) DioComKeyboard.getIMService())
					.isModes(CommonData.MODE_HALF_QWERTY)) {
				mFlickService.DioFlickAddPoint(touchX, touchY);
			}

			showPreview(nKeyIndex);
			break;
		case MotionEvent.ACTION_UP:
			mHandler.removeMessages(MSG_SHOW_PREVIEW);
			mHandler.removeMessages(MSG_REPEAT);
			mHandler.removeMessages(MSG_LONGPRESS);
			// Flick
			if (((DioInputMethodService) DioComKeyboard.getIMService())
					.isModes(CommonData.MODE_HALF_QWERTY)) {
				mDirection = mFlickService.DioFlickCheck(touchX, touchY, 40);
				if (mDirection != mFlickService.FlickInvalid) {
					resetMultiTap();
				}
			}
			if (nKeyIndex == mCurrentKey && mIsMultiTap) {
				mCurrentKeyTime += eventTime - mLastMoveTime;
			} else {
				resetMultiTap();
				if (isKeypad(nKeyboardType)) {
					mHangulService.DioHangulResetMultiTap();
				}

				mLastKey = mCurrentKey;
				mLastKeyTime = mCurrentKeyTime + eventTime - mLastMoveTime;
				mCurrentKey = nKeyIndex;
				mCurrentKeyTime = 0;
			}
			if ((mCurrentKeyTime < mLastKeyTime && mLastKey != NOT_A_KEY)) {
				mCurrentKey = mLastKey;
				touchX = mLastCodeX;
				touchY = mLastCodeY;
			}
			showPreview(NOT_A_KEY);
			Arrays.fill(mKeyIndices, NOT_A_KEY);

			// If we're not on a repeating key (which sends on a DOWN event)
			if (mRepeatKeyIndex == NOT_A_KEY && !mMiniKeyboardOnScreen
					&& !mAbortKey) {
				detectAndSendKey(touchX, touchY, eventTime);
			}

			invalidateKey(nKeyIndex, 0);
			mRepeatKeyIndex = NOT_A_KEY;
			break;
		}

		mLastX = touchX;
		mLastY = touchY;
		return true;
	}
	private boolean onHandwritingTouchEvent(MotionEvent me) {
		int touchX = (int) me.getX() - mPaddingLeft;
		int touchY = (int) me.getY() + mVerticalCorrection - mPaddingTop;
		int action = me.getAction();
		long eventTime = me.getEventTime();
		int keyIndex = getKeyIndices(touchX, touchY, null);

// ejjeon 2010/08/05 united unistroke test { �ʿ���� �α� ����
//		if (DEBUG)
//			Log.e(TAG, "onHandwritingTouchEvent action: " + action);
//		if (DEBUG)
//			Log.e(TAG, "keyIndex: " + keyIndex);
// ejjeon 2010/08/05 united unistroke test }
		float drawY = me.getY();

		if (keyIndex != NOT_A_KEY
				&& mKeys[keyIndex].codes[0] != CommonData.KEYCODE_HWR_PANEL
				&& mHwrService.getInkCounter() == 0) {
			if (mGestureDetector.onTouchEvent(me)) {
				showPreview(NOT_A_KEY);
				mHandler.removeMessages(MSG_REPEAT);
				mHandler.removeMessages(MSG_LONGPRESS);
				return true;
			}
		} else {
			if (isHwrArea(touchX, (int) drawY)
					|| (mbIsUpdateRequestNone && action != MotionEvent.ACTION_DOWN)) {
				keyIndex = mHwrAreaIndex;
			} else if (mbIsUpdateRequestNone && action == MotionEvent.ACTION_UP) {
				mbIsUpdateRequestNone = false;
				handleHwrTouchUp(me);
			}
		}

		switch (action) {
		case MotionEvent.ACTION_DOWN:
			mAbortKey = false;
			mStartX = touchX;
			mStartY = touchY;
			mLastCodeX = touchX;
			mLastCodeY = touchY;
			mLastKeyTime = 0;
			mCurrentKeyTime = 0;
			mLastKey = NOT_A_KEY;
			mCurrentKey = keyIndex;
			mPressedKey = NOT_A_KEY;
			mDownTime = me.getEventTime();
			mLastMoveTime = mDownTime;
			checkMultiTap(eventTime, keyIndex);
			mKeyboardActionListener
					.onPress(keyIndex != NOT_A_KEY ? mKeys[keyIndex].codes[0]
							: 0);

			mPressedKey = keyIndex;

			if (mCurrentKey >= 0 && mKeys[mCurrentKey].repeatable) {
				mRepeatKeyIndex = mCurrentKey;
				repeatKey();
				Message msg = mHandler.obtainMessage(MSG_REPEAT);
				mHandler.sendMessageDelayed(msg, REPEAT_START_DELAY);
			}

			if (mCurrentKey != NOT_A_KEY) {
				Message msg = mHandler.obtainMessage(MSG_LONGPRESS, me);
				mHandler.sendMessageDelayed(msg, LONGPRESS_TIMEOUT);
			}

			showPreview(keyIndex);
			break;

		case MotionEvent.ACTION_MOVE:
			boolean bContinueLongPress = false;

			if (keyIndex != NOT_A_KEY) {
				if (mCurrentKey == NOT_A_KEY) {
					mCurrentKey = keyIndex;
					mCurrentKeyTime = eventTime - mDownTime;
				} else {
					if (keyIndex == mCurrentKey) {
						mCurrentKeyTime += eventTime - mLastMoveTime;
						bContinueLongPress = true;
					} else {
						mLastKey = mCurrentKey;
						mLastCodeX = mLastX;
						mLastCodeY = mLastY;
						mLastKeyTime = mCurrentKeyTime + eventTime
								- mLastMoveTime;
						mCurrentKey = keyIndex;
						mCurrentKeyTime = 0;
					}
				}
				if (keyIndex != mRepeatKeyIndex) {
					mHandler.removeMessages(MSG_REPEAT);
					mRepeatKeyIndex = NOT_A_KEY;
				}
			}
			if (!bContinueLongPress) {
				// Cancel old longpress
				mHandler.removeMessages(MSG_LONGPRESS);
				// Start new longpress if key has changed
				if (keyIndex != NOT_A_KEY) {
					Message msg = mHandler.obtainMessage(MSG_LONGPRESS, me);
					mHandler.sendMessageDelayed(msg, LONGPRESS_TIMEOUT);
				}
			}

			if (mPressedKey != NOT_A_KEY) {
				if (mKeys[mPressedKey].codes[0] == CommonData.KEYCODE_HWR_PANEL) {
					handleHwrTouchMove(me);
					return true;
				}
			} else {
				if (keyIndex != NOT_A_KEY
						&& mKeys[keyIndex].codes[0] == CommonData.KEYCODE_HWR_PANEL) {
					handleHwrTouchMove(me);
					return true;
				}
			}

			showPreview(keyIndex);
			break;
		case MotionEvent.ACTION_UP:
			// IMPLEMETATION: HWR
			if (keyIndex != NOT_A_KEY
					&& mKeys[keyIndex].codes[0] == CommonData.KEYCODE_HWR_PANEL) {
				handleHwrTouchUp(me);
			}
			mHandler.removeMessages(MSG_SHOW_PREVIEW);
			mHandler.removeMessages(MSG_REPEAT);
			mHandler.removeMessages(MSG_LONGPRESS);

			if (keyIndex == mCurrentKey) {
				mCurrentKeyTime += eventTime - mLastMoveTime;
			} else {
				mLastKey = mCurrentKey;
				mLastKeyTime = mCurrentKeyTime + eventTime - mLastMoveTime;
				mCurrentKey = keyIndex;
				mCurrentKeyTime = 0;
			}

			if ((mCurrentKeyTime < mLastKeyTime && mLastKey != NOT_A_KEY)) {
				mCurrentKey = mLastKey;
				touchX = mLastCodeX;
				touchY = mLastCodeY;
			}

			showPreview(NOT_A_KEY);
			Arrays.fill(mKeyIndices, NOT_A_KEY);

			// If we're not on a repeating key (which sends on a DOWN event)
			if (mRepeatKeyIndex == NOT_A_KEY && !mMiniKeyboardOnScreen
					&& !mAbortKey) {
				detectAndSendKey(touchX, touchY, eventTime);
			} else if (mRepeatKeyIndex != NOT_A_KEY
					&& DioComKeyboard.getKeyboardType() == CommonData.MODE_HANDWRITING) {
				handlePreProcessSendKey();
			}
			invalidateKey(keyIndex, 0);
			mRepeatKeyIndex = NOT_A_KEY;
			break;
		}
		mLastX = touchX;
		mLastY = touchY;
		return true;
	}

	private boolean repeatKey() {
		Key key = mKeys[mRepeatKeyIndex];
		detectAndSendKey(key.x, key.y, mLastTapTime);
		return true;
	}

	@Override
	protected void swipeRight() {
		mKeyboardActionListener.swipeRight();
	}

	@Override
	protected void swipeLeft() {
		mKeyboardActionListener.swipeLeft();
	}

	@Override
	protected void swipeUp() {
		mKeyboardActionListener.swipeUp();
	}

	@Override
	protected void swipeDown() {
		mKeyboardActionListener.swipeDown();
	}

	public void dismissPreview(){
		if (mPreviewPopup != null) {
			if (mPreviewPopup.isShowing()) {
				mPreviewPopup.dismiss();
			}
		}
	}
	
	@Override
	public void closing() {
		dismissPreview();

		mHandler.removeMessages(MSG_REPEAT);
		mHandler.removeMessages(MSG_LONGPRESS);
		mHandler.removeMessages(MSG_SHOW_PREVIEW);
		mHandler.removeMessages(MSG_MULTITAP_TIME_OUT);

		if (mFullHwrPanel != null) {
			dismissFullHwrPanelWindow();
		}

		if (mFullHwrView != null) {
			mFullHwrView.destroyDrawingCache();
			mFullHwrView = null;
		}

		dismissPopupKeyboard();
		mBuffer = null;
		mCanvas = null;
		if (mMiniKeyboardCache != null)
			mMiniKeyboardCache.clear();

		super.closing();
	}

	@Override
	public void onDetachedFromWindow() {
		super.onDetachedFromWindow();
		closing();
	}

	private void dismissPopupKeyboard() {
		if (mPopupKeyboard != null && mPopupKeyboard.isShowing()) {
			mPopupKeyboard.dismiss();
			mMiniKeyboardOnScreen = false;
			invalidateAll();
		}
	}

	@Override
	public boolean handleBack() {
		super.handleBack();

		if (mPopupKeyboard != null && mPopupKeyboard.isShowing()) {
			dismissPopupKeyboard();
			return true;
		}
		return false;
	}

	private void resetMultiTap() {
		mLastSentIndex = NOT_A_KEY;
		mTapCount = 0;
		mLastTapTime = -1;
		mInMultiTapKey = false;
		mIsMultiTap = false;
	}

	private void checkMultiTap(long eventTime, int keyIndex) {
		final int nKeyboardType = DioComKeyboard.getKeyboardType();
		if (!isKeypad(nKeyboardType)
				&& nKeyboardType != CommonData.MODE_HALF_QWERTY) {
			return;
		}

		if (keyIndex == NOT_A_KEY)
			return;
		Key key = mKeys[keyIndex];

		int nInputRangeIndex = ((DioInputMethodService) DioComKeyboard
				.getIMService()).getInputRangeIndex();
		if (key.codes.length > 1) {

			if (nInputRangeIndex == InputRangeMode.ENG.ordinal()) {
				mHandler.removeMessages(MSG_MULTITAP_TIME_OUT);
				Message msg = mHandler.obtainMessage(MSG_MULTITAP_TIME_OUT);

				mHandler.sendMessageDelayed(msg, MULTITAP_INTERVAL);
			}

			mInMultiTapKey = true;
			if (eventTime < mLastTapTime + MULTITAP_INTERVAL
					&& keyIndex == mLastSentIndex) {
				if (mTapCount <= 0)
					mTapCount = 0;
				mTapCount = (mTapCount + 1) % key.codes.length;
				mIsMultiTap = true;
				return;
			} else {
				mTapCount = -1;
				mIsMultiTap = false;
				if (nInputRangeIndex == InputRangeMode.KOR.ordinal()) {
					mHangulService.DioHangulResetMultiTap();
				}
				return;
			}
		}
		if (eventTime > mLastTapTime + MULTITAP_INTERVAL
				|| keyIndex != mLastSentIndex) {
			resetMultiTap();
			if (nInputRangeIndex == InputRangeMode.KOR.ordinal()) {
				mHangulService.DioHangulResetMultiTap();
			}
		}
	}

	/**
	 * Drawing HWR panel
	 */
	private void onHWRPanelDraw() {
		final Paint paint = mPaint;
		final Canvas canvas = mCanvas;
		final Drawable keyBackground = mKeyBackground;// mKeyBackground;//
														// APPLIED_GUI {

		if (canvas == null || mPaint == null || mBuffer == null) {
			return; // NULL_EXCEPTION
		}
		paint.setAlpha(255);
		paint.setColor(mHwrBackgroundColor);

		keyBackground.setBounds(mHwrRectBackground.left,
				mHwrRectBackground.top, mHwrRectBackground.right,
				mHwrRectBackground.bottom);
		keyBackground.draw(canvas);
		// canvas.translate(-mHwrRectBackground.left,-(mHwrRectBackground.top+mHwrPadding));
		if (mHwrPreviewEnable) {
			canvas.translate(mPrevHwrRectArea.left, mPrevHwrRectArea.top);
			mHwrPrevBackground.setBounds(mPrevHwrRectArea.left,
					mPrevHwrRectArea.top, mPrevHwrRectArea.right,
					mPrevHwrRectArea.bottom);
			mHwrPrevBackground.setAlpha(0x50);
			mHwrPrevBackground.draw(canvas);
			canvas.translate(-mPrevHwrRectArea.left, -mPrevHwrRectArea.top);
		}
	}

	/**
	 * HWR Panel area setting
	 */
	public void setHWRPanelArea() {
		final Key[] keys = mKeys;

		setHwrArea(0, 0, 0, 0);

		for (int i = 0; i < keys.length; i++) {
			Key key = keys[i];
			if (key.codes[0] == CommonData.KEYCODE_HWR_PANEL) {
				setHwrArea(key.x, key.y, key.width, key.height);
				mHwrAreaIndex = i;
				break;
			}
		}
	}
	public void setHwrArea(int x, int y, int w, int h) {
		// Hand-Writing Area setting
		Rect padding = new Rect(0, 0, 0, 0);
		mKeyBackground.getPadding(padding);
		boolean bIsHwrAreaKeyOverDraw = false;

		if (bIsHwrAreaKeyOverDraw) {
			WindowManager wm = (WindowManager) this.getContext()
					.getSystemService(Context.WINDOW_SERVICE);
			Display d = wm.getDefaultDisplay();
			int rectAreaWidth = d.getWidth() - padding.left - padding.left;
			mHwrRectArea.set(x + padding.left, y + padding.top, x
					+ rectAreaWidth, y + h);
		}
		mHwrRectArea.set(x, y, x + w, y + h);

		mHwrRectBackground.set(x, y, x + w, y + h);// APPLIED_GUI }

		// Hand-Writing Writing area setting to recognize engine
		mHwrService.setWritingArea(mHwrRectArea);
		padding = null;// APPLIED_GUI
	}

	public boolean isHwrArea(int x, int y) {
		return (mHwrRectArea.contains(x, y));
	}

	private void startHWRRecognizeTimer() {
		mHandler.postDelayed(mHWRRecognize, mHwrRecogTime);
	}

	private void endHWRRecognizeTimer() {
		mHandler.removeCallbacks(mHWRRecognize);
	}

	private Runnable mHWRRecognize = new Runnable() {
		public void run() {
			if (DEBUG)
				Log.e(TAG, "mHWRRecognize");

			mbIsUpdateRequestNone = false;
			mStrokeCount = 0;
			mHwrService.recognizeSentence();

			if (mCallback != null) {// PREPROCESS_HWR
				mHandler.postDelayed(mCallback, 0);
				mCallback = null;
			} else {
				setHwrArea(mKeys[mHwrAreaIndex].x, mKeys[mHwrAreaIndex].y,
						mKeys[mHwrAreaIndex].width, mKeys[mHwrAreaIndex].height);
				invalidateAll();
			}
		}
	};

	private boolean isHWRInsideCheckArea(float sx, float sy, float ex,
			float ey, int penThickness, Rect Area) {
		float dimetion = penThickness / 2.0f;
		Rect srcRect = new Rect();

		srcRect.left = (sx < ex) ? ((int) (sx - dimetion))
				: ((int) (ex - dimetion));
		srcRect.right = (sx < ex) ? ((int) (ex + dimetion))
				: ((int) (sx + dimetion));
		srcRect.top = (sy < ey) ? ((int) (sy - dimetion))
				: ((int) (ey - dimetion));
		srcRect.bottom = (sy < ey) ? ((int) (ey + dimetion))
				: ((int) (sy + dimetion));
		return (Area.contains(srcRect));
	}

	private void onHWRDrawTouchPoint(float sx, float sy, float x, float y,
			int penThickness) {
		final Paint paint = mPaint;
		final Canvas canvas = mCanvas;

		if (paint != null && canvas != null) {
			paint.setColor(mHwrPenColor);
			paint.setAntiAlias(true);
			paint.setStrokeWidth(penThickness);
			if (x == sx && y == sy) {
				// canvas.drawPoint(x, y, paint);
				canvas.drawCircle(x, y, penThickness / 2, paint);
			} else {
				// paint.setStrokeWidth(penThickness-2);
				// canvas.drawPoint(x, y, paint);
				canvas.drawCircle(x, y, penThickness / 2, paint);
				paint.setStrokeWidth(penThickness);
				canvas.drawLine(sx, sy, x, y, paint);
			}
			onHWRInvalidate(sx, sy, x, y, penThickness);
		}
	}

	/**
	 * HWR pen drawing invalidate...
	 * 
	 * @param sx
	 * @param sy
	 * @param ex
	 * @param ey
	 * @param penThickness
	 */
	private void onHWRInvalidate(float sx, float sy, float ex, float ey,
			int penThickness) {
		float dimetion = penThickness / 2.0f;
		Rect invalidRect = new Rect();
		int rectR = this.getRight();
		int rectL = this.getLeft();
		int rectT = this.getTop();
		int rectB = this.getBottom();

		if (sx == ex && sy == ey) {
			// Point invalidate request ...
			invalidRect.set((int) (sx - dimetion), (int) (sy - dimetion),
					(int) (sx + dimetion), (int) (sy + dimetion));

		} else {
			// Line invalidate request ...
			invalidRect.left = (sx < ex) ? ((int) (sx - dimetion))
					: ((int) (ex - dimetion));
			invalidRect.right = (sx < ex) ? ((int) (ex + dimetion))
					: ((int) (sx + dimetion));
			invalidRect.top = (sy < ey) ? ((int) (sy - dimetion))
					: ((int) (ey - dimetion));
			invalidRect.bottom = (sy < ey) ? ((int) (ey + dimetion))
					: ((int) (sy + dimetion));
		}

		if (invalidRect.left < 0) {
			invalidRect.left = rectL;
		}
		if (invalidRect.right > rectR) {
			invalidRect.right = rectR;
		}
		if (invalidRect.top < 0) {
			invalidRect.top = rectT;
		}
		if (invalidRect.bottom > rectB) {
			invalidRect.bottom = rectB;
		}

		invalidate(invalidRect);
	}

	private boolean handleHwrTouchMove(float x, float y) {
		float drawX = x;
		float drawY = y;

		mbIsUpdateRequestNone = true;
		mHwrService.addPoint((short) drawX, (short) drawY);

		if (isHWRInsideCheckArea(mHwrDrawingPosX, mHwrDrawingPosY, drawX,
				drawY, mHwrPenThickness, mHwrRectArea))

			onHWRDrawTouchPoint(mHwrDrawingPosX, mHwrDrawingPosY, drawX, drawY,
					mHwrPenThickness);

		mHwrDrawingPosX = drawX;
		mHwrDrawingPosY = drawY;
		return true;
	}

	private boolean handleHwrTouchMove(MotionEvent me) {
		float drawX = me.getX();
		float drawY = me.getY();

		if (!mIsTouchDown) {
			mHwrDrawingPosX = drawX;
			mHwrDrawingPosY = drawY;
			mIsTouchDown = true;
		}

		endHWRRecognizeTimer();

		if (me.getHistorySize() > 0) {
			for (int i = 0; i < me.getHistorySize(); i++) {
				float historyX = me.getHistoricalX(i);
				float historyY = me.getHistoricalY(i);
				handleHwrTouchMove(historyX, historyY);
			}
		}

		mbIsUpdateRequestNone = true;
		mHwrService.addPoint((short) drawX, (short) drawY);

		if (isHWRInsideCheckArea(mHwrDrawingPosX, mHwrDrawingPosY, drawX,
				drawY, mHwrPenThickness, mHwrRectArea))
			onHWRDrawTouchPoint(mHwrDrawingPosX, mHwrDrawingPosY, drawX, drawY,
					mHwrPenThickness);

		mHwrDrawingPosX = drawX;
		mHwrDrawingPosY = drawY;
		return true;
	}
	private boolean handleHwrTouchUp(MotionEvent me) {
		mHwrService.endStroke();
		mIsTouchDown = false;
		if (mStrokeCount <= 1) {
			if (mHwrService.recognizeGestureBackSpace()) {
				mbIsUpdateRequestNone = false;
				mStrokeCount = 0;

				setHwrArea(mKeys[mHwrAreaIndex].x, mKeys[mHwrAreaIndex].y,
						mKeys[mHwrAreaIndex].width, mKeys[mHwrAreaIndex].height);
				invalidateAll();
				return true;
			}
		}

		startHWRRecognizeTimer();

		return true;
	}


	private void handlePreProcessSendKey() {
		if (mHwrService.getInkCounter() > 0) {
			mHwrService.setSuggestionActive(false);
			mHwrService.endStroke();
			endHWRRecognizeTimer();
			mbIsUpdateRequestNone = false;
			mHwrService.recognizeSentence();
		}
		onHWRPanelDraw();
		invalidateAll();
	}

	private void showFullHwrPanelWindow(boolean candidateShown) {
		if (DEBUG)
			Log.d(TAG, "showFullHwrPanelWindow: candidateShow="
					+ candidateShown);
		int[] nLocation = new int[2];
		int width = 0;
		int height = 0;

		if (mFullHwrPanel == null) {
			nLocation = null;
			Log.e(TAG, "showFullHwrPanelWindow: mFullHwrPanel is NULL ["
					+ new Throwable().getStackTrace()[0].getLineNumber() + "]");
			return;
		}

		if (mFullHwrView == null) {
			nLocation = null;
			Log.e(TAG, "showFullHwrPanelWindow: mFullHwrView is NULL ["
					+ new Throwable().getStackTrace()[0].getLineNumber() + "]");
			return;
		}

		if (getWindowToken() == null || getApplicationWindowToken() == null) {
			Log.e(TAG, "showFullHwrPanelWindow: getWindowToken="
					+ getWindowToken() + ",getApplicationWindowToken="
					+ getApplicationWindowToken() + " ["
					+ new Throwable().getStackTrace()[0].getLineNumber() + "]");
			return;
		}

		this.getRootView().getLocationInWindow(nLocation);

		WindowManager wm = (WindowManager) this.getContext().getSystemService(
				Context.WINDOW_SERVICE);
		Display d = wm.getDefaultDisplay();
		width = d.getWidth();

		int candidateHeight = ((DioInputMethodService) DioComKeyboard
				.getIMService()).getCandidateViewMgr().getHeight();

		if (candidateShown && candidateHeight == 0) {
			candidateHeight = (int) (getResources().getDimension(
					R.dimen.candidate_height) + getResources().getDimension(
					R.dimen.candidate_padding));
		}
		height = d.getHeight()
				- mKeyboard.getHeight()
				- (int) getResources().getDimension(R.dimen.system_status_bar_height);

		int top = -height + nLocation[1];
		if(DEBUG) Log.d(TAG, "nLocation[1] : " + nLocation[1]);
		if(DEBUG) Log.d(TAG, "nLocation[0] : " + nLocation[0]);
		if(DEBUG) Log.d(TAG, "nLocation top  : " + top);
		if (candidateShown) {
			height = height - candidateHeight;
		}
		
		if (DEBUG)
			Log.d(TAG, "==Display Height = " + d.getHeight());
		if (DEBUG)
			Log.d(TAG, "==Keyboard Height = " + mKeyboard.getHeight());
		if (DEBUG)
			Log.d(TAG, "==Candidate Height = " + candidateHeight);
		if (DEBUG)
			Log.d(TAG, "==Full Panel Height = " + height);

		mFullHwrView.measure(MeasureSpec.makeMeasureSpec(width,
				MeasureSpec.AT_MOST), MeasureSpec.makeMeasureSpec(height,
				MeasureSpec.AT_MOST));
		mFullHwrPanel.setContentView(mFullHwrView);

		mFullHwrPanel.setWidth(width);
		mFullHwrPanel.setHeight(height);

		mFullHwrPanel.showAtLocation(this, Gravity.FILL_HORIZONTAL, nLocation[0],
				top);
		mFullHwrPanel.update(nLocation[0], top, width, height);

		mFullHwrView.setOnKeyboardActionListener(mKeyboardActionListener);
		mFullHwrView.clearCanvasBuffer(width, height);

		nLocation = null;
	}


	public void invalidateFullHwrPanel(boolean candidateShown) {
		if (DEBUG)
			Log.d(TAG, "====showFullHwrPanelWindow: candidateShow="
					+ candidateShown);
		int[] nLocation = new int[2];
		int width = 0;
		int height = 0;

		if (mFullHwrPanel == null) {
			nLocation = null;
			Log.e(TAG, "showFullHwrPanelWindow: mFullHwrPanel is NULL ["
					+ new Throwable().getStackTrace()[0].getLineNumber() + "]");
			return;
		}

		if (mFullHwrView == null) {
			nLocation = null;
			Log.e(TAG, "showFullHwrPanelWindow: mFullHwrView is NULL ["
					+ new Throwable().getStackTrace()[0].getLineNumber() + "]");
			return;
		}

		if (getWindowToken() == null || getApplicationWindowToken() == null) {
			Log.e(TAG, "showFullHwrPanelWindow: getWindowToken="
					+ getWindowToken() + ",getApplicationWindowToken="
					+ getApplicationWindowToken() + " ["
					+ new Throwable().getStackTrace()[0].getLineNumber() + "]");
			return;
		}

		this.getRootView().getLocationInWindow(nLocation);

		WindowManager wm = (WindowManager) this.getContext().getSystemService(
				Context.WINDOW_SERVICE);
		Display d = wm.getDefaultDisplay();

		width = d.getWidth();

		int candidateHeight = ((DioInputMethodService) DioComKeyboard
				.getIMService()).getCandidateViewMgr().getHeight();

		if (candidateShown && candidateHeight == 0) {
			candidateHeight = (int) (getResources().getDimension(
					R.dimen.candidate_height) + getResources().getDimension(
					R.dimen.candidate_padding));
		}

		height = d.getHeight()
				- mKeyboard.getHeight()
				- (int) getResources().getDimension(
						R.dimen.system_status_bar_height);

		int top = -height + nLocation[1];

		if (candidateShown) {
			height = height - candidateHeight;
		}

		if (DEBUG)
			Log.d(TAG, "Display Height = " + d.getHeight());
		if (DEBUG)
			Log.d(TAG, "Keyboard Height = " + mKeyboard.getHeight());
		if (DEBUG)
			Log.d(TAG, "Candidate Height = " + candidateHeight);
		if (DEBUG)
			Log.d(TAG, "Full Panel Height = " + height);

		mFullHwrView.measure(MeasureSpec.makeMeasureSpec(width,
				MeasureSpec.AT_MOST), MeasureSpec.makeMeasureSpec(height,
				MeasureSpec.AT_MOST));
		mFullHwrPanel.setContentView(mFullHwrView);

		mFullHwrPanel.setWidth(width);
		mFullHwrPanel.setHeight(height);

		mFullHwrPanel.showAtLocation(this, Gravity.NO_GRAVITY, nLocation[0],
				top);
		mFullHwrPanel.update(nLocation[0], top, width, height);

		mFullHwrView.setOnKeyboardActionListener(mKeyboardActionListener);
		mFullHwrView.clearCanvasBuffer(width, height);

		nLocation = null;
	}

	public void dismissFullHwrPanelWindow() {
		if (DEBUG)
			Log.d(TAG, "dismissFullHwrPanelWindow: " + mFullHwrPanel);

		if (mFullHwrPanel != null) {
			mFullHwrPanel.dismiss();
		}
	}

	public void setHwrInputLanguage(InputRangeMode inputRangeMode) {
		if (mHwrService != null) {
			mHwrService.setHwrInputLanguage(inputRangeMode);
		}
		invalidateAll();
	}

	public boolean isMultitapActive() {
		return mIsMultiTap;
	}

	private int getFlickData(Key[] aKey, int index) {
		if (DEBUG)
			Log.e(TAG, "getFlickData");
		if(index >= CommonData.half_qwerty_flic_keys.length)
			return -206;
		int code = -206;
		int inputRangeIndex = ((DioInputMethodService) DioComKeyboard
				.getIMService()).getInputRangeIndex();
		final int nKeyboardType = DioComKeyboard.getKeyboardType();
		if (mDirection == mFlickService.FlickToLeft) {
			code = aKey[mPressedKey].codes[0];
		} else if (mDirection == mFlickService.FlickToRight) {
			if (aKey[mPressedKey].codes.length > 1) {
				code = aKey[mPressedKey].codes[1];
			} else {
				code = aKey[mPressedKey].codes[0];
			}
		} else if (mDirection == mFlickService.FlickToUp) {
			code = CommonData.half_qwerty_flic_keys[index][0];
		} else if (mDirection == mFlickService.FlickToDown) {
			code = CommonData.half_qwerty_flic_keys[index][1];
		}
		return code;
	}
}