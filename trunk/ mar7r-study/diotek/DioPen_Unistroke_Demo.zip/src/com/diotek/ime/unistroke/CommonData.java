package com.diotek.ime.unistroke;

import java.util.ArrayList;
public class CommonData {
    public static final boolean TARGET = false;
    public static final boolean IME_DEBUG = true;
    public static final boolean IME_ERROR = true;
    public static final boolean DRAW_PATH = false;
    
    public static final int KEYCODE_SHIFT_LONGPRESS = -10;
    public static final int RECOM_WORD_MAX_NUM = 20;

    public static final int KEYCODE_COMMON_BACKSPACE             = -351;
    public static final int KEYCODE_COMMON_SPACE                 = -352;
    public static final int KEYCODE_COMMON_SHIFT                 = -353;
    public static final int KEYCODE_COMMON_MODE                  = -354;
    public static final int KEYCODE_COMMON_INPUT_RANGE           = -355;
    public static final int KEYCODE_COMMON_INPUT_RANGE_SYM       = -356;
    public static final int KEYCODE_COMMON_ENTER                 = -357;
    public static final int KEYCODE_COMMON_MODE_LONGPRESS        = -358;
    public static final int KEYCODE_COMMON_INPUT_RANGE_LONGPRESS = -359;
    public static final int KEYCODE_COMMON_SHIFT_LONGPRESS       = -365;

    public static final int KEYCODE_COMMON_DOT_COM               = -370;
    public static final int KEYCODE_COMMON_DOT_COM_LONGPRESS     = -371;

    public static final int KEYCODE_COMMON_STAR_LONGPRESS        = -380;

    public static final int KEYCODE_HWR_PANEL         = -201;
    public static final int KEYCODE_SYMBOL_LARROW     = -202;
    public static final int KEYCODE_SYMBOL_RARROW     = -203;
    public static final int KEYCODE_SYMBOL_PAGE       = -204;
    public static final int KEYCODE_FUNCTION_NULL     = -205;
    public static final int KEYCODE_NULL              = -206;

    public static final int KEYCODE_BACKSPACE_KEYIDX  = 12;
    public static final int KEYCODE_SPACE_VALUE       = 32;
    public static final int KEYCODE_BACKSPACE_VALUE   = 8;
    public static final int KEYCODE_ENTER_VALUE       = 10;
    public static final int KEYCODE_SHIFT_VALUE       = -1;

    public static final boolean USE_RWD   = true;
    public static final boolean DOUBLE_SPACE   = true;
    public static final boolean DHWR_MULTICHAR = true;
    public static final boolean DHWR_RECOG_CANDIDATE = true;
    
    public static final boolean ONLY_ENGLISH = false; // English | Digit | Symbol (!Korean) 

    public static final int MODE_QWERTY         = 0;
    //public static final int MODE_TEXT_KEYPAD         = 1;
    public static final int MODE_KEYPAD_SKY2      = 1;
    public static final int MODE_KEYPAD_CJI       = 2;
    public static final int MODE_KEYPAD_NARA      = 3;
    public static final int MODE_KEYPAD_MOTO      = 4;
    public static final int MODE_HANDWRITING      = 5;
    public static final int MODE_FULL_HANDWRITING = 6;
    public static final int MODE_HALF_QWERTY      = 7;
    public static final int MODE_PHONE_NUMBER     = 8;
    
    
    
    public final static int MODES[] = {
       MODE_QWERTY,
//       MODE_KEYPAD_CJI,
//       MODE_KEYPAD_SKY2,
//       MODE_HALF_QWERTY,
//       MODE_KEYPAD_NARA,
       MODE_FULL_HANDWRITING,
       MODE_HANDWRITING
      
//        MODE_HALF_QWERTY_CJI
    };
    
    public static final int MODE_NO_DEMO     = 0;
    public static ArrayList<CharSequence> KeyboardIM = new ArrayList<CharSequence>();
    
    public enum InputRangeMode {
        KOR(0, "Korean",  "�ѱ���",   "KOR"),
        ENG(1, "English", "����",     "ENG"),
        NUM(2, "Number",  "����",     "NUM"),
        SYM(3, "Symbol",  "Ư����ȣ", "SYM"),
        MAX(4, "", "", "");
        
        private int mUniqueIdx;
        private String mEngName;
        private String mKorName;
        private String mBtnLabel;
        
        InputRangeMode(int idx, String engName, String korName, String btnLabel) {
            this.mUniqueIdx = idx;
            this.mEngName = engName;
            this.mKorName = korName;
            this.mBtnLabel = btnLabel;
        }
        
        public int getIdx() {
            return mUniqueIdx;
        }
        
        public String getEngName() {
            return mEngName;
        }
        
        public String getKorName() {
            return mKorName;
        }
        
        public static String getEngName(InputRangeMode idx) {
            return idx.mEngName;
        }
        
        public static String getKorName(InputRangeMode idx) {
            return idx.mKorName;
        }
        
        public String getBtnLabel() {
            return mBtnLabel;
        }

        public static int getMax(){
            return (MAX.mUniqueIdx -1);
        }
    }
    
    // Hangul KeyMap Data
    // SK sky2
    public static char KeyData_Sky2[] = {  
        0x3147, 0x314e,  0,
        0x3131, 0x314b,  0x3132,
        0x3163, 0x3161,  0x3162,
        0x314f, 0x3151,  0,
        0x3137, 0x314c,  0x3138,
        0x3134, 0x3139,  0,
        0x3153, 0x3155,  0,
        0x3141, 0x3145,  0x3146,
        0x3142, 0x314d,  0x3143,
        0x3157, 0x315b,  0,
        0x3148, 0x314a,  0x3149,
        0x315c, 0x3160,  0
    };

    // Samsung cji
    public static char KeyData_Cji[] = {
        0x3147, 0x3141,  0,
        0x3163, 0,       0,
        0x00B7, 0     ,  0,
        0x3161, 0,       0,
        0x3131, 0x314b,  0x3132,
        0x3134, 0x3139,  0,
        0x3137, 0x314c,  0x3138,
        0x3142, 0x314d,  0x3143,
        0x3145, 0x314e,  0x3146,
        0x3148, 0x314a,  0x3149,
        0,      0,       0,
        0,      0,       0
    };

    //naragul
    public static char KeyData_Naragul[] = {
        0x3161, 0,      0,
        0x3131, 0,      0,
        0x3134, 0,      0,
        0x314f, 0x3153, 0,
        0x3139, 0,      0,
        0x3141, 0,      0,
        0x3157, 0x315c, 0,
        0x3145, 0,      0,
        0x3147, 0,      0,
        0x3163, 0,      0,
        0xFF0A, 0,      0,
        0x0023, 0,      0
    };
    
    //moto
    public static char KeyData_Motorola[] = {
        0x3147, 0,       0,
        0x3131, 0x3132,  0,
        0x3134, 0,       0,
        0x314f, 0x3153,  0,
        0x3137, 0x3138,  0,
        0x3139, 0,       0,
        0x3157, 0x315c,  0,
        0x3142, 0x3143,  0,
        0x3145, 0x3146,  0,
        0x3163, 0x3161,  0,
        0x3148, 0x3149,  0,
        0x0023, 0,       0
    };

    public static String wordKeyMap[][] = {
        {"bc", "qwsz"  },  //a
        {"ac", "vghn"  },  //b
        {"ab", "xdfv"  },  //c
        {"ef", "serfcx"},  //d
        {"df", "wrds"  },  //e
        {"de", "drtgvc"},  //f
        {"hi", "ftyhbv"},  //g
        {"gi", "gyujnb"},  //h
        {"gh", "uojk"  },  //i
        {"kl", "huikmn"},  //j
        {"jl", "jiolm" },  //k
        {"jk", "kop"   },  //l
        {"no", "njk"   },  //m
        {"mo", "bhjm"  },  //n
        {"mn", "ipkl"  },  //o
        {"rs", "ol"    },  //p
        {"z" , "qeas"  },  //q
        {"ps", "etdf"  },  //r
        {"pr", "awedxz"},  //s
        {"uv", "ryfg"  },  //t
        {"tv", "yihj"  },  //u
        {"tu", "cfgb"  },  //v
        {"xy", "qeas"  },  //w
        {"wy", "zsdc"  },  //x
        {"wx", "tugh"  },  //y
        {"q",  "asx"   }   //z
    };
    
    // Settings
    public static final int HWR_PEN_COLOR[] = {
       /* 0xFF0375B8,  // blue
        0xFF99CCFF,  // light blue
        0xFF99FF32,  // green
        0xFFFFC000,  // orange
        0xFFFF32CC,  // pink
        0xFFCC66FF,  // purple
        0xFFFFFFFF,  // white
        0xFFFFFF00,  // yellow
        0xFF66FFFF   // yellowish greens
*/        
        /*<color name="blue">*/0xFF0375B8,
        /*<color name="green">*/0xFF99FF32,
        /*<color name="yellow">*/0xFFFFFF00,
        /*<color name="purple">*/0xFFCC66FF,
        /*<color name="black">*/0xFF000000,
        /*<color name="white">*/0xFFFFFFFF,
        /*<color name="pink">*/0xFFFF32CC,
        /*<color name="gray">*/0xFF808080
    };
    
    public static final int HWR_PEN_THICKNESS[] = {
    	2,
    	3,
    	5,
    	7,
    	9,
    	11,
    	13
    };
    
    public static final int HALF_QWERTY_V_INDEX = 8;
    public static final int HALF_QWERTY_H_INDEX = 13;
    public static int half_qwerty_flic_keys[][] = {
        {'1','!'}, 
        {'2','@'},  
        {'3','#'},  
        {'4','$'},  
        {'5','%'},  
        {'6','^'},  
        {'7','&'},  
        {'8','*'},  
        {'9','('},  
        {'0',')'}, 
        {'+','-'}, 
        {';','='}, 
        {':','\"'}, 
        {'/','?'} 
    };
    // Domain List
    public static String domainList[] = {
        "daum.net",
        "gmail.com",
        "google.com",
        "hanmail.net",
        "hotmail.com",
        "nate.com",
        "naver.com",
        "yahoo.com"
    };
}
