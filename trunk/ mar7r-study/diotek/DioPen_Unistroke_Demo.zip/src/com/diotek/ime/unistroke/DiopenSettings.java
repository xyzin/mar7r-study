package com.diotek.ime.unistroke;

//import com.diotek.ime.unistroke.String;

import com.diotek.ime.unistroke.R;
import com.diotek.ime.unistroke.PenColorSettings;
import com.diotek.ime.unistroke.PenThicknessSettings;


import android.content.Intent;
import android.os.Bundle;
import android.preference.CheckBoxPreference;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.preference.Preference.OnPreferenceChangeListener;
import android.preference.Preference.OnPreferenceClickListener;
import android.util.Log;

public class DiopenSettings extends PreferenceActivity {
    protected static final String TAG = null;
	private Preference mPreferenceAbout;
    private Preference mPreferenceOption;
    
    private Preference mPenColor;
	private Preference mPenThickness;
	
	private int mCurColorIdx;
	private int mCurThicknessIdx;
	
//	private final String INTENT_CUR_MODE = "Cur_Mode";
	private final String INTENT_CUR_COLOR_IDX = "Cur_Color_Idx";
	private final String PREF_KEY_PEN_COLOR = "set_hwr_pen_color";
	
	private final String INTENT_CUR_THICKNESS_IDX = "Cur_Thickness_Idx";
	private final String PREF_KEY_PEN_THICKNESS = "set_hwr_pen_thickness";
    

    private CheckBoxPreference mRecomWordCheckBox;
	// ejjeon 2010/08/16 united unistroke test {
	private Preference mPreferenceShiftInfo;
	private Preference mPreferenceShiftNumInfo;
	private Preference mPreferenceUserTraining;
    private CheckBoxPreference mUnistrokeCheckBox;
    private CheckBoxPreference mUnistrokeCandCheckBox;
    private CheckBoxPreference mHanShiftCheckBox;
    private CheckBoxPreference mEngShiftCheckBox;
    private CheckBoxPreference mNumShiftCheckBox;
    private CheckBoxPreference mContextCheckBox;
	// ejjeon 2010/08/16 united unistroke test }
    
    @Override
    protected void onCreate(Bundle icicle) {
        super.onCreate(icicle);
//        if(DEMO == CommonData.MODE_HANDWRITING) {
//            addPreferencesFromResource(R.xml.prefs_demo_hwr);
//        } else {
            addPreferencesFromResource(R.xml.prefs);
//        }

        mPreferenceAbout = findPreference("dio_ime_settings_about");
        mPreferenceAbout.setOnPreferenceClickListener(aboutclickListener);
        
        if(CommonData.USE_RWD) {
            mRecomWordCheckBox = (CheckBoxPreference) findPreference("use_word_recommendation");
            mRecomWordCheckBox.setOnPreferenceChangeListener(onUseRecomWordListener);
            
            mPreferenceOption = findPreference("dio_ime_settings_rwd");
            if(mRecomWordCheckBox.isChecked()) {
                mPreferenceOption.setEnabled(true);
            } else {
                mPreferenceOption.setEnabled(false);
            }
        }
        
        mPenColor = findPreference(PREF_KEY_PEN_COLOR);
		mPenColor.setOnPreferenceClickListener(PenColorClickListener);
		
		mPenThickness = findPreference(PREF_KEY_PEN_THICKNESS);
		mPenThickness.setOnPreferenceClickListener(PenThicknessClickListener);

		// ejjeon 2010/08/16 united unistroke test {
        mPreferenceUserTraining = findPreference("unistroke_usertraining");
        mPreferenceUserTraining.setOnPreferenceClickListener(onUnistrokeUserTrainingclickListener);
		mPreferenceShiftInfo = findPreference("dio_settings_shift_info");
		mPreferenceShiftInfo.setOnPreferenceClickListener(onShiftInfoClickListener);
		mPreferenceShiftNumInfo = findPreference("dio_settings_shift_num_info");
		mPreferenceShiftNumInfo.setOnPreferenceClickListener(onShiftNumInfoClickListener);
		mUnistrokeCheckBox = (CheckBoxPreference)findPreference("unistroke");
		mUnistrokeCheckBox.setOnPreferenceChangeListener(onUnistrokeClickListener);
		mUnistrokeCandCheckBox = (CheckBoxPreference)findPreference("unistroke_cand");
		mHanShiftCheckBox = (CheckBoxPreference)findPreference("han_shift");
		mEngShiftCheckBox = (CheckBoxPreference)findPreference("eng_shift");
		mNumShiftCheckBox = (CheckBoxPreference)findPreference("num_shift");
		mContextCheckBox = (CheckBoxPreference)findPreference("context_check");
		// ejjeon 2010/08/16 united unistroke test }
    }

    Preference.OnPreferenceClickListener aboutclickListener = new OnPreferenceClickListener(){
        public boolean onPreferenceClick(Preference preference){
        	
            Intent intent = new Intent();
            intent.setClass(DiopenSettings.this, DioAbout.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivityForResult(intent, 0);
            return true;
        }
    };

	// ejjeon 2010/08/16 united unistroke test {
    Preference.OnPreferenceClickListener onUnistrokeUserTrainingclickListener = new OnPreferenceClickListener(){
        public boolean onPreferenceClick(Preference preference){
        	
            Intent intent = new Intent();
            intent.setClass(DiopenSettings.this, UnistrokeUserTrainingSettings.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivityForResult(intent, 0);
            return true;
        }
    };
    Preference.OnPreferenceClickListener onShiftInfoClickListener = new OnPreferenceClickListener(){
        public boolean onPreferenceClick(Preference preference){
        	
            Intent intent = new Intent();
            intent.setClass(DiopenSettings.this, ShiftInfoSettings.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivityForResult(intent, 0);
            return true;
        }
    };
    Preference.OnPreferenceClickListener onShiftNumInfoClickListener = new OnPreferenceClickListener(){
        public boolean onPreferenceClick(Preference preference){
        	
            Intent intent = new Intent();
            intent.setClass(DiopenSettings.this, ShiftNumInfoSetting.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivityForResult(intent, 0);
            return true;
        }
    };
   Preference.OnPreferenceChangeListener onUnistrokeClickListener = new OnPreferenceChangeListener(){
        public boolean onPreferenceChange(Preference preference, Object newValue) {
            if((Boolean) newValue) {
        		mUnistrokeCandCheckBox.setEnabled(true);
        		mHanShiftCheckBox.setEnabled(true);
        		mEngShiftCheckBox.setEnabled(true);
        		mNumShiftCheckBox.setEnabled(true);
        		mContextCheckBox.setEnabled(true);
	        } else {
        		mUnistrokeCandCheckBox.setEnabled(false);
        		mHanShiftCheckBox.setEnabled(false);
        		mEngShiftCheckBox.setEnabled(false);
        		mNumShiftCheckBox.setEnabled(false);
        		mContextCheckBox.setEnabled(false);
	        }
			return true;
		}
    };
	// ejjeon 2010/08/16 united unistroke test }
    
    Preference.OnPreferenceChangeListener onUseRecomWordListener = new OnPreferenceChangeListener(){
        public boolean onPreferenceChange(Preference preference, Object newValue) {
            if((Boolean) newValue) {
                mPreferenceOption.setEnabled(true);
	        } else {
                mPreferenceOption.setEnabled(false);
	        }
			return true;
		}
    };
    
    Preference.OnPreferenceClickListener PenColorClickListener = new OnPreferenceClickListener() {
    	public boolean onPreferenceClick(Preference preference){
    		mCurColorIdx = Integer.parseInt(mPenColor.getSharedPreferences().getString(PREF_KEY_PEN_COLOR, "2"));
    		
    		Intent intent = new Intent();
    		intent.setClass(DiopenSettings.this, PenColorSettings.class);
    		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//    		intent.putExtra(INTENT_CUR_MODE, "full");
    		intent.putExtra(INTENT_CUR_COLOR_IDX, mCurColorIdx);
    		startActivityForResult(intent, 0);
    		return true;
    		
    	}
    };

    Preference.OnPreferenceClickListener PenThicknessClickListener = new OnPreferenceClickListener() {
    	public boolean onPreferenceClick(Preference preference){
    		mCurThicknessIdx = Integer.parseInt(mPenThickness.getSharedPreferences().getString(PREF_KEY_PEN_THICKNESS, "0"));
    		
    		Intent intent = new Intent();
    		intent.setClass(DiopenSettings.this, PenThicknessSettings.class);
    		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//    		intent.putExtra(INTENT_CUR_MODE, "full");
    		intent.putExtra(INTENT_CUR_THICKNESS_IDX, mCurThicknessIdx);
    		startActivityForResult(intent, 0);
    		return true;
    		
    	}
    };
    
}
