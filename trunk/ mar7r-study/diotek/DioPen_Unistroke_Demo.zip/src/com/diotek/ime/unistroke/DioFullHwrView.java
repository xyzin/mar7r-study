package com.diotek.ime.unistroke;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.inputmethodservice.KeyboardView.OnKeyboardActionListener;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

import com.diotek.dhwr.unistroke.DHWR;
import com.diotek.dhwr.unistroke.DioHwrMethodService;
import com.diotek.ime.unistroke.R;
import com.diotek.ime.unistroke.CommonData;
import com.diotek.ime.unistroke.DioComKeyboard;
import com.diotek.ime.unistroke.DioInputMethodService;
import com.diotek.ime.unistroke.CommonData.InputRangeMode;

public class DioFullHwrView extends View {
    static final String TAG = "DioFullHwrView";
    private static final boolean DEBUG = CommonData.IME_DEBUG;
    
    private final int NOT_A_KEY = -1;
    private int mRepeatCursorKey = NOT_A_KEY;
    
    private static final int REPEAT_INTERVAL = 50;
    
    private OnKeyboardActionListener mKeyboardActionListener;
    
    private float mHwrDrawingPosX = 0.0f;
    private float mHwrDrawingPosY = 0.0f;
    private int mStrokeCount = 0;
    
    private int mHwrPenThickness;
    private int mHwrPenColor;
    private int mHwrRecogTime;
    
    // Panel
    //private Drawable mHwrPanelImg;
    
    private DioComKeyboardView mParentView;
    
    private boolean mIsTouchDown = false;
    private Rect mHwrRectArea = new Rect();
    
    private DioHwrMethodService mHwrService; // NOTE:: do not destroy this value!! only reference

    private Canvas mCanvas;
    private Bitmap mBuffer;
    
    private final float mScale = getResources().getDisplayMetrics().density;
    
    private boolean mDrawPending;
    private Rect mDirtyRect = new Rect();
    private Paint mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    
    public DioFullHwrView(Context context) {
        super(context);
        if(DEBUG) Log.d(TAG,"DioFullHwrView()");        
        
        initData(context);
    }
    
    public DioFullHwrView(Context context, AttributeSet attrs) {
        super(context, attrs);
        if(DEBUG) Log.d(TAG,"DioFullHwrView()");        
        
        initData(context);
    }
    
    public void setHwrPanelAttribute(DioComKeyboardView view) {
        mParentView = view;
    }
    
    Handler mHandler = new Handler() {
    
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
            	default:
            		break;
            }
        }
        
    };
    
    private void initData(Context context) {
        if(DEBUG) Log.d(TAG,"initData()");        
        
        this.setBackgroundColor(getResources().getColor(R.color.transparent_black));
        //mHwrPanelImg = getResources().getDrawable(R.drawable.btn_keyboard_normal_key);
        updataHwrSetting();
    }
    
    public void updataHwrSetting() {
        // Settings value
        mHwrPenThickness = ((DioInputMethodService) DioComKeyboard.getIMService()).getSettingHwrPenThickness();
        mHwrPenColor = ((DioInputMethodService) DioComKeyboard.getIMService()).getSettingHwrPenColor();//0xFF0AC6E2;
		// ejjeon 2010/07/29 united unistroke test { Ÿ�̸Ӹ� �ִ��� ����
        if ((mHwrService != null) && mHwrService.bUnistroke)
        	mHwrRecogTime = 1;
        else
        // ejjeon 2010/07/23 united unistroke test }
        mHwrRecogTime = ((DioInputMethodService) DioComKeyboard.getIMService()).getSettingHwrRecogTime();
    }
    
    public void setHwrService( DioHwrMethodService service ) {
    	mHwrService = service;
    }

    public void clearCanvasBuffer(int width, int height) {
        mBuffer = null;
        mCanvas = null;

        if (mBuffer == null) {
            if(width > 0 && height > 0) {
                mBuffer = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                mCanvas = new Canvas(mBuffer);
                invalidateAll();    
            }
        }
    }
    
    @Override
    protected void onDraw(Canvas canvas) {
        if(DEBUG) Log.d(TAG,"onDraw()");
                
        super.onDraw(canvas);
        if (mDrawPending || mBuffer == null) {
            onBufferDraw();        
        }
        
        canvas.drawBitmap(mBuffer, 0, 0, null);
    }

    public void onBufferDraw(){
        if(DEBUG) Log.d(TAG,"onBufferDraw()");

        if (mBuffer == null) {
        	mBuffer = Bitmap.createBitmap(getWidth(), getHeight(), Bitmap.Config.ARGB_8888);
            mCanvas = new Canvas(mBuffer);
            invalidateAll();
        }
        
        setHwrArea(0, 0, getWidth(), getHeight());

        //mHwrPanelImg.setAlpha(0x70);

        //mCanvas.translate(mHwrRectArea.left, mHwrRectArea.top);
        //mHwrPanelImg.setBounds(0, 0, mHwrRectArea.width(), mHwrRectArea.height());
        //mHwrPanelImg.draw(mCanvas);
        //mCanvas.translate(-mHwrRectArea.left, -mHwrRectArea.top);
		
		// ejjeon 2010/08/05 united unistroke test { shift line draw
        final Paint paint = mPaint;
		final Canvas canvas = mCanvas;
		//paint.setAlpha(255);
		Rect mShiftRect = new Rect(); // Rect mShiftRect = mHwrRectArea �ϸ� mShiftRect �� mHwrRectArea ��ü�� ������ �ϰ� �� 
		mShiftRect.bottom = mHwrRectArea.bottom;
		mShiftRect.top = mHwrRectArea.top;
		mShiftRect.left = mHwrRectArea.left;
		mShiftRect.right = mHwrRectArea.right;
		
		if ((mHwrService != null) && mHwrService.GetShiftRect(mShiftRect))
		{
		//	paint.setAlpha(128);
			paint.setStrokeWidth(1);
			paint.setColor(0xFFFF0000);
			canvas.drawLine(mShiftRect.left, mShiftRect.top, mShiftRect.right, mShiftRect.bottom, paint);
			Log.w(TAG,"[JEJLOG] mShiftRect left " + mShiftRect.left + " right " + mShiftRect.right + " top " + mShiftRect.top + " bottom " + mShiftRect.bottom);
		}
		// ejjeon 2010/08/05 united unistroke test } shift line draw

        mDrawPending = false;
        mDirtyRect.setEmpty();
    }
    
    public void invalidateAll() {
        if(DEBUG) Log.d(TAG,"invalidateAll()");
        mDirtyRect.union(0, 0, getWidth(), getHeight());
        mDrawPending = true;
        invalidate();
    }    
    
    private void closing() {
        if (DEBUG) Log.d(TAG,"closing()");
        if(mBuffer != null){
        	mBuffer.recycle();
        	mBuffer = null;
        }
        mCanvas = null;
    }
    
    @Override
    protected void onDetachedFromWindow() {
        if (DEBUG) Log.d(TAG,"onDetachedFromWindow()");
        closing();
        
        super.onDetachedFromWindow();
    }
    
    private void onHWRInvalidate(float sx,float sy,
             float ex,float ey,int penThickness){
        if(DEBUG) Log.d(TAG,"onHWRInvalidate");
        
        float dimetion = penThickness/2.0f;
        Rect invalidRect    = new Rect();
        int rectR = this.getRight();
        int rectL = this.getLeft();
        int rectT = this.getTop();
        int rectB = this.getBottom();
        
        if(sx == ex && sy == ey){
            invalidRect.set((int)(sx - dimetion), (int)(sy - dimetion),
                    (int)(sx + dimetion), (int)(sy + dimetion));
        
        }else{
            invalidRect.left = 
            (sx < ex) ? ((int)(sx - dimetion)) : ((int)(ex - dimetion));
            invalidRect.right = 
            (sx < ex) ? ((int)(ex + dimetion)) : ((int)(sx + dimetion));            
            invalidRect.top = 
            (sy < ey) ? ((int)(sy - dimetion)) : ((int)(ey - dimetion));
            invalidRect.bottom = 
            (sy < ey) ? ((int)(ey + dimetion)) : ((int)(sy + dimetion));
                    
        }
        
        if(invalidRect.left < 0)        {invalidRect.left     = rectL;}
        if(invalidRect.right > rectR)    {invalidRect.right     = rectR;}
        if(invalidRect.top < 0)            {invalidRect.top     = rectT;}
        if(invalidRect.bottom > rectB)    {invalidRect.bottom = rectB;}
        
        invalidate(invalidRect);
     }
     
     @Override
     public boolean onTouchEvent(MotionEvent me) {
            
         int action = me.getAction();
         if(DEBUG) Log.d(TAG,"onTouchEvent: " +action);
         
         switch (action) {
         case MotionEvent.ACTION_DOWN:
        	 return handleHwrTouchDown(me);             
         
         case MotionEvent.ACTION_MOVE:
             return handleHwrTouchMove(me);     

         case MotionEvent.ACTION_UP:
             return handleHwrTouchUp(me);
         }
         
         return false;
         
     }
     
     private boolean handleHwrTouchDown(MotionEvent me){
    	 if(DEBUG) Log.d(TAG,"handleHwrTouchDown");

    	 float drawX = me.getX();
    	 float drawY = me.getY();
    	 mIsTouchDown = true;
    	 mStrokeCount ++;
    
         endFullHWRRecognizeTimer(mFullHWRBoxRecognize);

    	 mHwrDrawingPosX = drawX;
    	 mHwrDrawingPosY = drawY;
    	 mHwrService.addPoint((short) drawX, (short) drawY);
    	 if(isHWRInsideCheckArea(mHwrDrawingPosX,mHwrDrawingPosY,drawX,drawY,
    			 mHwrPenThickness,mHwrRectArea)){
    		 onHWRDrawTouchPoint(mHwrDrawingPosX,mHwrDrawingPosY,drawX,drawY,
    				 mHwrPenThickness); 
    	 }
    	 return true;
     }
     
     private boolean handleHwrTouchMove(float x,float y){
            if(DEBUG) Log.d(TAG,"handleHwrTouchMove 2");
            
            float drawX = x;
            float drawY = y;
            
            mHwrService.addPoint((short) drawX, (short) drawY);
            if(isHWRInsideCheckArea(mHwrDrawingPosX,mHwrDrawingPosY,
                                    drawX,drawY,mHwrPenThickness,mHwrRectArea)) {
                onHWRDrawTouchPoint(mHwrDrawingPosX,mHwrDrawingPosY,
                        drawX,drawY,mHwrPenThickness);
            }

            mHwrDrawingPosX = drawX;
            mHwrDrawingPosY = drawY;
            return true;
        } 
     
     private boolean handleHwrTouchMove(MotionEvent me){
        if(DEBUG) Log.d(TAG,"handleHwrTouchMove");
        float drawX = me.getX();
        float drawY = me.getY();
        
        if(!mIsTouchDown) {
            mHwrDrawingPosX = drawX;
            mHwrDrawingPosY = drawY;
            mIsTouchDown = true;
        }
        
        endFullHWRRecognizeTimer(mFullHWRBoxRecognize);

        if(me.getHistorySize() > 0){
            for(int i = 0; i < me.getHistorySize(); i++){
                float historyX = me.getHistoricalX(i);
                float historyY = me.getHistoricalY(i);
                handleHwrTouchMove(historyX,historyY);
            }
        }
        
        mHwrService.addPoint((short) drawX, (short) drawY);
        if(isHWRInsideCheckArea(mHwrDrawingPosX,mHwrDrawingPosY,
                                drawX,drawY,mHwrPenThickness,mHwrRectArea)) {
            onHWRDrawTouchPoint(mHwrDrawingPosX,mHwrDrawingPosY,
                    drawX,drawY,mHwrPenThickness);
        }

        mHwrDrawingPosX = drawX;
        mHwrDrawingPosY = drawY;
        return true;
    }
    
    private boolean handleHwrTouchUp(MotionEvent me){
        if(DEBUG) Log.d(TAG,"handleHwrTouchUp");
        mHwrService.endStroke();
        mIsTouchDown = false;
        
        
        if(mStrokeCount <= 1) {
            if(mHwrService.recognizeGestureBackSpace()) {
                mStrokeCount = 0;
                clearCanvasBuffer(getWidth(), getHeight());
                invalidateAll();
                return true;
            }
        }
    
        startFullHWRRecognizeTimer(mFullHWRBoxRecognize, mHwrRecogTime);
        return true;
    }
    
    
    private void startFullHWRRecognizeTimer(Runnable r, int iTimer) {
        if(DEBUG) Log.d(TAG, "startHWRRecognizeTimer");
        mHandler.postDelayed(r, iTimer);
    }
    
    private void endFullHWRRecognizeTimer(Runnable r) {
        if(DEBUG) Log.d(TAG,"endHWRRecognizeTimer");
        mHandler.removeCallbacks(r);        
    }

    private Runnable mFullHWRBoxRecognize = new Runnable(){
        public void run(){
            if(DEBUG) Log.d(TAG,"mHWRRecognize");
            
            mStrokeCount = 0;
            
        	final boolean bPredictionOn = ((DioInputMethodService) DioComKeyboard.getIMService()).isPredictionOn();
        	final int nInputRange = ((DioInputMethodService) DioComKeyboard.getIMService()).getInputRangeIndex();
        	
        	mHwrService.setSuggestionActive(true);
        	
        	// Only when RecomWord is active, single candidate is valid.
        	if( bPredictionOn && nInputRange == InputRangeMode.ENG.ordinal() ) {
        		mHwrService.setSuggestionActive(false);
        	} else {
        		mHwrService.setSuggestionActive(true);
        	}
        	
        	mHwrService.recognizeSentence();
        	
            clearCanvasBuffer(getWidth(), getHeight());
            invalidateAll();
        }
    };


    private void onHWRDrawTouchPoint(float sx,float sy,float x, float y,
             int penThickness){
        if(DEBUG) Log.d(TAG,"onHWRDrawTouchPoint");
        
        final Paint paint = mPaint;
        final Canvas canvas = mCanvas;
        
        if(paint != null && canvas != null) {
            paint.setColor(mHwrPenColor);
            paint.setAntiAlias(true);
            paint.setStrokeWidth(penThickness);         
            if(x == sx &&  y == sy){
                //canvas.drawPoint(x, y, paint);
            	mCanvas.drawCircle(x, y, penThickness/2, paint);
            } else{
                //paint.setStrokeWidth(penThickness-1);
                //canvas.drawPoint(x, y, paint);
            	mCanvas.drawCircle(x, y, penThickness/2, paint);
                paint.setStrokeWidth(penThickness);
                canvas.drawLine(sx,sy,x,y, paint);
            }
        
        onHWRInvalidate(sx,sy,x,y,penThickness);
        }
    }
    
    public int getHwrRectAreaHeight() {
    	if(mHwrRectArea != null) {
    		return mHwrRectArea.bottom - mHwrRectArea.top;
    	}
    	return 0;
    }
    
    public void setHwrArea(int x,int y,int w,int h){
        //log("setHwrArea", BEGIN, String.format("x[%3d]  y[%3d]  w[%3d]  h[%3d]", x, y, w, h));
        if(DEBUG) Log.d(TAG,"setHwrArea");
       
        //mHwrRectArea.set(x+1, y+1, x + w - 1, y + h -1); // dhlee 2010/01/07 [�ʱ� ���� ����]

        mHwrRectArea.set(x+1, y+(int)(3*mScale), x + w - 1, y + h -15); // dhlee 2010/01/07 [�ʱ� ���� ����]
        
        mHwrService.setWritingArea(mHwrRectArea);
    }

    private boolean isHWRInsideCheckArea(float sx,float sy,float ex,
             float ey,int penThickness,Rect Area){
        float dimetion = penThickness/2.0f;
        Rect srcRect    = new Rect();
        
        srcRect.left = 
            (sx < ex) ? ((int)(sx - dimetion)) : ((int)(ex - dimetion));
        srcRect.right = 
            (sx < ex) ? ((int)(ex + dimetion)) : ((int)(sx + dimetion));            
        srcRect.top = 
            (sy < ey) ? ((int)(sy - dimetion)) : ((int)(ey - dimetion));
        srcRect.bottom = 
            (sy < ey) ? ((int)(ey + dimetion)) : ((int)(sy + dimetion));
        
        return(Area.contains(srcRect));
    }
    
    public void setOnKeyboardActionListener(OnKeyboardActionListener listener) {
        if(DEBUG) Log.d(TAG,"setOnKeyboardActionListener");
        mKeyboardActionListener = listener;
    }

    /**
     * Returns the {@link OnKeyboardActionListener} object.
     * @return the listener attached to this keyboard
     */
    protected OnKeyboardActionListener getOnKeyboardActionListener() {
        if(DEBUG) Log.d(TAG,"OnKeyboardActionListener");
        return mKeyboardActionListener;
    }

}
