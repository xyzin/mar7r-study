package com.diotek.ime.unistroke;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

import com.diotek.dhwr.unistroke.DHWR;
import com.diotek.ime.unistroke.UnistrokeUserTrainingSettings.UnistrokeImageView;

public class UnistrokeUserModelView extends Activity {
    private final String TAG = "UnistrokeUserModelView";
    private final boolean DEBUG = CommonData.IME_DEBUG;
    private final boolean ERROR = CommonData.IME_ERROR;
    private final boolean DRAW_PATH = CommonData.DRAW_PATH;
    
    private Bitmap[] mBitmapImageIds;
    private char[] mBitmapImageIdsCodes;
    
    private Context mApplicationContext;
    
    private String FILE_NAME;
    int[][] mModel = null;
    int[] mModelIndex = null;
    int mSize = 0;
    int mSelectedImage = -1;
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mApplicationContext = getApplicationContext();
        
        FILE_NAME = this.getIntent().getStringExtra("TraningFileName");
        FileInputStream fis;
        try {
            fis = openFileInput(FILE_NAME);
            int nFileSize;
            try {
                nFileSize = fis.available(); // ���� ���� ������
                if(nFileSize <= 0) {
                    if(ERROR) Log.e(TAG, "file open error");
                    return;
                }
                fis.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            if(ERROR) Log.e(TAG, "file open error");
            e.printStackTrace();
            return;
        }
        
        setDrawables();
        
        setContentView(R.layout.unistroke_usertraining_list);
        
        GridView gridview = (GridView) findViewById(R.id.GridViewUserTraining);
        gridview.setAdapter(new ImageAdapter(this));

        gridview.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				setSelectImage(arg2);
			}
        	
		});
        
        Button btn = (Button) findViewById(R.id.ButtonDeleteUserTrainingSelected);
        btn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
	            if(mSize < 1)
	                return;
	            if(mSelectedImage < 0)
	            	return;
	            DHWR.DHWRUnregisterUserModel(mModelIndex[mSelectedImage]);
	            DHWR.InkClear();
	            fileSave();
	            setDrawables();   
	            GridView gridview = (GridView) findViewById(R.id.GridViewUserTraining);
	            gridview.invalidateViews();
	            
	            Toast.makeText(mApplicationContext, "�����Ϸ�", Toast.LENGTH_SHORT).show();
	            setSelectImage(0);
			}
		});
        
        setSelectImage(0);
    }

    private void setSelectImage(int num) {
		ImageView image = (ImageView) findViewById(R.id.ImageViewUserTrainingSelected);
		
		image.setImageBitmap(mBitmapImageIds[num]);
		mSelectedImage = num;
		
		TextView txtView = (TextView) findViewById(R.id.TextViewUserTraining);
		txtView.setText(String.valueOf(mBitmapImageIdsCodes[num]));
    }
    
    public void onDestory() {
    	mBitmapImageIds = null;
    }
    
    private void setDrawables() {
        // ���Ϸ� ����Ǿ� �ִ� user model �� ������ ����
        try {
            FileInputStream fis = openFileInput(FILE_NAME);
            try {
                int nFileSize = fis.available(); // ���� ���� ������
                byte[] pchunk = new byte[nFileSize];
                // ���Ͽ� ����Ǿ� �ִ� user model �� �о� �޸𸮿� �ű��
                fis.read(pchunk);
                DHWR.DHWRLoadUserModel(pchunk, nFileSize);
                fis.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            if(DEBUG) Log.e(TAG, "User Training DB�� �����ϴ�.");
            Toast.makeText(mApplicationContext, "User Training DB�� �������� �ʽ��ϴ�.", Toast.LENGTH_SHORT).show();
            return;
        }
        
        int[] nSize = new int[2];
        int[] nPoint = new int[2];

        int retError = DHWR.DHWRGetUserModelSize(nSize);
        if(DEBUG) Log.d(TAG, "=== DHWRGetUserModelSize retError: " + Integer.toHexString(retError));
        if(DEBUG) Log.d(TAG, "=== nSize: " + nSize[0]);
        if(nSize[0] <= 0) {
            if(DEBUG) Log.e(TAG, "User Training DB�� �����ϴ�.");
            Toast.makeText(mApplicationContext, "User Training DB�� �������� �ʽ��ϴ�.", Toast.LENGTH_SHORT).show();
        }
        
        mSize = nSize[0];
        mModel = new int[mSize][];
        mModelIndex = new int[mSize];
        char[] nCode = new char[2];

        mBitmapImageIds = new Bitmap[mSize];
        mBitmapImageIdsCodes = new char[mSize];
        
        for (int k = 0; k < mSize; k++) {
            DHWR.DHWRGetUserModelInkPointSize(k, nPoint);
            mModel[k] = new int[nPoint[0] * 2];
            mModelIndex[k] = k;
            DHWR.DHWRGetUserModelInkBuff(nPoint[0] * 2, k, nCode, mModel[k]); // nModel[k] �� x ��ǥ, y ��ǥ�� ����� ������� ����
            if(DEBUG) Log.d(TAG, "nCode: " + nCode[0]);
            mBitmapImageIdsCodes[k] = nCode[0];    
            
            mBitmapImageIds[k] = Bitmap.createBitmap(150, 150, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(mBitmapImageIds[k]);

     		Paint paint = new Paint();
            
            paint.setAntiAlias(true);
            paint.setTextSize(20);
            
            
            int oldX = mModel[k][0];
            int oldY = mModel[k][1];
            paint.setStrokeWidth(5);
            paint.setColor(Color.RED);
            canvas.drawPoint(oldX, oldY, paint);
            
            paint.setColor(Color.WHITE);
            paint.setStrokeWidth(2);
            Path path = new Path();
            
            if(DRAW_PATH) {
                path.moveTo(oldX, oldY);
            }
            for(int i=2;i<(nPoint[0] * 2)-2; i+=2) {
                if(DRAW_PATH) {
//                    path.lineTo(oldX, oldY);
                    path.lineTo(mModel[k][i], mModel[k][i+1]);
                    canvas.drawPath(path, paint);
                } else {
                    canvas.drawLine(oldX, oldY, mModel[k][i], mModel[k][i+1], paint);
                }
                
                oldX = mModel[k][i];
                oldY = mModel[k][i+1];
            }
        }

    }
    
    private boolean fileSave() {
        // ������ ����Ǿ� �ִ� user model �� ���޹���
        int[] nBuffSize = new int[2];
        int retError = DHWR.DHWRStoreUserModel(null, nBuffSize);
        byte[] pUserModel = new byte[nBuffSize[0]];
        retError = DHWR.DHWRStoreUserModel(pUserModel, nBuffSize);
        
        // ���޹��� �޸𸮸� ���Ͽ� ����
        try {
            FileOutputStream fos = openFileOutput(FILE_NAME, Context.MODE_PRIVATE);
            try {
                fos.write(pUserModel);
                fos.close();
//                DHWR.DHWRClearUserModel();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                 e.printStackTrace();
                return false;
            }
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return false;
        }
        
        return true;
    }
    
    public class ImageAdapter extends BaseAdapter {
    	private Context mContext;
    	 
        public ImageAdapter (Context c) {
        	mContext = c;
    	}

    	@Override
    	public int getCount() {
    		return mBitmapImageIds.length;
    	}

    	@Override
    	public Object getItem(int position) {
    		return mBitmapImageIds[position];
    	}

    	@Override
    	public long getItemId(int position) {
    		// TODO Auto-generated method stub
    		return position;
    	}

    	@Override
    	public View getView(int position, View convertView, ViewGroup parent){
    		ImageView imageView;
    		
    		if(convertView == null){
    			imageView = new ImageView(mContext);
    			imageView.setLayoutParams(new GridView.LayoutParams(120, 120));
//    			imageView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
    			imageView.setScaleType(ImageView.ScaleType.MATRIX);
    			imageView.setPadding(8, 8, 8, 8);   
    		} else {
    			imageView = (ImageView) convertView;
    		}

    		imageView.setImageBitmap(mBitmapImageIds[position]);
    		
    		imageView.setBackgroundResource(android.R.drawable.gallery_thumb);
    		
    		return imageView;
    	}

    }
}
