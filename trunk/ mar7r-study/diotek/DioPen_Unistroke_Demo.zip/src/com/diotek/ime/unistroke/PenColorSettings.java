package com.diotek.ime.unistroke;

import java.util.ArrayList;

import com.diotek.ime.unistroke.R;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

public class PenColorSettings extends Activity {
	
	private ListView mColorListView;
	private ImageTextAdapter mColorAdapter;
	private Button mCancelBtn;
	
	private int mCurColor = 0;

	//private final String INTENT_CUR_MODE = "Cur_Mode";
	private final String INTENT_CUR_COLOR_IDX = "Cur_Color_Idx";
	private static final String PREF_KEY_PEN_COLOR = "set_hwr_pen_color";
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		requestWindowFeature(Window.FEATURE_LEFT_ICON);
		setContentView(R.layout.pen_color);
		getWindow().setFeatureDrawableResource(Window.FEATURE_LEFT_ICON, R.drawable.ic_dialog_menu_generic);
		
		//String curMode = getIntent().getExtras().getString(INTENT_CUR_MODE);
		
		mCurColor = getIntent().getExtras().getInt(INTENT_CUR_COLOR_IDX, 0);
				
		// Color List
		mColorListView = (ListView) findViewById(R.id.color_list);
		
		ArrayList<ImageText> ColorString = new ArrayList<ImageText>();
		
		ImageText ListBlue = new ImageText(getResources().getDrawable(R.drawable.blue), getResources().getString(R.string.color_blue));
		ImageText ListGreen = new ImageText(getResources().getDrawable(R.drawable.green), getResources().getString(R.string.color_green));
		ImageText ListYellow = new ImageText(getResources().getDrawable(R.drawable.yellow), getResources().getString(R.string.color_yellow));
		ImageText ListPurple = new ImageText(getResources().getDrawable(R.drawable.purple), getResources().getString(R.string.color_purple));
		ImageText ListBlack = new ImageText(getResources().getDrawable(R.drawable.black), getResources().getString(R.string.color_black));
		ImageText ListWhite = new ImageText(getResources().getDrawable(R.drawable.white), getResources().getString(R.string.color_white));
		ImageText ListPink = new ImageText(getResources().getDrawable(R.drawable.pink), getResources().getString(R.string.color_pink));
		
		ColorString.clear();
		ColorString.add(ListBlue);
		ColorString.add(ListGreen);
		ColorString.add(ListYellow);
		ColorString.add(ListPurple);
		ColorString.add(ListBlack);
		ColorString.add(ListWhite);
		ColorString.add(ListPink);
		
		mColorAdapter = new ImageTextAdapter(this, R.layout.pen_settings_list, ColorString);
		mColorListView.setAdapter(mColorAdapter);
		
		mColorListView.setOnItemClickListener(mColorListClickListener);
		mColorListView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
		mColorListView.setItemChecked(mCurColor, true);

		// Button
//		mOkBtn = (Button) findViewById(R.id.ok);
//		mOkBtn.setOnClickListener(mOkClickListener);
		mCancelBtn = (Button) findViewById(R.id.cancel);
		mCancelBtn.setOnClickListener(mCancelClicklistener);
		
		mColorListView.setSelection(mCurColor);
	}
	
	AdapterView.OnItemClickListener mColorListClickListener = new OnItemClickListener() {
		@Override
		public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
				long arg3) {

			mCurColor = arg2;
			saveInputMethodToSet(mCurColor);
			
			finish();
		}
	};
	
//	View.OnClickListener mOkClickListener = new OnClickListener() {
//
//		@Override
//		public void onClick(View v) {
//			
//			saveInputMethodToSet(mCurColor);
//			
//			onStop();
//			finish();
//		}
//	};
//	
	View.OnClickListener mCancelClicklistener = new OnClickListener() {

		@Override
		public void onClick(View v) {
			finish();
		}
	};
	
	private void saveInputMethodToSet(int colorIdx){
	   	SharedPreferences sp = PreferenceManager.
									getDefaultSharedPreferences(this);
	   	SharedPreferences.Editor editor = sp.edit();
	     
	   	editor.putString(PREF_KEY_PEN_COLOR, String.valueOf(colorIdx));
      
	   	editor.commit();
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
	}
	
	@Override
	public void onStop() {
		super.onStop();
	}
	
	@Override
	public void finish() {
		super.finish();
	}
	
	private class ImageTextAdapter extends ArrayAdapter<ImageText> {
		
		private ArrayList<ImageText> mItems;
		
		public ImageTextAdapter(Context context, int textViewResourceId, ArrayList<ImageText> items) {
			super(context, textViewResourceId, items);
			mItems = items;
		}
		
		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			View v = convertView;
			if(v == null) {
				LayoutInflater vi = (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				v = vi.inflate(R.layout.pen_settings_list, null);
			}
			
			ImageText it = mItems.get(position);
			if(it != null) {
				ImageView iv = (ImageView) v.findViewById(R.id.image);
				CheckedTextView tv = (CheckedTextView) v.findViewById(R.id.text);
				if(iv != null) {
					iv.setBackgroundDrawable(it.getImage());
				}
				if(tv != null) {
					tv.setText(it.getColor());
					if(mCurColor == position) {
						tv.setChecked(true);
					} else {
						tv.setChecked(false);
					}
				}
			}
			return v;
		}
	}
	
	class ImageText {
		private Drawable mImage;
		private String mColor;
		
		public ImageText(Drawable _image, String _color) {
			this.mImage = _image;
			this.mColor = _color;
		}
		
		public Drawable getImage() {
			return mImage;
		}
		
		public String getColor() {
			return mColor;
		}
	}
}
