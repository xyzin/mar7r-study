// ejjeon 2010/08/17 united unistroke test { shift info setting
package com.diotek.ime.unistroke;

import com.diotek.dhwr.unistroke.DHWR;
import com.diotek.ime.unistroke.R;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.RadioGroup;

public class ShiftInfoSettings extends Activity{
	EditText mEditText;
	RadioGroup mRadioGroup;
   @Override
	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.shift_info);
        
        mEditText = (EditText)findViewById(R.id.EditText01);
        mRadioGroup = (RadioGroup)findViewById(R.id.RadioGroup01);
        SharedPreferences mySharedPref = this.getSharedPreferences(DioInputMethodService.PREF_RESTORE_INPUTMETHOD, Activity.MODE_PRIVATE);
        Integer nShiftRange = mySharedPref.getInt(DioInputMethodService.PREF_RESTORE_SHIFT_RANGE, 25);
        mEditText.setText(nShiftRange.toString());
        int nShiftDirection = mySharedPref.getInt(DioInputMethodService.PREF_RESTORE_SHIFT_DIRECTION, DHWR.DHWR_SHIFT_DIRECT_LEFT);
        switch(nShiftDirection)
        {
        case DHWR.DHWR_SHIFT_DIRECT_LEFT:
            mRadioGroup.check(R.id.RadioButton01);
            break;
        case DHWR.DHWR_SHIFT_DIRECT_RIGHT:
            mRadioGroup.check(R.id.RadioButton02);
            break;
        case DHWR.DHWR_SHIFT_DIRECT_TOP:
            mRadioGroup.check(R.id.RadioButton03);
            break;
        case DHWR.DHWR_SHIFT_DIRECT_BOTTOM:
            mRadioGroup.check(R.id.RadioButton04);
            break;
        }
    }
    @Override
    protected void onDestroy() {
    	// TODO Auto-generated method stub
        // RESTORE_INPUT_METHOD
        SharedPreferences mySharedPref = this.getSharedPreferences(DioInputMethodService.PREF_RESTORE_INPUTMETHOD, Activity.MODE_PRIVATE);
        SharedPreferences.Editor editor = mySharedPref.edit();
        if(editor != null){
        	
        	int nShiftRange = Integer.parseInt(mEditText.getText().toString());
            
        	if ((nShiftRange >= 0) && (nShiftRange <= 100))
        		editor.putInt(DioInputMethodService.PREF_RESTORE_SHIFT_RANGE, nShiftRange);
            int nShiftDirection = mRadioGroup.getCheckedRadioButtonId();
            if (nShiftDirection >= 0)
            {
                switch(nShiftDirection)
                {
                case R.id.RadioButton01:
                	editor.putInt(DioInputMethodService.PREF_RESTORE_SHIFT_DIRECTION, DHWR.DHWR_SHIFT_DIRECT_LEFT);
                    break;
                case R.id.RadioButton02:
                	editor.putInt(DioInputMethodService.PREF_RESTORE_SHIFT_DIRECTION, DHWR.DHWR_SHIFT_DIRECT_RIGHT);
                    break;
                case R.id.RadioButton03:
                	editor.putInt(DioInputMethodService.PREF_RESTORE_SHIFT_DIRECTION, DHWR.DHWR_SHIFT_DIRECT_TOP);
                    break;
                case R.id.RadioButton04:
                	editor.putInt(DioInputMethodService.PREF_RESTORE_SHIFT_DIRECTION, DHWR.DHWR_SHIFT_DIRECT_BOTTOM);
                    break;
                }
            }
            editor.commit();
        }
    	super.onDestroy();
    }
}
//ejjeon 2010/08/17 united unistroke test }