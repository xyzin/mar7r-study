package com.diotek.ime.unistroke;

import java.util.ArrayList;

import com.diotek.ime.unistroke.R;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.AdapterView.OnItemClickListener;

public class PenThicknessSettings extends Activity {
	
	private ListView mThicknessListView;
	private ImageTextAdapter mThicknessAdapter;
	private Button mCancelBtn;
	
	private int mCurThickness = 0;

//	private final String INTENT_CUR_MODE = "Cur_Mode";
	private final String INTENT_CUR_THICKNESS_IDX = "Cur_Thickness_Idx";
	private final String PREF_KEY_PEN_THICKNESS = "set_hwr_pen_thickness";
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		requestWindowFeature(Window.FEATURE_LEFT_ICON);
		setContentView(R.layout.pen_thickness);
		getWindow().setFeatureDrawableResource(Window.FEATURE_LEFT_ICON, R.drawable.ic_dialog_menu_generic);
		
//		String curMode = getIntent().getExtras().getString(INTENT_CUR_MODE);
	
		mCurThickness = getIntent().getExtras().getInt(INTENT_CUR_THICKNESS_IDX, 0);
		
		// Thickness List
		mThicknessListView = (ListView) findViewById(R.id.thickness_list);
		
		ArrayList<ImageText> ThicknessString = new ArrayList<ImageText>();
		
		ImageText ListThickness01 = new ImageText(getResources().getDrawable(R.drawable.thickness01), getResources().getString(R.string.thickness_2));
		ImageText ListThickness02 = new ImageText(getResources().getDrawable(R.drawable.thickness02), getResources().getString(R.string.thickness_3));
		ImageText ListThickness03 = new ImageText(getResources().getDrawable(R.drawable.thickness03), getResources().getString(R.string.thickness_5));
		ImageText ListThickness04 = new ImageText(getResources().getDrawable(R.drawable.thickness04), getResources().getString(R.string.thickness_7));
		ImageText ListThickness05 = new ImageText(getResources().getDrawable(R.drawable.thickness05), getResources().getString(R.string.thickness_9));
		ImageText ListThickness06 = new ImageText(getResources().getDrawable(R.drawable.thickness06), getResources().getString(R.string.thickness_11));
		ImageText ListThickness07 = new ImageText(getResources().getDrawable(R.drawable.thickness07), getResources().getString(R.string.thickness_13));
		
		ThicknessString.clear();
		ThicknessString.add(ListThickness01);
		ThicknessString.add(ListThickness02);
		ThicknessString.add(ListThickness03);
		ThicknessString.add(ListThickness04);
		ThicknessString.add(ListThickness05);
		ThicknessString.add(ListThickness06);
		ThicknessString.add(ListThickness07);
		
		mThicknessAdapter = new ImageTextAdapter(this, R.layout.pen_settings_list, ThicknessString);
		mThicknessListView.setAdapter(mThicknessAdapter);
		
		mThicknessListView.setOnItemClickListener(mThicknessListClickListener);
		mThicknessListView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
		mThicknessListView.setItemChecked(mCurThickness, true);
//		mThicknessListView.setBackgroundColor(getResources().getColor(R.color.white));
//		mThicknessListView.setScrollingCacheEnabled(false);
		
//		// Button
//		mOkBtn = (Button) findViewById(R.id.ok);
//		mOkBtn.setOnClickListener(mOkClickListener);
		mCancelBtn = (Button) findViewById(R.id.cancel);
		mCancelBtn.setOnClickListener(mCancelClicklistener);
		
		mThicknessListView.setSelection(mCurThickness);
	}
	
	AdapterView.OnItemClickListener mThicknessListClickListener = new OnItemClickListener() {
		@Override
		public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
				long arg3) {
			mCurThickness = arg2;
			saveInputMethodToSet(mCurThickness); 
			
			finish();
		}
	};
	
//	View.OnClickListener mOkClickListener = new OnClickListener() {
//
//		@Override
//		public void onClick(View v) {
//			saveInputMethodToSet(mCurThickness);
//			
//			finish();
//		}
//	};
//	
	View.OnClickListener mCancelClicklistener = new OnClickListener() {

		@Override
		public void onClick(View v) {
			finish();
		}
	};

	private void saveInputMethodToSet(int Idx){
	   	SharedPreferences sp = PreferenceManager.
									getDefaultSharedPreferences(this);
	   	SharedPreferences.Editor editor = sp.edit();
	      
   		editor.putString(PREF_KEY_PEN_THICKNESS, String.valueOf(Idx));

	   	editor.commit();
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
	}
	
	@Override
	public void onStop() {
		super.onStop();
	}
	
	@Override
	public void finish() {
		super.finish();
	}
	
private class ImageTextAdapter extends ArrayAdapter<ImageText> {
		
		private ArrayList<ImageText> mItems;
		
		public ImageTextAdapter(Context context, int textViewResourceId, ArrayList<ImageText> items) {
			super(context, textViewResourceId, items);
			mItems = items;
		}
		
		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			View v = convertView;
			if(v == null) {
				LayoutInflater vi = (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				v = vi.inflate(R.layout.pen_settings_list, null);
			}
			
			ImageText it = mItems.get(position);
			if(it != null) {
				ImageView iv = (ImageView) v.findViewById(R.id.image);
				CheckedTextView tv = (CheckedTextView) v.findViewById(R.id.text);
				if(iv != null) {
					iv.setBackgroundDrawable(it.getImage());
				}
				if(tv != null) {
					tv.setText(it.getColor());
					if(mCurThickness == position) {
						tv.setChecked(true);
					} else {
						tv.setChecked(false);
					}
				}
			}
			return v;
		}
	}
	
	class ImageText {
		private Drawable mImage;
		private String mThickness;
		
		public ImageText(Drawable _image, String _thickness) {
			this.mImage = _image;
			this.mThickness = _thickness;
		}
		
		public Drawable getImage() {
			return mImage;
		}
		
		public String getColor() {
			return mThickness;
		}
	}
}
