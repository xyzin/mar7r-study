package com.diotek.ime.unistroke;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import com.diotek.ime.unistroke.R;
import com.diotek.dhwr.unistroke.DHWR;

import android.R.layout;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.gesture.GestureOverlayView;
import android.gesture.GestureOverlayView.OnGestureListener;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class UnistrokeUserTrainingSettings extends Activity implements OnGestureListener, OnClickListener {

    private final String TAG = "UnistrokeUserTrainingSettings";
    private final boolean DEBUG = CommonData.IME_DEBUG;
    private final boolean ERROR = CommonData.IME_ERROR;
    private final boolean DRAW_PATH = CommonData.DRAW_PATH;
    
    private final String FILE_NAME = "usermodel.uni";
    
    private GestureOverlayView mGestureOverlayView;
    private EditText mEditText;
    private Button mButtonSave;
//    private Button mButtonDelete;
//    private Button mButtonReplay;
    private Button mButtonList; 
    private char mNewModelCode;
    
    private Context mApplicationContext;
    
    int[][] mModel = null;
    int[] mModelIndex = null;
    int mSize = 0;
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.unistroke_usertraining);
        mApplicationContext = getApplicationContext();
        
        mGestureOverlayView = (GestureOverlayView)findViewById(R.id.gestures);
        mGestureOverlayView.addOnGestureListener(this);
        
        mEditText = (EditText)findViewById(R.id.EditTextDemo);
        
        mButtonSave = (Button)findViewById(R.id.ButtonSave);
        mButtonSave.setOnClickListener(this);
        
//        mButtonDelete = (Button)findViewById(R.id.ButtonDelete);
//        mButtonDelete.setOnClickListener(this);
        
//        mButtonReplay = (Button)findViewById(R.id.ButtonReplay);
//        mButtonReplay.setOnClickListener(this);
        
        mButtonList = (Button)findViewById(R.id.ButtonList);
        mButtonList.setOnClickListener(this);
        
        // ���Ϸ� ����Ǿ� �ִ� user model �� ������ ����
        try {
            FileInputStream fis = openFileInput(FILE_NAME);
            try {
                int nFileSize = fis.available(); // ���� ���� ������
                if(DEBUG) Log.d(TAG, "nFileSize: " + nFileSize);
                byte[] pchunk = new byte[nFileSize];
                // ���Ͽ� ����Ǿ� �ִ� user model �� �о� �޸𸮿� �ű��
                fis.read(pchunk);
                DHWR.DHWRLoadUserModel(pchunk, nFileSize);
                fis.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            try {
                FileOutputStream fos = openFileOutput(FILE_NAME, Context.MODE_PRIVATE);
                try {
                    fos.close();
                } catch (IOException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
            } catch (FileNotFoundException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
        }
    }

    @Override
    public void onGesture(GestureOverlayView overlay, MotionEvent event) {
        if(DEBUG) Log.d(TAG, "onGesture");
        
        float x = event.getX();
        float y = event.getY();
        if(DEBUG) Log.d(TAG, "x, y: " + x + ", " + y);

        DHWR.AddPoint((short)x, (short)y);
    }

    @Override
    public void onGestureCancelled(GestureOverlayView overlay, MotionEvent event) {
        
    }

    @Override
    public void onGestureEnded(GestureOverlayView overlay, MotionEvent event) {
        if(DEBUG) Log.d(TAG, "onGestureEnded");
        float x = event.getX();
        float y = event.getY();
        if(DEBUG) Log.d(TAG, "x, y: " + x + ", " + y);
        DHWR.AddPoint((short)x, (short)y);
        DHWR.EndStroke();
    }

    @Override
    public void onGestureStarted(GestureOverlayView overlay, MotionEvent event) {
        if(DEBUG) Log.d(TAG, "onGestureStarted");
        
        float x = event.getX();
        float y = event.getY();
        DHWR.InkClear();
        if(DEBUG) Log.d(TAG, "x, y: " + x + ", " + y);
        DHWR.AddPoint((short)x, (short)y);
    }

    @Override
    public void onClick(View v) {
        // TODO Auto-generated method stub
        if(v.getId() == R.id.ButtonSave) {
            if(DEBUG) Log.d(TAG, "ButtonSave");

            if(mEditText.getText().toString() == "" || mEditText.getText().toString().length() != 1) {
                Toast.makeText(mApplicationContext, "���ڸ� ����� �Է��Ͻÿ�!", Toast.LENGTH_SHORT).show();
                return;
            }

//            mGestureOverlayView.clear(true);
            int[] count = new int[1];
            DHWR.GetInkCount(count);
            if(DEBUG) Log.d(TAG, "=============== ink2: " + count[0]);

            mNewModelCode = mEditText.getText().toString().charAt(0);
            if(DEBUG) Log.d(TAG, "==== mNewModelCode: " + mNewModelCode);
            int[][] arMode = new int[3][2];
            int[] pCands = new int[1];
            
            int nMode = 0;
            arMode[nMode][0] = DHWR.DLANG_KOREAN;
            arMode[nMode][1] = DHWR.DTYPE_CONSONANT | DHWR.DTYPE_VOWEL | DHWR.DTYPE_UNISTROKE;
            nMode++;
            arMode[nMode][0] = DHWR.DLANG_ENGLISH;
            arMode[nMode][1] = DHWR.DTYPE_UPPERCASE | DHWR.DTYPE_LOWERCASE | DHWR.DTYPE_UNISTROKE;
            nMode++;
            arMode[nMode][0] = DHWR.DLANG_NUMERIC;
            arMode[nMode][1] = DHWR.DTYPE_UNISTROKE;
            nMode++;

            pCands[0] = DHWR.MAX_CANDIDATES;
            int retError = DHWR.SetAttribute(DHWR.SINGLECHAR, arMode, nMode, pCands);
            if(DEBUG) Log.d(TAG, "=== SetAttribute retError: " + Integer.toHexString(retError));
            retError = DHWR.DHWRRegisterUserModel(mNewModelCode);
            if(DEBUG) Log.d(TAG, "=== DHWRRegisterUserModel retError: " + Integer.toHexString(retError));

            if (retError != 0) {
                char[] aResult = new char[(DHWR.MAX_CHARACTERS + 1) * (DHWR.MAX_CANDIDATES)];
                retError = DHWR.Recognize(aResult);
                if(retError == DHWR.ERR_SUCCESS) {
                    Toast.makeText(mApplicationContext, "Drawn character is too similar to '" + aResult[0] +"'", Toast.LENGTH_SHORT).show();
                    DHWR.InkClear();
                } else {
                    Toast.makeText(mApplicationContext, "�Է� �ȵ�", Toast.LENGTH_SHORT).show();
                }
                return;
            }
            fileSave();
        } /*else if(v.getId() == R.id.ButtonReplay) {
            if(DEBUG) Log.d(TAG, "ButtonReplay_Clear");
            DHWR.DHWRClearUserModel();
            DHWR.InkClear();
            if(DEBUG) Log.d(TAG, "=========================== inkclear ===========================");

            fileSave();
        }*//* else if(v.getId() == R.id.ButtonDelete) {
            if(DEBUG) Log.d(TAG, "ButtonDelete_Delete");
            if(mSize < 1)
                return;
            DHWR.DHWRUnregisterUserModel(mModelIndex[2]);
            DHWR.InkClear();
            fileSave();
        }*/ else if(v.getId() == R.id.ButtonList) {
        	if(DEBUG) Log.d(TAG, "ButtonList");
        	
    		Intent intent = new Intent();
    		intent.setClass(UnistrokeUserTrainingSettings.this, UnistrokeUserModelView.class);
    		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    		intent.putExtra("TraningFileName", FILE_NAME);
    		startActivityForResult(intent, 0);
    		
        }
    }

    private boolean fileSave() {
        // ������ ����Ǿ� �ִ� user model �� ���޹���
        int[] nBuffSize = new int[2];
        int retError = DHWR.DHWRStoreUserModel(null, nBuffSize);
        if(DEBUG) Log.d(TAG, "=== DHWRStoreUserModel retError: " + Integer.toHexString(retError));
        if(DEBUG) Log.d(TAG, "nBufferSize: " + nBuffSize[0]);
        byte[] pUserModel = new byte[nBuffSize[0]];
        retError = DHWR.DHWRStoreUserModel(pUserModel, nBuffSize);
        if(DEBUG) Log.d(TAG, "=== DHWRStoreUserModel retError: " + Integer.toHexString(retError));
        
        // ���޹��� �޸𸮸� ���Ͽ� ����
        try {
            FileOutputStream fos = openFileOutput(FILE_NAME, Context.MODE_PRIVATE);
            try {
                fos.write(pUserModel);
                fos.close();
//                DHWR.DHWRClearUserModel();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                 e.printStackTrace();
                return false;
            }
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return false;
        }
        
        Toast.makeText(mApplicationContext, mNewModelCode + "�� �ԷµǾ����ϴ�.", Toast.LENGTH_SHORT).show();
        return true;
    }
    
    public class UnistrokeImageView extends ImageView{
    	private int mX = 0;
    	private int mY = 0;
    	private int[] mUnistrokeModel;
    	private int mPoint = 0;
    	
    	public UnistrokeImageView(Context context, int[] nModel, int point) {
    		super(context);
    		setBackgroundColor(Color.WHITE);
    		mUnistrokeModel = nModel;
    		mPoint = point;
    	}
    	
    	@Override
    	protected void onDraw(Canvas canvas) {
    		// �����̹���
     		super.onDraw(canvas);
     		Paint paint = new Paint();
            paint = new Paint();
            
            paint.setAntiAlias(true);
            paint.setTextSize(20);
            
            
            int oldX = mUnistrokeModel[0];
            int oldY = mUnistrokeModel[1];
            paint.setStrokeWidth(5);
            paint.setColor(Color.RED);
            canvas.drawPoint(oldX, oldY, paint);
            
            paint.setColor(Color.BLACK);
            paint.setStrokeWidth(2);
            Path path = new Path();
            
            if(DRAW_PATH) {
                path.moveTo(oldX, oldY);
            }
            for(int i=2;i<mPoint-2; i+=2) {
                if(DRAW_PATH) {
//                    path.lineTo(oldX, oldY);
                    path.lineTo(mUnistrokeModel[i], mUnistrokeModel[i+1]);
                    canvas.drawPath(path, paint);
                } else {
                    canvas.drawLine(oldX, oldY, mUnistrokeModel[i], mUnistrokeModel[i+1], paint);
                }

                oldX = mUnistrokeModel[i];
                oldY = mUnistrokeModel[i+1];
            }
    	}
    }
}
