﻿package com.diotek.ime.unistroke;

import java.util.Vector;
import android.util.Log;

import com.diotek.ime.unistroke.R;
import com.diotek.ime.unistroke.CommonData.InputRangeMode;

public class DioKeyboardSwitcher {

    private final String TAG = "DioKeyboardSwitcher";
    private static boolean DEBUG = CommonData.IME_DEBUG;
    
    public static final int MODE_TEXT    = 0;
    public static final int MODE_PHONE   = 1;
    public static final int MODE_EMAIL   = 2;
    public static final int MODE_URL     = 3;
    public static final int MODE_IM      = 4;
    public static final int MODE_SYMBOLS = 5;
    public static final int MODE_NUMBER  = 6;

    public static final int KBD_MODE_NORMAL = R.id.mode_normal;
    public static final int KBD_MODE_EMAIL = R.id.mode_email;
    public static final int KBD_MODE_URL = R.id.mode_url;
    public static final int KBD_MODE_IM = R.id.mode_im;

    public static final int KBD_MODE_HWR_KOR = R.id.mode_hwr_kor;
    public static final int KBD_MODE_HWR_ENG = R.id.mode_hwr_eng;
    public static final int KBD_MODE_HWR_NUM = R.id.mode_hwr_num;
    public static final int KBD_MODE_HWR_SYM = R.id.mode_hwr_sym;
    public static final int KBD_MODE_HWR_UNISTROKE = R.id.mode_hwr_unistroke;

    public static final int KBD_MODE_PHONE_01 = R.id.phone_num1;
    public static final int KBD_MODE_PHONE_02 = R.id.phone_num2;
    public static final int KBD_MODE_PHONE_NUM_MAX = 2;

    public static final int KBD_MODE_QWERTY_SYM01 = R.id.qwerty_sym01;
    public static final int KBD_MODE_QWERTY_SYM02 = R.id.qwerty_sym02;
    public static final int KBD_MODE_QWERTY_SYM03 = R.id.qwerty_sym03;
    public static final int KBD_MODE_QWERTY_SYM_MAX = 3;
    public static final int KBD_MODE_HALF_QWERTY_SYM01 = R.id.half_qwerty_sym01;
    public static final int KBD_MODE_HALF_QWERTY_SYM02 = R.id.half_qwerty_sym02;
    public static final int KBD_MODE_HALF_QWERTY_SYM03 = R.id.half_qwerty_sym03;
    public static final int KBD_MODE_HALF_QWERTY_SYM04 = R.id.half_qwerty_sym04;
    public static final int KBD_MODE_HALF_QWERTY_SYM05 = R.id.half_qwerty_sym05;
    public static final int KBD_MODE_HALF_QWERTY_SYM_MAX = 5;

    public static final int KBD_MODE_KEYPAD_SYM01 = R.id.keypad_sym01;
    public static final int KBD_MODE_KEYPAD_SYM02 = R.id.keypad_sym02;
    public static final int KBD_MODE_KEYPAD_SYM03 = R.id.keypad_sym03;
    public static final int KBD_MODE_KEYPAD_SYM04 = R.id.keypad_sym04;
    public static final int KBD_MODE_KEYPAD_SYM05 = R.id.keypad_sym05;
    public static final int KBD_MODE_KEYPAD_SYM06 = R.id.keypad_sym06;
    public static final int KBD_MODE_KEYPAD_SYM_MAX = 6;

    public static final int KBD_MODE_SYM[] = {
        KBD_MODE_QWERTY_SYM01,
        KBD_MODE_QWERTY_SYM02,
        KBD_MODE_QWERTY_SYM03,
        KBD_MODE_HALF_QWERTY_SYM01,
        KBD_MODE_HALF_QWERTY_SYM02,
        KBD_MODE_HALF_QWERTY_SYM03,
        KBD_MODE_HALF_QWERTY_SYM04,
        KBD_MODE_HALF_QWERTY_SYM05,
        KBD_MODE_KEYPAD_SYM01,
        KBD_MODE_KEYPAD_SYM02,
        KBD_MODE_KEYPAD_SYM03,
        KBD_MODE_KEYPAD_SYM04,
        KBD_MODE_KEYPAD_SYM05,
        KBD_MODE_KEYPAD_SYM06,
        KBD_MODE_PHONE_01,
        KBD_MODE_PHONE_02
    };
    
    public static final int KBD_MODE_KOREAN[] = { 
        R.xml.keypad_kor_sky2,
        R.xml.keypad_kor_cji,
        R.xml.keypad_kor_naratgeul,
        R.xml.keypad_kor_moto
    };

    DioComKeyboard mKeyboard = null;
    DioComKeyboardView mInputView;
    DioInputMethodService mMethodService;

    private int mMode;
    private int mImeOptions;

    public static Vector<CharSequence> vKeyboardList = new Vector<CharSequence>();

    private int mLastDisplayWidth;

    public DioKeyboardSwitcher(DioInputMethodService inputMethodService) {
        if(DEBUG) Log.e(TAG,"DioKeyboardSwitcher");
        mMethodService = inputMethodService;

        for(int j=0; j<mMethodService.mKeyboaerList.length; j++) {
            vKeyboardList.add(mMethodService.mKeyboaerList[j]);
        }
    }

    public void setKeyboardMode(int modeText, int imeOptions, boolean bIsUnistroke) { // ejjeon 2010/08/27 united unistroke test
        if(DEBUG) Log.e(TAG,"setKeyboardMode : modeText - " + modeText + " , imeOptions - " + imeOptions);

        mMode = modeText;
        mImeOptions = imeOptions;

        boolean bIsLandscape = mMethodService.isFullscreenMode();
        if (DEBUG) Log.e(TAG,"bIsLandscape : " + bIsLandscape);

        if(mKeyboard != null) {
            mKeyboard = null;
        }

        int xmlID = 0;
        int kbdMode = KBD_MODE_NORMAL;
        boolean bShiftLock = false;

        final int nInputMethodIndex = mMethodService.getInputMethodIndex();
        final int nInputRangeIndex = mMethodService.getInputRangeIndex();

        
        switch(modeText) {
        case MODE_TEXT:
        case MODE_EMAIL:
        case MODE_URL:
        case MODE_IM:
            // dhlee 2010/02/17 [edit �Ӽ��� �°� ����] {
            if(modeText == MODE_EMAIL)
                kbdMode = KBD_MODE_EMAIL;
            else if(modeText == MODE_URL)
                kbdMode = KBD_MODE_URL;
            else
                kbdMode = KBD_MODE_NORMAL;
            // dhlee 2010/02/17 [edit �Ӽ��� �°� ����] }

            switch(nInputMethodIndex) {
            case CommonData.MODE_KEYPAD_SKY2:
            case CommonData.MODE_KEYPAD_CJI:
            case CommonData.MODE_KEYPAD_NARA:
            case CommonData.MODE_KEYPAD_MOTO:
                if(nInputRangeIndex == InputRangeMode.KOR.ordinal()) {
                    xmlID = KBD_MODE_KOREAN[nInputMethodIndex-1];
                } else if(nInputRangeIndex == InputRangeMode.ENG.ordinal()) {
                    xmlID = R.xml.keypad_eng;
                } else if(nInputRangeIndex == InputRangeMode.NUM.ordinal()) {
                    xmlID = R.xml.keypad_num;
                } else if(nInputRangeIndex == InputRangeMode.SYM.ordinal()) {
                    xmlID = R.xml.keypad_sym;
                    kbdMode = KBD_MODE_SYM[mMethodService.getSymbolPage() + KBD_MODE_HALF_QWERTY_SYM_MAX +KBD_MODE_QWERTY_SYM_MAX];
                }
                bShiftLock = true;
                break;
            case CommonData.MODE_QWERTY:
                if(nInputRangeIndex == InputRangeMode.KOR.ordinal()) {
                    xmlID = R.xml.keyboard_qwerty_kor;
                } else if(nInputRangeIndex == InputRangeMode.ENG.ordinal()) {
                    xmlID = R.xml.keyboard_qwerty_eng;
                } else if(nInputRangeIndex == InputRangeMode.SYM.ordinal()
                        || nInputRangeIndex == InputRangeMode.NUM.ordinal() ) {
                    xmlID = R.xml.keyboard_qwerty_sym;
                    kbdMode = KBD_MODE_SYM[mMethodService.getSymbolPage()];
                }
                bShiftLock = true;
                break;
            case CommonData.MODE_HANDWRITING:
                xmlID = R.xml.hwr_norm_scr;
                
                if(nInputRangeIndex == InputRangeMode.KOR.ordinal()) {
                    kbdMode = KBD_MODE_HWR_KOR;
                } else if(nInputRangeIndex == InputRangeMode.ENG.ordinal()) {
                    kbdMode = KBD_MODE_HWR_ENG;
                } else if(nInputRangeIndex == InputRangeMode.NUM.ordinal()) {
                    kbdMode = KBD_MODE_HWR_NUM;
                } else if(nInputRangeIndex == InputRangeMode.SYM.ordinal()) {
                	if (bIsUnistroke) // ejjeon 2010/08/27 united unistroke test
                        kbdMode = KBD_MODE_HWR_UNISTROKE;
                	else
                		kbdMode = KBD_MODE_HWR_SYM;
                }
                break;
            case CommonData.MODE_FULL_HANDWRITING:
                xmlID = R.xml.hwr_full_scr;
                
                if(nInputRangeIndex == InputRangeMode.KOR.ordinal()) {
                    kbdMode = KBD_MODE_HWR_KOR;
                } else if(nInputRangeIndex == InputRangeMode.ENG.ordinal()) {
                    kbdMode = KBD_MODE_HWR_ENG;
                } else if(nInputRangeIndex == InputRangeMode.NUM.ordinal()) {
                    kbdMode = KBD_MODE_HWR_NUM;
                } else if(nInputRangeIndex == InputRangeMode.SYM.ordinal()) {
                	if (bIsUnistroke) // ejjeon 2010/08/27 united unistroke test
                        kbdMode = KBD_MODE_HWR_UNISTROKE;
                	else
                		kbdMode = KBD_MODE_HWR_SYM;
                }
                break;
            case CommonData.MODE_HALF_QWERTY:
                if(nInputRangeIndex == InputRangeMode.KOR.ordinal()) {
                    xmlID = R.xml.keyboard_half_qwerty_kor;
                } else if(nInputRangeIndex == InputRangeMode.ENG.ordinal()) {
                    xmlID = R.xml.keyboard_half_qwerty_eng;
                } else if(nInputRangeIndex == InputRangeMode.SYM.ordinal()
                        || nInputRangeIndex == InputRangeMode.NUM.ordinal() ) {
                    xmlID = R.xml.keyboard_half_qwerty_sym;
                    kbdMode = KBD_MODE_SYM[mMethodService.getSymbolPage()+ KBD_MODE_QWERTY_SYM_MAX];
                }
                bShiftLock = true;
                break;
            default:
                return;
            }
            break;
        case MODE_PHONE:
            xmlID = R.xml.keypad_phone;
            kbdMode = KBD_MODE_SYM[mMethodService.getSymbolPage() + KBD_MODE_HALF_QWERTY_SYM_MAX + KBD_MODE_QWERTY_SYM_MAX + KBD_MODE_KEYPAD_SYM_MAX];
            break;
        case MODE_SYMBOLS:
            break;
        case MODE_NUMBER:
            switch(nInputMethodIndex) {
            case CommonData.MODE_KEYPAD_SKY2:
            case CommonData.MODE_KEYPAD_CJI:
            case CommonData.MODE_KEYPAD_NARA:
            case CommonData.MODE_KEYPAD_MOTO:
                xmlID = R.xml.keypad_num;
                break;
            case CommonData.MODE_QWERTY:
                xmlID = R.xml.keyboard_qwerty_sym;
                kbdMode = KBD_MODE_QWERTY_SYM01;
                break;
            default:
                xmlID = R.xml.keypad_num;
                break;
            }
        default:
            return;
        }

        mKeyboard = new DioComKeyboard(mMethodService, xmlID, kbdMode, nInputMethodIndex);
        mKeyboard.enableShiftLock(bShiftLock);

        mInputView.setKeyboard(mKeyboard);
        mInputView.setShifted(false);

        boolean bIsPreviw = (nInputMethodIndex == CommonData.MODE_QWERTY ) ? true:false;
        mInputView.setPreviewEnabled(bIsPreviw);

        mKeyboard.setImeOptions(mMethodService.getResources(), modeText, imeOptions);
        mKeyboard.setShiftLocked(mKeyboard.isShiftLocked());
    }

    public void setKeyboardMode(boolean bIsUnistroke) { // ejjeon 2010/08/27 united unistroke test hand writing 에서 unistroke 일 때는 sym 모드대신 unistroke 모드의 이미지가 나오게 하기 위해 unistroke 여부를 인자로 받게 수정 함
        if(DEBUG) Log.e(TAG,"setKeyboardMode()");
        setKeyboardMode(mMode, mImeOptions, bIsUnistroke);
    }

    public int getKeyboardMode() {
        return mMode;
    }

    public void makeKeyboards() {
        if (mKeyboard != null) {
            int displayWidth = mMethodService.getMaxWidth();
            if (displayWidth == mLastDisplayWidth) return;
            mLastDisplayWidth = displayWidth;
        }
    }

    public void setInputView(DioComKeyboardView inputView) {
        mInputView = inputView;
    }

    public boolean isAlphabetMode() {
        switch(mMethodService.getInputMethodIndex()) {
        case CommonData.MODE_KEYPAD_SKY2:
        case CommonData.MODE_KEYPAD_CJI:
        case CommonData.MODE_KEYPAD_NARA:
        case CommonData.MODE_KEYPAD_MOTO:
        case CommonData.MODE_QWERTY:
        case CommonData.MODE_HALF_QWERTY:
            if(mMethodService.getInputRangeIndex() != InputRangeMode.KOR.ordinal()) {
                return true;
            }
        }

        return false;
    }

    public void toggleShift() {
        if(mInputView == null || mMethodService == null) {
            if(DEBUG)
                Log.e(TAG,"toggleShift : mInputView - " + mInputView + " mMethodService - " + mMethodService);
            return;
        }

        if( (mMethodService.getInputMethodIndex() == CommonData.MODE_QWERTY)
                && (mMethodService.getInputRangeIndex() == InputRangeMode.KOR.ordinal())) {
            if(mInputView.isShifted() == true) {
                mInputView.setShifted(false);
            } else {
                mInputView.setShifted(true);
            }
        }
    }
}
