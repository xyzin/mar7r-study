package com.diotek.recomword;

import android.util.Log;

import com.diotek.ime.unistroke.CommonData;

public class RecomWord{
    static {
        try {
            Log.i("JNI", "Trying to load libRecomWord.so");
            if(CommonData.TARGET == true) {
                System.load("/system/lib/libRecomWord.so");
            } else {
                System.load("/data/data/com.diotek.ime.unistroke/lib/libRecomWord.so");
            }
        } catch (UnsatisfiedLinkError ule) {
            Log.e("JNI", "WARNING: Could not load libRecomWord.so");
        }
    }

    public final static String rwdVersion = "1.31a";

    public final static int     MAX_USER_LIST_NUM    = (250);
    public final static int     MAX_USER_DB_NUM      = (250);

    public final static int     MAX_LEN_FILE_PATH    = ( 1024 );
    public final static int     MAX_WORD_LEN         = ( 20 );
    public final static int     MAX_NUM_UMLAUT_CHAR  = (54);

    public final static short  RWD_LANG_NONE       =     0x00;            // NONE
    public final static short  RWD_LANG_ENG_US     =     0x01;            // ENGLISH_US
    public final static short  RWD_LANG_ENG_UK     =     0x02;            // ENGLISH_UK
    public final static short  RWD_LANG_KOR        =     0x03;            // KOREAN
    public final static short  RWD_LANG_ARA        =     0x04;            // ARABIC
    public final static short  RWD_LANG_CHI_CN     =     0x05;            // SIMP_CHN
    public final static short  RWD_LANG_CHI_TW     =     0x06;            // TRAD_CHN
    public final static short  RWD_LANG_CHI_HK     =     0x07;            // HONGKONG
    public final static short  RWD_LANG_JPN        =     0x08;            // JAPANESE
    public final static short  RWD_LANG_THA        =     0x09;            // THAI
    public final static short  RWD_LANG_ALB        =     0x0A;            // ALBANIAN
    public final static short  RWD_LANG_AUS        =     0x0B;            // AUSTRIA
    public final static short  RWD_LANG_BAQ        =     0x0C;            // BASQUE
    public final static short  RWD_LANG_CAT        =     0x0D;            // CATALAN
    public final static short  RWD_LANG_SCR        =     0x0E;            // CROATIAN
    public final static short  RWD_LANG_CZE        =     0x0F;            // CZECH
    public final static short  RWD_LANG_DAN        =     0x10;            // DANISH
    public final static short  RWD_LANG_DUT        =     0x11;            // DUTCH
    public final static short  RWD_LANG_EST        =     0x12;            // ESTONIAN
    public final static short  RWD_LANG_FIN        =     0x13;            // FINNISH
    public final static short  RWD_LANG_FRE        =     0x14;            // FRENCH
    public final static short  RWD_LANG_GLA        =     0x15;            // GAELIC
    public final static short  RWD_LANG_GLG        =     0x16;            // GALICIAN
    public final static short  RWD_LANG_GER        =     0x17;            // GERMAN
    public final static short  RWD_LANG_HUN        =     0x18;            // HUNGARIAN
    public final static short  RWD_LANG_ICE        =     0x19;            // ICELANDIC
    public final static short  RWD_LANG_IRI        =     0x1A;            // IRISH
    public final static short  RWD_LANG_ITA        =     0x1B;            // ITALIAN
    public final static short  RWD_LANG_LAV        =     0x1C;            // LATVIAN
    public final static short  RWD_LANG_LIT        =     0x1D;            // LITHUANIAN
    public final static short  RWD_LANG_NOR        =     0x1E;            // NORWEGIAN
    public final static short  RWD_LANG_POL        =     0x1F;            // POLISH
    public final static short  RWD_LANG_POR_EUR    =     0x20;            // PORTUGUESE for European
    public final static short  RWD_LANG_POR_BRA    =     0x21;            // PORTUGUESE for Brazilian
    public final static short  RWD_LANG_SCC        =     0x22;            // SERBIAN
    public final static short  RWD_LANG_SLO        =     0x23;            // SLOVAK
    public final static short  RWD_LANG_SLV        =     0x24;            // SLOVENIAN
    public final static short  RWD_LANG_SPA        =     0x25;            // SPANISH
    public final static short  RWD_LANG_SWE        =     0x26;            // SWEDISH
    public final static short  RWD_LANG_TUR        =     0x27;            // TURKISH
    public final static short  RWD_LANG_VIE        =     0x28;            // VIETNAMESE
    public final static short  RWD_LANG_TAR        =     0x29;            // TATAR
    public final static short  RWD_LANG_BEL        =     0x2A;            // BELARUSIAN
    public final static short  RWD_LANG_BUL        =     0x2B;            // BULGARIAN
    public final static short  RWD_LANG_GRE        =     0x2C;            // GREEK
    public final static short  RWD_LANG_KAZ        =     0x2D;            // KAZAKH
    public final static short  RWD_LANG_MAC        =     0x2E;            // MACEDONIAN
    public final static short  RWD_LANG_MON        =     0x2F;            // MONGOLIAN
    public final static short  RWD_LANG_RUS        =     0x30;            // RUSSIAN
    public final static short  RWD_LANG_UKR        =     0x31;            // UKRAINIAN
    public final static short  RWD_LANG_RUM        =     0x32;            // ROMANIAN
    
    /* DB Type */
    public final static int    RWD_LANG_DB         = 0;
    public final static int    RWD_USER_DB         = 1;
    public final static int    RWD_USER_HISTORY    = 2;
    public final static int    RWD_SPELLCHK_DB     = 3;
    public final static int    RWD_MAX_DB_NUM      = 4;
    
    /* Shift Type */
    public final static int    RWD_SHIFT_OFF       = 0;
    public final static int    RWD_SHIFT_ON        = 1;
    public final static int    RWD_SHIFT_CAPS      = 2;
    
    public final static int    RwdNoError                         = 0;
    public final static int    RwdUnknownErrorOccured             = -1;
    public final static int    RwdInvalidLanguage                 = -2;
    public final static int    RwdDbFileOpenFalied                = -3;
    public final static int    RwdDbFileReadFalied                = -4;
    public final static int    RwdDbFileAlreadyOpened             = -5;
    public final static int    RwdLanguageDBNotYetOpened          = -6;
    public final static int    RwdUserDBNotYetOpened              = -7;
    public final static int    RwdUserListNotYetOpened            = -8;
    public final static int    RwdLanguageDBOpenFailed            = -9;
    public final static int    RwdUserDBOpenFailed                = -10;
    public final static int    RwdUserListOpenFailed              = -11;
    public final static int    RwdInvalidInput                    = -12;
    public final static int    RwdAddWordAlreadyExist             = -13;
    public final static int    RwdContiCharWasNotSet              = -14;
    public final static int    RwdFilePathIsTooLong               = -15;
    public final static int    RwdDBFilePathDoesNotSet            = -16;
    public final static int    RwdMaxLimitExceeded                = -17;
    public final static int    RwdAddItemToUserDBFailed           = -18;
    public final static int    RwdAddItemToUserListFailed         = -19;
    public final static int    RwdSpellCheckInitializationFailed  = -20;
    public final static int    RwdMemoryOverFlow                  = -21;
    public final static int    RwdResultBufferWasNotSet           = -22;
    public final static int    RwdInvalidBufferSize               = -23;
    public final static int    RwdInvalidDBHeader                 = -24;
    public final static int    RwdInvalidItemIndex                = -25;
    public final static int    RwdInvalidData                     = -26;
    public final static int    RwdOutOfRange                      = -27;
    public final static int    RwdNotAlphabetChar                 = -28;
    public final static int    RwdNotInitialized                  = -29;
    public final static int    RwdNotSupportFunction              = -30;
    public final static int    RwdLisenceExpired                  = -31;
    public final static int    RwdNotSupportModel                 = -32;
    
    
    public static native int   RW_Create();
    public static native void  RW_Destroy();
    
    public static native int   RW_InitLangDB(int langCode, int resultLimit);
    public static native int   RW_InitUserDB(char[] strUdbPath);
    public static native int   RW_InitUserHistoryDB(char[] strULstPath);
    public static native int   RW_SetSpellChkDB(char[] strULstPath);
    
    public static native void  RW_SetOptionWordCorrection(boolean enable);
    public static native void  RW_SetOptionWordCompletion(boolean enable);
    public static native void  RW_SetOptionSpellCheck(boolean enable);
    public static native void  RW_SetOptionHangulJasoSrch(boolean enable);
    public static native void  RW_SetOptionAutoAppendToUDB(boolean enable);
    
    public static native int   RW_SetMinLimit(int minLimit);
    public static native int   RW_SetShiftMode(int mode);
    public static native int   RW_SetLanguage(int langCode);
    public static native int   RW_DoInputString(char inputString, char[] regionCharList);
    public static native int   RW_ClearInputStringAll();
    public static native int   RW_ClearInputStringOne();
    public static native int   RW_DoInputStringWord(char[] inputString);
    
    public static native int   RW_DoSearchingWord(int [] bestIndex);
    public static native int   RW_GetResultList(char[][] resultList, int resultNumber);
    public static native int   RW_GetResultWord(char[] resultWord, int indexWord);
    public static native int   RW_SelectResultList(int index);
    
    public static native int   RW_AddItemToUserDB(char[] inputString);
    public static native int   RW_GetRecordCount(int dbType);
    public static native int   RW_DeleteItemAll(int dbType);
    public static native int   RW_GetData(int index, char[] strWord, int dbType);
    public static native int   RW_DeleteItemFromUserDB(int index);
    
    public static native int   RW_WORD_CORRECTION_STATE();
    public static native int   RW_WORD_COMPLETION_STATE();
    public static native int   RW_SPELL_CHECK_STATE();
    public static native int   RW_HANGUL_JASO_SRCH_STATE();
    public static native int   RW_AUTO_APPEND_TO_UDB_STATE();
    public static native int   RW_LANGUAGE_CODE();
    public static native int   RW_INPUT_LIMIT_MIN();
    public static native int   RW_RESULT_LIST_NUM();
    public static native int   RW_INPUT_STRING_LENGTH();
    public static native int   RW_RESULT_LIST_LIMIT_MAX();
    public static native int   RW_SHIFT_STATE();
    
}