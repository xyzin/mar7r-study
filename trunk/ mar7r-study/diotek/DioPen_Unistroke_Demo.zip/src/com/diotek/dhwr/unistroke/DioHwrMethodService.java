package com.diotek.dhwr.unistroke;

import java.util.ArrayList;
import java.util.List;

import com.diotek.dhwr.unistroke.DHWR;
import com.diotek.ime.unistroke.CommonData;
import com.diotek.ime.unistroke.DioComKeyboard;
import com.diotek.ime.unistroke.DioInputMethodService;
import com.diotek.ime.unistroke.CommonData.InputRangeMode;

import android.R.integer;
import android.content.Context;
import android.graphics.Rect;
import android.util.Log;

public class DioHwrMethodService {
    private final boolean DEBUG = CommonData.IME_DEBUG;
    private static final String TAG ="DioHwrMethodService";
    
    Context mIMEService;
    private boolean mbSuggestionActive = true;
    private boolean mHWRCandidateShown = false;
    private boolean mHWRAutoSpaceAdded = false;
    
    private int[] mCands = new int[1];
    /**
     * Box Mode
     */
    private int mHWInputMode;
    private int mHWInputModeType;
    private List<CharSequence> mSuggestions =  null;
    
    // ejjeon 2010/08/12 united unistroke test {
    public boolean bUnistroke = false;
    public boolean bUnistrokeCand = false;
    private boolean bCheckContext = false;
    private boolean bHanShift = false;
    private boolean bEngShift = false;
    private boolean bNumShift = false;
    private byte nShiftDirection = DHWR.DHWR_SHIFT_DIRECT_LEFT;
    private byte nShiftPercent = 25;
    
    // context
    public void setUnistrokeContextState()
    {
    	setUnistrokeContextState(bCheckContext);
    }
    public void setUnistrokeContextState(boolean bCheckContext)
    {
    	byte[] param = new byte[8];
		if (bCheckContext)
			param[0] = DHWR.DHWR_UNISTROKE_CONTEXT_INIT;
		else
			param[0] = DHWR.DHWR_UNISTROKE_CONTEXT_NOTUSE;
    	DHWR.SetParam(DHWR.DHWR_PARAM_UNISTROKE_CONTEXT_STATE, param);
    	this.bCheckContext = bCheckContext;
    }
    // shift(writing area ���� ���� ȣ��Ǿ�� ��)
    public void setShift(boolean bHanShift, boolean bEngShift, boolean bNumShift, byte nShiftDirection, byte nShiftPercent) 
    {
        byte[] param = new byte[8];
        param[0] = 0;
        if (bHanShift)
        	param[0] |= DHWR.DHWR_SHIFT_HAN_ON;
        if (bEngShift)
        	param[0] |= DHWR.DHWR_SHIFT_ENG_ON;
        if (bNumShift)
        	param[0] |= DHWR.DHWR_SHIFT_NUM_ON;
        DHWR.SetParam(DHWR.DHWR_PARAM_SHIFT_INFO_STATE, param);
        
        param[0] = nShiftDirection;
        DHWR.SetParam(DHWR.DHWR_PARAM_SHIFT_INFO_DIRECTION, param);
        param[0] = nShiftPercent;
        DHWR.SetParam(DHWR.DHWR_PARAM_SHIFT_INFO_PERCENT, param);
    	this.bHanShift = bHanShift;
    	this.bEngShift = bEngShift;
    	this.bNumShift = bNumShift;
    	this.nShiftDirection = nShiftDirection;
    	this.nShiftPercent = nShiftPercent;
	}
    public boolean GetShiftRect(Rect tShiftRect) // �������� ����� ����
    {
    	boolean bReturn = true;
    	if (bUnistroke == false)
    		bReturn = false;
    	
    	if (((getHwrInputMode() == DHWR.DLANG_KOREAN) && (bHanShift == false))
    		|| ((getHwrInputMode() == DHWR.DLANG_ENGLISH) && (bEngShift == false))
    		|| ((getHwrInputMode() == DHWR.DLANG_NUMERIC) && (bNumShift == false))
    		|| ((getHwrInputMode() == DHWR.DLANG_SYMBOL) && (bHanShift == false) && (bEngShift == false) && (bNumShift == false)))
    		bReturn =  false;
    	
    	if (bReturn == false)
    		;
    	else if (nShiftDirection == DHWR.DHWR_SHIFT_DIRECT_LEFT)
		{
			tShiftRect.left += (tShiftRect.right - tShiftRect.left) * nShiftPercent / 100;
			tShiftRect.right = tShiftRect.left;
		}
		else if (nShiftDirection == DHWR.DHWR_SHIFT_DIRECT_RIGHT)
		{
			tShiftRect.right -= (tShiftRect.right - tShiftRect.left) * nShiftPercent / 100;
			tShiftRect.left = tShiftRect.right;
		}
		else if (nShiftDirection == DHWR.DHWR_SHIFT_DIRECT_TOP)
		{
			tShiftRect.top += (tShiftRect.bottom - tShiftRect.top) * nShiftPercent / 100;
			tShiftRect.bottom = tShiftRect.top;
		}
		else if (nShiftDirection == DHWR.DHWR_SHIFT_DIRECT_BOTTOM)
		{
			tShiftRect.bottom -= (tShiftRect.bottom - tShiftRect.top) * nShiftPercent / 100;
			tShiftRect.top = tShiftRect.bottom;
		}
    	return bReturn;
    }
    // num shift
    public void setNumShiftValue(int[][] numShiftValue)
    {
        byte[][] param = new byte[10][8];
        int nTemp;
        for (int k = 0; k < 10; k++)
        {
        	param[k][0] = (byte)(numShiftValue[k][0] & 0x000000ff);
        	param[k][1] = (byte)((numShiftValue[k][0] & 0x0000ff00) >> 8);
        	param[k][2] = (byte)((numShiftValue[k][0] & 0x00ff0000) >> 16);
        	param[k][3] = (byte)((numShiftValue[k][0] & 0xff000000) >> 24);
        	//param[k][0] = numShiftValue[k][0];
        	DHWR.SetParam(DHWR.DHWR_PARAM_SHIFT_NUM_0 + k, param[k]);
        }
    }
    // ejjeon 2010/08/12 united unistroke test }
    
    // Function
	public void setContext(Context context){
        mIMEService = context;
    }
    
    public void Create() {
    	// ejjeon 2010/08/13 united unistroke test {
    	byte[] level = new byte[8];
    	level[0] = DHWR.LEVEL_INFO;
    	DHWR.SetParam(DHWR.DHWR_LOG_LEVEL, level);    
    	// ejjeon 2010/08/13 united unistroke test }
    	DHWR.Create();
    }
    
    public void Close() {
    	DHWR.Close();
    }
    
    // dhlee 2010/02/05 ��� ȥ���϶��� ��� �Ұ�
    private void setAttribute(int type, int Language, int LanguageType, int nMode ) {
        int recType = type;
        int[][] arMode = new int[3][2];
//        int[] pCands = new int[1];
        
        // ejjeon 2010/08/11 united unistroke test {
        nMode = 0;
        
        if (bUnistroke)
        {
	        // symbol �� ��/��/�� unistroke
	        if ((Language == DHWR.DLANG_KOREAN) || (Language == DHWR.DLANG_SYMBOL))
	        {
		        arMode[nMode][0] = DHWR.DLANG_KOREAN;
		        arMode[nMode][1] = DHWR.DTYPE_CONSONANT | DHWR.DTYPE_VOWEL | DHWR.DTYPE_UNISTROKE;
		        nMode++;
			}
			if ((Language == DHWR.DLANG_ENGLISH) || (Language == DHWR.DLANG_SYMBOL))
			{
		        arMode[nMode][0] = DHWR.DLANG_ENGLISH;
		        arMode[nMode][1] = DHWR.DTYPE_UPPERCASE | DHWR.DTYPE_LOWERCASE | DHWR.DTYPE_UNISTROKE;
		        nMode++;
			}
			if ((Language == DHWR.DLANG_NUMERIC) || (Language == DHWR.DLANG_SYMBOL))
			{
		        arMode[nMode][0] = DHWR.DLANG_NUMERIC;
		        arMode[nMode][1] = DHWR.DTYPE_UNISTROKE;
		        nMode++;
	        }
        }
		
		if (nMode == 0) // gesture ���� ���
	    // ejjeon 2010/08/11 united unistroke test }
		{
	        arMode[nMode][0] = Language;
	        arMode[nMode][1] = LanguageType;
	        nMode++;
		}
        
        mCands[0] = DHWR.MAX_CANDIDATES;

        DHWR.SetAttribute(recType, arMode, nMode, mCands);
    }
    
    public boolean recognizeGestureBackSpace() {
        if(DEBUG) Log.e(TAG,"recognizeGestureBackSpace");
        int result = 0;
        char[] aResult = new char[(DHWR.MAX_CHARACTERS + 1) * (DHWR.MAX_CANDIDATES)];
        
        setAttribute(DHWR.SINGLECHAR, DHWR.DLANG_GESTURE_EDITING, DHWR.DTYPE_NONE, 1);
        result = DHWR.Recognize(aResult);
        
        if(aResult[0] == DHWR.GESTURE_BACKSPACE ) {
            ((DioInputMethodService)mIMEService).onKey(CommonData.KEYCODE_COMMON_BACKSPACE, null);
            clearInk();
            return true;
        }
        
        aResult = null;
        return false;
    }
    
    private boolean recognizeGesture(){
        if(DEBUG) Log.e(TAG,"recognizeGesture");
        int result = 0;
        char[] aResult = new char[(DHWR.MAX_CHARACTERS + 1) * (DHWR.MAX_CANDIDATES)];
        
        setAttribute(DHWR.SINGLECHAR, DHWR.DLANG_GESTURE_EDITING, DHWR.DTYPE_NONE, 1);
        result = DHWR.Recognize(aResult);
        
        if((getHwrInputMode() == DHWR.DLANG_KOREAN) 
        		|| ((bUnistroke == true) && (getHwrInputMode() == DHWR.DLANG_SYMBOL))) // ejjeon 2010/08/16 united unistroke test shift gesture �� �ν� ��� ������ �����ϰ� �ϱ� ����
        {
            if(aResult[0] == DHWR.GESTURE_SPACE) {
                return false;
            }
        } else {
            if(aResult[0] == DHWR.GESTURE_HAN_SPACE) {
                return false;
            }
        }
        
        switch(aResult[0]){
        case DHWR.GESTURE_RETURN:
            ((DioInputMethodService)mIMEService).onKey(CommonData.KEYCODE_COMMON_ENTER, null);
            break;
        // ejjeon 2010/08/16 united unistroke test { shift gesture �� �ν� ��� ������ �����ϰ� �ϱ� ����
        case DHWR.GESTURE_SHIFT:
            ((DioInputMethodService)mIMEService).onKey(CommonData.KEYCODE_COMMON_INPUT_RANGE, null);
            break;
        // ejjeon 2010/08/16 united unistroke test }
        case DHWR.GESTURE_SPACE:
        case DHWR.GESTURE_HAN_SPACE:
            ((DioInputMethodService)mIMEService).onKey(32, null);
            break;
        default:
            return false;
        }
        
        aResult = null;
        clearInk();
        
        return true;
    }
    
    // dhlee 2010/08/30 [Unistroke Recognize] {
    private void recognizeUnistroke() {
        char[] aResult = new char[(DHWR.MAX_CHARACTERS + 1) * (DHWR.MAX_CANDIDATES)];
        
        for(int i=0; i<aResult.length; i++) {
            aResult[i] = 0x00;
        }

        setAttribute(DHWR.SINGLECHAR, getHwrInputMode(), getHwrInputModeType(), 1);

        int result = DHWR.Recognize(aResult);
        short resultLowByte = (short) result;

        if(DEBUG) {
            for(int j=0; j<aResult.length; j++) {
                if (aResult[j] > 0)
                {
                    Log.e(TAG,"aResult[" + j + "] : " +(int)aResult[j]);
                }
            }
        }
        if(DEBUG) Log.e(TAG,"result: " + resultLowByte);

        clearInk();

        if(resultLowByte == 0 && (aResult.length > 0) && (aResult[0] > 0)) { // ejjeon 2010/08/24
            makeSuggestionUnistroke(mSuggestions, aResult);
            
            if(mbSuggestionActive && mHWRCandidateShown){
                ((DioInputMethodService)mIMEService).setSuggestions(mSuggestions, true, true);
            }else{
                boolean isRecomm = false;

                // ejjeon 2010/08/02 united unistroke test {
                // �ν� ����� �ѱ� �����̸� ���� ���ڸ� ����� �ѱ� ���ڰ� ǥ�õǰ� �ؾ� ��
                // (unistroke ������ ���� �ѱ� �ڼ�, ����, ����, ��ȣ�� �ν��ϴ� �ѱ� ���ڰ�
                // ���Դٴ� ���� ���� �ν� ����� ���� �ν� ����� �������� �ѱ� ���ڰ� �Ǿ��ٴ� �ǹ���)
                
                if(mHWInputMode == DHWR.DLANG_KOREAN) {
                    if (bUnistroke && (aResult[0] >= 0xac00)) {
                        ((DioInputMethodService)mIMEService).onKey(CommonData.KEYCODE_COMMON_BACKSPACE, null);
                    }
                    // ejjeon 2010/08/02 united unistroke test }                    
                    isRecomm = ((DioInputMethodService)mIMEService).setComposingJaso(mSuggestions.get(0).charAt(0));
                } else {
                    if(mCands[0] > 1) {
                        ((DioInputMethodService)mIMEService).setSuggestions(mSuggestions, true, true, true);
                    } else {
                        ((DioInputMethodService)mIMEService).setSuggestions(mSuggestions, true, true, false);
                    }
                }

                mbSuggestionActive = true;
                if(mHWRAutoSpaceAdded && !isRecomm){
                    ((DioInputMethodService)mIMEService).onKey(32, null);
                }
            }
        }
    }
    // dhlee 2010/08/30 [Unistroke Recognize] }
    
    public void recognizeSentence() {
        int result = 0;
        short resultLowByte = 0;
        int i;    
       
        if(IsRecognizeTextMode() 
        		|| (bUnistroke == true)) // ejjeon 2010/08/16 united unistroke test shift gesture �� �ν� ��� ������ �����ϰ� �ϱ� ����
        {
            if(recognizeGesture() == true){
                return;
            }
        }

        if(bUnistroke) {
            recognizeUnistroke();
        }
        
        char[] aResult = new char[(DHWR.MAX_CHARACTERS + 1) * (DHWR.MAX_CANDIDATES)];
        
        for(i=0; i<aResult.length; i++) {
            aResult[i] = 0x00;
        }

        setAttribute(DHWR.MULTICHAR, getHwrInputMode(), getHwrInputModeType(), 1);    
        if(DEBUG) Log.e(TAG,"getHwrInputMode(): " +getHwrInputMode());
        if(DEBUG) Log.e(TAG,"getHwrInputModeType(): " +getHwrInputModeType());

        result = DHWR.Recognize(aResult);
        resultLowByte = (short) result;
        
        if(DEBUG) {
            for(int j=0; j<aResult.length; j++) {
                Log.e(TAG,"aResult : " +(int)aResult[j]);
            }
        }
        if(DEBUG) Log.e(TAG,"result: " + resultLowByte);

        clearInk();

        if(resultLowByte == 0) {
            makeSuggestion(mSuggestions, aResult);
            if(mbSuggestionActive && mHWRCandidateShown){
                ((DioInputMethodService)mIMEService).setSuggestions(mSuggestions, true, true);
            }else{
                boolean isRecomm = ((DioInputMethodService)mIMEService).setComposingText(mSuggestions.get(0));
                mbSuggestionActive = true;
                if(mHWRAutoSpaceAdded && !isRecomm){
                    ((DioInputMethodService)mIMEService).onKey(32, null);
                }
            }
        }
    }

    public void makeSuggestion(List<CharSequence> suggestions, char[] result){
        suggestions.clear();
        String strResult = new String(result);
         
        for(int i=0; i < strResult.length(); i++) {
            if(strResult.charAt(i) == 0x00) {
                strResult = strResult.substring(0, i);
                break;
            }
        }
        suggestions.add(strResult);
    }

    public void makeSuggestionUnistroke(List<CharSequence> suggestions, char[] result){
        suggestions.clear();
        String strResult = new String(result);
        if(DEBUG) Log.d(TAG, "==== strResult: " + strResult);

        int j=0;
        for(int i=0; i < mCands[0] * 2; i+=2) {
            suggestions.add(strResult.substring(i,i+1));
        }
    }

    private char onPostProcessor(char cResult){
        char ret = cResult;
        if(IsRecognizeTextMode()){
            return ret;
        }
        if(ret == 0x20a9){ // uni won code // symbol and number mode check
            ret = 0x005c; // "\"
        }
        return ret;
    }

    public void setWritingArea(Rect rect) {
        DHWR.SetWritingArea(rect.left, rect.top, rect.right, rect.bottom, 40);
   }

    public void addPoint(short x,short y){
        DHWR.AddPoint(x,y);
    }
    
    public int getInkCounter() {
        int[] count = new int[1];
        DHWR.GetInkCount(count);

        return count[0];
    }

    public void endStroke(){
        DHWR.EndStroke();
    }

    private void setHwrInputMode(int mode){
        mHWInputMode = mode;
    }

    private void setUserVowelCharSet() {
        char wCodeSet[] = {0x3157, 0x3160, 0x315c, 0x3161}; // ��, ��, ��, ��
        DHWR.SetUserVowelCharSet(wCodeSet, 4);

    }
    
    private void setHwrInputModeType(int modeType) {
        mHWInputModeType = modeType;
    }
     
    private int getHwrInputMode() {
        return mHWInputMode;
    }
     
    private int getHwrInputModeType() {
        return mHWInputModeType;
    }

    public void clearInk(){
        DHWR.InkClear();
    }

    public void setHwrInputLanguage(InputRangeMode inputRangeIndex){
        switch(inputRangeIndex){
        case KOR:
            if(CommonData.DHWR_MULTICHAR){
                setHwrInputMode(DHWR.DLANG_KOREAN);
                setUserVowelCharSet();
                setHwrInputModeType(DHWR.DTYPE_JOHAP|DHWR.DTYPE_CONSONANT|DHWR.DTYPE_VOWEL);
            } else {
                setHwrInputMode(DHWR.DLANG_KOREAN);
                setHwrInputModeType(DHWR.DTYPE_CONSONANT|DHWR.DTYPE_VOWEL);
            }
                
            break;
        case ENG:
            setHwrInputMode(DHWR.DLANG_ENGLISH);
            setHwrInputModeType(DHWR.DTYPE_UPPERCASE | DHWR.DTYPE_LOWERCASE);
            break;
        case NUM:
            setHwrInputMode(DHWR.DLANG_NUMERIC);
            setHwrInputModeType(DHWR.DTYPE_NONE);
            break;
        case SYM:
            setHwrInputMode(DHWR.DLANG_SYMBOL);
            setHwrInputModeType(DHWR.DTYPE_NONE);
            break;
        default:
            setHwrInputMode(DHWR.DLANG_ENGLISH);
            setHwrInputModeType(DHWR.DTYPE_UPPERCASE | DHWR.DTYPE_LOWERCASE);
            break;
        }
    }

    private boolean IsRecognizeTextMode(){
        if(((getHwrInputMode() & DHWR.DLANG_SYMBOL) == DHWR.DLANG_SYMBOL)){
            return false;
        } else {
            return true;
        }
    }

    public void initMethod() {
        if(DEBUG) Log.d(TAG,"initMethod");

        if(mSuggestions ==  null){
            mSuggestions = new ArrayList<CharSequence>();
        }
    }

    public void setSuggestionActive(boolean active) {
        mbSuggestionActive = active;
    }

    public void destroy() {
        mSuggestions = null;
        Close();
    }
}
