package com.diotek.flick;

public class DioFlickMethodService{

    public final int FlickToLeft  = 0;
    public final int FlickToUp    = 1;
    public final int FlickToRight = 2;
    public final int FlickToDown  = 3;
    public final int FlickInvalid = 4;
    public final int FlickMax = FlickInvalid;

    public void DioFlickEnable() {
        Flicklib.FlickEnable();
    }

    public void DioFlickAddPoint(int x, int y) {
        Flicklib.FlickAddPoint(x, y);
    }

    public void DioFlickClearPoint() {
        Flicklib.FlickClearPoint();
    }

    public int DioFlickCheck(int x, int y, int MinFlickLen) {
        return Flicklib.FlickCheck(x, y, MinFlickLen);
    }

    public int DioGetFlickData() {
        return Flicklib.GetFlickData();
    }

    public void DioFlickSetSensibility(int nFlickSensibility) {
        Flicklib.FlickSetSensibility(nFlickSensibility);
    }
}