package com.diotek.flick;

import com.diotek.ime.unistroke.CommonData;

import android.util.Log;

public class Flicklib{
    static {
      try {
          Log.i("JNI", "Trying to load libFlick.so");          
          if(CommonData.TARGET == true) {
              System.load("/system/lib/libFlick.so");
          } else {
              System.load("/data/data/com.diotek.ime.unistroke/lib/libFlick.so");
          }
      }
      catch (UnsatisfiedLinkError ule) {
          Log.e("JNI", "WARNING: Could not load libFlick.so");
      }
     }
    
    //Flick
     public static native void  FlickEnable();
     public static native void  FlickAddPoint(int x, int y);
     public static native void  FlickClearPoint();
     public static native int   FlickCheck(int x, int y, int MinFlickLen);
     public static native int   GetFlickData();
     public static native void  FlickSetSensibility(int nFlickSensibility);
}